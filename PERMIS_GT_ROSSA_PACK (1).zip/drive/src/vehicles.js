// Véhicules : la GT rouge du joueur (dessin original), ambulance, tram, camion, camionnette.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

const cv = (w, h, d) => { const c = document.createElement('canvas'); c.width = w; c.height = h; d(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; };

function extrudeSide(points, width, bevel = .1) {
  const s = new THREE.Shape(); s.moveTo(points[0][0], points[0][1]); for (let i = 1; i < points.length; i++) s.lineTo(points[i][0], points[i][1]); s.closePath();
  const g = new THREE.ExtrudeGeometry(s, { depth: width - 2 * bevel, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel * .9, bevelSegments: 5, curveSegments: 18 });
  g.translate(0, 0, -(width - 2 * bevel) / 2); g.rotateY(-Math.PI / 2); // longueur sur l'axe z (avant = -z)
  g.deleteAttribute('normal'); g.deleteAttribute('uv'); const m = mergeVertices(g, 1e-4); m.computeVertexNormals(); return m;
}
function smoothCurve(pts, n = 6) { const c = new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(p[0], p[1], 0)), true, 'centripetal'); return c.getPoints(pts.length * n).map(v => [v.x, v.y]); }
function wheel(r, w, rimMat, tireMat) {
  const g = new THREE.Group();
  const tire = new THREE.Mesh(new THREE.CylinderGeometry(r, r, w, 28), tireMat); tire.rotation.z = Math.PI / 2; tire.castShadow = true; g.add(tire);
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(r * .66, r * .66, w + .01, 24), rimMat); rim.rotation.z = Math.PI / 2; g.add(rim);
  for (let k = 0; k < 5; k++) { const sp = new THREE.Mesh(new THREE.BoxGeometry(w + .02, r * 1.15, .07), rimMat); sp.rotation.x = k * Math.PI * 2 / 5; g.add(sp); }
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(r * .16, r * .16, w + .03, 12), new THREE.MeshStandardMaterial({ color: '#d9b64a', metalness: .8, roughness: .3 })); hub.rotation.z = Math.PI / 2; g.add(hub);
  return g;
}

// GT rouge « Rossa » : silhouette de berline sportive à moteur avant, dessin original.
export function makeGT() {
  const car = new THREE.Group();
  const paint = new THREE.MeshPhysicalMaterial({ color: '#a00b1e', metalness: .1, roughness: .32, clearcoat: 1, clearcoatRoughness: .06, envMapIntensity: .8 });
  const black = new THREE.MeshStandardMaterial({ color: '#141518', roughness: .45, metalness: .4 });
  const glass = new THREE.MeshPhysicalMaterial({ color: '#10161e', metalness: .2, roughness: .05, clearcoat: 1, envMapIntensity: 1.2 });
  const chrome = new THREE.MeshStandardMaterial({ color: '#d6dbe0', metalness: 1, roughness: .18 });
  const tireM = new THREE.MeshStandardMaterial({ color: '#17181a', roughness: .92 });
  const rimM = new THREE.MeshStandardMaterial({ color: '#b9bec4', metalness: .9, roughness: .25 });
  // profil latéral (x = position longitudinale, y = hauteur), avant vers x négatif
  const body = smoothCurve([[-2.3, .36], [-2.38, .56], [-2.2, .74], [-1.4, .84], [-.55, .92], [.4, .95], [1.4, .98], [2.12, .95], [2.36, .82], [2.36, .52], [2.26, .34], [1.8, .32], [1.76, .6], [1.62, .76], [1.3, .83], [.98, .76], [.84, .6], [.8, .32], [-1.1, .32], [-1.14, .6], [-1.28, .76], [-1.6, .83], [-1.92, .76], [-2.06, .6], [-2.1, .34]], 5);
  const bodyGeo = extrudeSide(body, 1.96, .09);
  const bm = new THREE.Mesh(bodyGeo, paint); bm.castShadow = true; bm.receiveShadow = true; car.add(bm);
  // verrière (vitrage teinté) et pavillon peint
  const gh = smoothCurve([[-.62, .9], [.05, 1.2], [.8, 1.24], [1.62, .99], [1.45, .93], [-.45, .9]], 4);
  const gm = new THREE.Mesh(extrudeSide(gh, 1.56, .06), glass); gm.position.y = .01; car.add(gm);
  // calandre, prises d'air, diffuseur, échappements
  const grille = new THREE.Mesh(new RoundedBoxGeometry(1.1, .2, .1, 3, .04), black); grille.position.set(0, .5, -2.33); car.add(grille);
  [-.58, .58].forEach(x => { const intake = new THREE.Mesh(new RoundedBoxGeometry(.32, .12, .08, 2, .03), black); intake.position.set(x, .38, -2.3); car.add(intake); });
  const diff = new THREE.Mesh(new THREE.BoxGeometry(1.5, .14, .2), black); diff.position.set(0, .34, 2.27); car.add(diff);
  [-.42, -.28, .28, .42].forEach(x => { const ex = new THREE.Mesh(new THREE.CylinderGeometry(.055, .055, .2, 14), chrome); ex.rotation.x = Math.PI / 2; ex.position.set(x, .36, 2.36); car.add(ex); });
  [-1, 1].forEach(s => { const side = new THREE.Mesh(new RoundedBoxGeometry(.05, .1, .5, 2, .03), black); side.position.set(s * .985, .62, -.8); car.add(side);
    const mir = new THREE.Mesh(new RoundedBoxGeometry(.24, .12, .14, 2, .04), paint); mir.position.set(s * 1.07, .98, -.42); car.add(mir); });
  // phares, feux arrière, clignotants
  const head = new THREE.MeshStandardMaterial({ color: '#f4f8ff', emissive: '#dfe9ff', emissiveIntensity: .6, roughness: .1 });
  const tail = new THREE.MeshStandardMaterial({ color: '#7d0a14', emissive: '#ff1a2e', emissiveIntensity: .45 });
  car.userData.blink = { L: [], R: [] };
  [-1, 1].forEach(s => {
    const h = new THREE.Mesh(new RoundedBoxGeometry(.42, .09, .1, 2, .03), head); h.position.set(s * .64, .74, -2.22); h.rotation.y = s * .15; car.add(h);
    const t = new THREE.Mesh(new RoundedBoxGeometry(.5, .08, .06, 2, .02), tail); t.position.set(s * .58, .8, 2.24); car.add(t);
    [[s * .92, .72, -2.06], [s * .86, .8, 2.18]].forEach(p => { const b = new THREE.Mesh(new THREE.BoxGeometry(.16, .06, .06), new THREE.MeshBasicMaterial({ color: '#5a3a10' })); b.position.set(...p); car.add(b); car.userData.blink[s < 0 ? 'L' : 'R'].push(b); });
  });
  // écusson original : bouclier jaune et chevron rouge
  const badge = new THREE.Mesh(new THREE.PlaneGeometry(.16, .2), new THREE.MeshBasicMaterial({ map: cv(64, 80, (x, w, h) => { x.fillStyle = '#e8c33a'; x.beginPath(); x.moveTo(4, 4); x.lineTo(w - 4, 4); x.lineTo(w - 4, h * .55); x.quadraticCurveTo(w / 2, h, 4, h * .55); x.closePath(); x.fill(); x.fillStyle = '#c8102e'; x.beginPath(); x.moveTo(14, 18); x.lineTo(w / 2, 50); x.lineTo(w - 14, 18); x.lineTo(w - 22, 18); x.lineTo(w / 2, 38); x.lineTo(22, 18); x.fill(); }), transparent: true }));
  badge.position.set(0, .82, -2.27); badge.rotation.x = -.35; badge.rotation.y = Math.PI; car.add(badge);
  // plaque NE
  const plate = new THREE.Mesh(new THREE.PlaneGeometry(.52, .11), new THREE.MeshBasicMaterial({ map: cv(260, 56, (x, w, h) => { x.fillStyle = '#ffffff'; x.fillRect(0, 0, w, h); x.strokeStyle = '#111'; x.lineWidth = 3; x.strokeRect(2, 2, w - 4, h - 4); x.fillStyle = '#111'; x.font = '700 38px Helvetica, Arial, sans-serif'; x.textBaseline = 'middle'; x.fillText('NE · 2027', 22, h / 2 + 2); }) }));
  plate.position.set(0, .52, 2.38); car.add(plate);
  // roues
  car.userData.wheels = []; car.userData.front = [];
  [[-.84, -1.6, true], [.84, -1.6, true], [-.85, 1.3, false], [.85, 1.3, false]].forEach(([x, z, f]) => { const piv = new THREE.Group(); piv.position.set(x, .36, z); const w = wheel(.36, .28, rimM, tireM); piv.add(w); car.add(piv); car.userData.wheels.push(w); if (f) car.userData.front.push(piv); });
  car.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return car;
}

export function makeAmbulance() {
  const g = new THREE.Group();
  const white = new THREE.MeshStandardMaterial({ color: '#f4f5f2', roughness: .4 });
  const stripe = new THREE.MeshStandardMaterial({ map: cv(512, 64, (x, w, h) => { for (let i = 0; i < 16; i++) { x.fillStyle = i % 2 ? '#f2d21a' : '#1f5fb0'; x.fillRect(i * 32, 0, 32, h); } }) });
  const body = new THREE.Mesh(new RoundedBoxGeometry(2.1, 2.3, 5.8, 3, .15), white); body.position.set(0, 1.45, .3); g.add(body);
  const cab = new THREE.Mesh(new RoundedBoxGeometry(2.05, 1.5, 1.6, 3, .2), white); cab.position.set(0, 1.05, -2.9); g.add(cab);
  const ws = new THREE.Mesh(new THREE.BoxGeometry(1.8, .7, .05), new THREE.MeshStandardMaterial({ color: '#18212b', metalness: .8, roughness: .1 })); ws.position.set(0, 1.5, -3.71); ws.rotation.x = -.25; g.add(ws);
  [-1.06, 1.06].forEach(x => { const s = new THREE.Mesh(new THREE.BoxGeometry(.02, .3, 7.2), stripe); s.position.set(x, 1.2, -.3); g.add(s); });
  const txt = new THREE.Mesh(new THREE.PlaneGeometry(1.6, .35), new THREE.MeshBasicMaterial({ map: cv(512, 110, (x, w, h) => { x.fillStyle = '#ffffff'; x.fillRect(0, 0, w, h); x.fillStyle = '#c4161c'; x.font = '800 78px Helvetica, Arial, sans-serif'; x.textAlign = 'center'; x.fillText('AMBULANCE', w / 2, 82); }) })); txt.position.set(0, 2.2, 3.21); g.add(txt);
  g.userData.beacons = [];
  [-.6, .6].forEach((x, i) => { const b = new THREE.Mesh(new RoundedBoxGeometry(.4, .14, .26, 2, .05), new THREE.MeshBasicMaterial({ color: '#1f6dff', toneMapped: false })); b.position.set(x, 2.66, -2.2); g.add(b); g.userData.beacons.push(b); });
  const L = new THREE.PointLight('#3b7bff', 0, 18, 2); L.position.set(0, 3, -2.2); g.add(L); g.userData.beaconLight = L;
  addWheels(g, [[-.95, -2.4], [.95, -2.4], [-.95, 2], [.95, 2]], .42);
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return g;
}
function addWheels(g, list, r) { const tire = new THREE.MeshStandardMaterial({ color: '#17181a', roughness: .92 }), rim = new THREE.MeshStandardMaterial({ color: '#9aa1a8', metalness: .8, roughness: .3 }); g.userData.wheels = []; list.forEach(([x, z]) => { const w = new THREE.Group(); const t = new THREE.Mesh(new THREE.CylinderGeometry(r, r, .3, 20), tire); t.rotation.z = Math.PI / 2; w.add(t); const rr = new THREE.Mesh(new THREE.CylinderGeometry(r * .6, r * .6, .31, 14), rim); rr.rotation.z = Math.PI / 2; w.add(rr); w.position.set(x, r, z); g.add(w); g.userData.wheels.push(w); }); }

export function makeTruck(color = '#e6e2d6', kind = 'truck') {
  const g = new THREE.Group();
  const paint = new THREE.MeshStandardMaterial({ color, roughness: .5 });
  const cabM = new THREE.MeshStandardMaterial({ color: kind === 'van' ? color : '#2f5f9f', roughness: .4, metalness: .3 });
  const L = kind === 'van' ? 5.2 : 8.5, H = kind === 'van' ? 2.5 : 3.4;
  const box = new THREE.Mesh(new RoundedBoxGeometry(2.3, H - .6, L - 2, 3, .08), paint); box.position.set(0, (H - .6) / 2 + .6, .9); g.add(box);
  const cab = new THREE.Mesh(new RoundedBoxGeometry(2.3, kind === 'van' ? 1.7 : 2.4, 1.9, 3, .2), cabM); cab.position.set(0, kind === 'van' ? 1.35 : 1.75, -L / 2 + 1); g.add(cab);
  const ws = new THREE.Mesh(new THREE.BoxGeometry(2.0, .8, .05), new THREE.MeshStandardMaterial({ color: '#18212b', metalness: .8, roughness: .1 })); ws.position.set(0, kind === 'van' ? 1.7 : 2.35, -L / 2 + .04); g.add(ws);
  if (kind === 'van') { const t = new THREE.Mesh(new THREE.PlaneGeometry(3, .5), new THREE.MeshBasicMaterial({ map: cv(512, 90, (x, w, h) => { x.fillStyle = color; x.fillRect(0, 0, w, h); x.fillStyle = '#b3262d'; x.font = '800 60px Helvetica, Arial, sans-serif'; x.fillText('LIVRAISONS', 20, 66); }) })); t.position.set(1.16, 1.7, .9); t.rotation.y = Math.PI / 2; g.add(t); }
  addWheels(g, kind === 'van' ? [[-1.05, -1.6], [1.05, -1.6], [-1.05, 1.7], [1.05, 1.7]] : [[-1.05, -3.1], [1.05, -3.1], [-1.05, 2.4], [1.05, 2.4], [-1.05, 3.4], [1.05, 3.4]], .48);
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return g;
}

export function makeTramCar(front) {
  const g = new THREE.Group();
  const body = new THREE.MeshStandardMaterial({ color: '#f2f2ee', roughness: .35, metalness: .2 });
  const band = new THREE.MeshStandardMaterial({ color: '#c8102e', roughness: .4 });
  const glass = new THREE.MeshStandardMaterial({ color: '#16202a', metalness: .85, roughness: .08 });
  const b = new THREE.Mesh(new RoundedBoxGeometry(2.4, 2.6, 8.6, 4, .35), body); b.position.y = 1.75; g.add(b);
  const w = new THREE.Mesh(new THREE.BoxGeometry(2.42, .9, 7.8), glass); w.position.y = 2.15; g.add(w);
  const r = new THREE.Mesh(new THREE.BoxGeometry(2.43, .28, 8.4), band); r.position.y = .95; g.add(r);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(1.2, .3, 3), new THREE.MeshStandardMaterial({ color: '#8d959c', metalness: .6 })); roof.position.y = 3.2; g.add(roof);
  if (front) { const pant = new THREE.Mesh(new THREE.BoxGeometry(.05, 1.3, 1.4), new THREE.MeshStandardMaterial({ color: '#333' })); pant.position.set(0, 3.9, 0); pant.rotation.x = .6; g.add(pant); const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.6, .35), new THREE.MeshBasicMaterial({ map: cv(400, 88, (x, w, h) => { x.fillStyle = '#111'; x.fillRect(0, 0, w, h); x.fillStyle = '#ffb020'; x.font = '700 52px Helvetica, Arial'; x.fillText('5  Boudry', 18, 64); }), toneMapped: false })); sign.position.set(0, 2.95, -4.31); sign.rotation.y = Math.PI; g.add(sign); }
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return g;
}

export function makeCones(n = 4) { const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ map: cv(64, 128, (x, w, h) => { for (let i = 0; i < 4; i++) { x.fillStyle = i % 2 ? '#ffffff' : '#f05a1a'; x.fillRect(0, i * 32, w, 32); } }) }); for (let i = 0; i < n; i++) { const c = new THREE.Mesh(new THREE.ConeGeometry(.22, .75, 16), m); c.position.set(0, .38, i * 1.4); c.castShadow = true; g.add(c); } return g; }
