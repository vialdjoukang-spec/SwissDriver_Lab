// Humain réaliste : avatar humain articulé (squelette) + animations Repos / Marche / Course
// recalées (« retargeting ») depuis un jeu d'animations de capture de mouvement.
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/examples/jsm/utils/SkeletonUtils.js';

function b64ToBuf(b64) { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u.buffer; }
export function loadGLB(b64) { return new Promise((res, rej) => new GLTFLoader().parse(b64ToBuf(b64), '', res, rej)); }

// Convertit les clips de l'animation source (os « mixamorig… », repère Z-haut en cm) vers l'avatar (os sans préfixe, Y-haut en m)
export function retargetClips(animGltf, avatarGltf) {
  const src = animGltf.scene; src.updateMatrixWorld(true);
  let charNode = null, srcHips = null; src.traverse(o => { if (/^Character$/i.test(o.name)) charNode = o; if (/mixamorigHips$/i.test(o.name)) srcHips = o; });
  const qChar = charNode ? charNode.quaternion.clone() : new THREE.Quaternion();
  const sChar = charNode ? charNode.scale.x : 1;
  const srcHipY = srcHips ? srcHips.getWorldPosition(new THREE.Vector3()).y : 1;
  let dstHips = null; avatarGltf.scene.traverse(o => { if (o.isBone && o.name === 'Hips') dstHips = o; });
  const dstHipY = dstHips ? dstHips.position.y : 1;
  const clips = {};
  for (const clip of animGltf.animations) {
    const tracks = [];
    for (const t of clip.tracks) {
      const name = t.name.replace(/^mixamorig:?/, '');
      if (name.endsWith('.quaternion')) {
        const v = t.values.slice();
        if (name.startsWith('Hips.')) { const q = new THREE.Quaternion(); for (let i = 0; i < v.length; i += 4) { q.fromArray(v, i).premultiply(qChar); q.toArray(v, i); } }
        tracks.push(new THREE.QuaternionKeyframeTrack(name, t.times, v));
      } else if (name === 'Hips.position') {
        const v = t.values.slice(), p = new THREE.Vector3(); let y0 = null;
        for (let i = 0; i < v.length; i += 3) { p.fromArray(v, i).multiplyScalar(sChar).applyQuaternion(qChar); if (y0 === null) y0 = p.y; v[i] = 0; v[i + 1] = dstHipY + (p.y - srcHipY) * (dstHipY / srcHipY); v[i + 2] = 0; }
        tracks.push(new THREE.VectorKeyframeTrack(name, t.times, v));
      }
    }
    clips[clip.name.toLowerCase()] = new THREE.AnimationClip(clip.name, clip.duration, tracks);
  }
  return clips;
}

export function makeHuman(avatarGltf, clips, outfit) {
  const model = SkeletonUtils.clone(avatarGltf.scene);
  model.traverse(o => {
    if (o.isMesh || o.isSkinnedMesh) {
      o.castShadow = true; o.receiveShadow = true; o.frustumCulled = false;
      if (outfit && /Outfit_(Top|Bottom)/.test(o.name)) { o.material = o.material.clone(); o.material.color = new THREE.Color(/Top/.test(o.name) ? outfit[0] : outfit[1]); }
    }
  });
  const root = new THREE.Group(); root.add(model);
  const mixer = new THREE.AnimationMixer(model);
  const A = { idle: mixer.clipAction(clips.idle), walk: mixer.clipAction(clips.walk), run: mixer.clipAction(clips.run) };
  Object.values(A).forEach(a => { a.play(); a.setEffectiveWeight(0); });
  A.idle.setEffectiveWeight(1);
  root.userData = { mixer, A, w: { idle: 1, walk: 0, run: 0 } };
  return root;
}

// v : vitesse signée (m/s). Vitesses naturelles des clips : marche ≈ 1,5 m/s, course ≈ 4,6 m/s.
export function animateHuman(h, v, dt) {
  const u = h.userData, s = Math.abs(v);
  const target = s < .12 ? { idle: 1, walk: 0, run: 0 } : s < 3 ? { idle: 0, walk: 1, run: 0 } : { idle: 0, walk: Math.max(0, 4 - s), run: Math.min(1, s - 3) };
  const k = 1 - Math.exp(-dt * 8);
  for (const n of ['idle', 'walk', 'run']) { u.w[n] += (target[n] - u.w[n]) * k; u.A[n].setEffectiveWeight(u.w[n]); }
  const dir = v < 0 ? -1 : 1;
  u.A.walk.timeScale = dir * THREE.MathUtils.clamp(s / 1.5, .6, 1.8);
  u.A.run.timeScale = dir * THREE.MathUtils.clamp(s / 4.6, .7, 1.4);
  u.mixer.update(dt);
}
