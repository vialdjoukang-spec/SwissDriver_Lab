import * as THREE from 'three';
import { Sky } from 'three/examples/jsm/objects/Sky.js';
import { CELL, RW, CW, CURB, cellType, groundY, makeMaterials, makeGeometries, buildChunk, makeCar, hash } from './city.js';
import { loadGLB, retargetClips, makeHuman, animateHuman } from './human.js';
import { makeGT, makeAmbulance, makeTruck, makeTramCar, makeCones } from './vehicles.js';
import { sign, plate, yieldMarking } from './signs.js';
import { SCENARIOS, CHAPTERS_READY } from './scenarios.js';

const DATA = window.DATA;
const $ = s => document.querySelector(s);
const md = s => String(s ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/ ([?!:;»])/g, ' $1').replace(/« /g, '« ');
const plain = s => String(s ?? '').replace(/\*\*/g, '');
const V = (x, y, z) => new THREE.Vector3(x, y, z);

/* =================== Rendu =================== */
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = .8;
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
$('#stage').appendChild(renderer.domElement);
const scene = new THREE.Scene(); scene.fog = new THREE.Fog('#dce6ef', 120, 280);
const camera = new THREE.PerspectiveCamera(55, innerWidth / innerHeight, .1, 900);
const sky = new Sky(); sky.scale.setScalar(4500); scene.add(sky);
const sun = new THREE.Vector3(); { const u = sky.material.uniforms; u.turbidity.value = 4; u.rayleigh.value = 1.2; u.mieCoefficient.value = .004; u.mieDirectionalG.value = .8; sun.setFromSphericalCoords(1, THREE.MathUtils.degToRad(48), THREE.MathUtils.degToRad(215)); u.sunPosition.value.copy(sun); }
{ const pm = new THREE.PMREMGenerator(renderer); const sc2 = new THREE.Scene(); const s2 = new Sky(); s2.scale.setScalar(4500); s2.material.uniforms.sunPosition.value.copy(sun); s2.material.uniforms.turbidity.value = 4; s2.material.uniforms.rayleigh.value = 1.2; sc2.add(s2); scene.environment = pm.fromScene(sc2, 0, .1, 2000).texture; scene.environmentIntensity = .4; pm.dispose(); }
scene.add(new THREE.HemisphereLight('#dfeaf6', '#9a9288', .75));
const sunL = new THREE.DirectionalLight('#fff3dc', 2.1); sunL.castShadow = true; sunL.shadow.mapSize.set(3072, 3072);
Object.assign(sunL.shadow.camera, { left: -50, right: 50, top: 50, bottom: -50, near: 1, far: 200 }); sunL.shadow.bias = -.0004; sunL.shadow.normalBias = .03; scene.add(sunL, sunL.target);

/* =================== Ville =================== */
const M = makeMaterials(); const G = makeGeometries();
scene.add(new THREE.Mesh(new THREE.PlaneGeometry(4000, 4000).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ color: '#8c9499', roughness: 1 })).translateY(-.05));
const chunks = new Map(); const LOAD_R = 2;
const chunkAt = (x, z) => [Math.floor(x / CELL), Math.floor(z / CELL)];
function updateChunks(px, pz, budget = 1) {
  const [ci, cj] = chunkAt(px, pz); const want = [];
  for (let dj = -LOAD_R; dj <= LOAD_R; dj++) for (let di = -LOAD_R; di <= LOAD_R; di++) want.push([ci + di, cj + dj, di * di + dj * dj]);
  want.sort((a, b) => a[2] - b[2]);
  for (const [i, j] of want) { if (budget <= 0) break; const k = i + ',' + j; if (!chunks.has(k)) { const g = buildChunk(i, j, M, G); scene.add(g); chunks.set(k, g); budget--; } }
  for (const [k, g] of chunks) { const { i, j } = g.userData; if (Math.abs(i - ci) > LOAD_R || Math.abs(j - cj) > LOAD_R) { scene.remove(g); g.traverse(o => { if (o.geometry && !Object.values(G).includes(o.geometry)) o.geometry.dispose(); }); chunks.delete(k); } }
}
let COLL = { boxes: [], circles: [] }, colT = -1;
function colliders() { const o = { boxes: [], circles: [] }; for (const g of chunks.values()) { o.boxes.push(...g.userData.col.boxes); o.circles.push(...g.userData.col.circles); } return o; }
function hitsWorld(x, z, r = 1.0) { for (const b of COLL.boxes) if (x > b.x0 - r && x < b.x1 + r && z > b.z0 - r && z < b.z1 + r) return true; for (const c of COLL.circles) { const dx = x - c.x, dz = z - c.z; if (dx * dx + dz * dz < (c.r + r) ** 2) return true; } return false; }

// feux : cycle général, avec états imposés par les situations (clé = indice j du carrefour sur l'avenue)
const PHASE = 26;
const phaseAt = t => { const u = t % PHASE; return u < 12 ? 'avG' : u < 14.5 ? 'avY' : u < 24 ? 'crG' : 'crY'; };
const LIGHT_OVR = new Map();
function lightAt(kind, t, j) {
  const o = LIGHT_OVR.get(j);
  if (o) { if (o === 'off') return 'off'; if (kind === 'av') return o; return o === 'green' ? 'red' : 'green'; }
  const p = phaseAt(t); if (kind === 'av') return p === 'avG' ? 'green' : p === 'avY' ? 'amber' : 'red'; return p === 'crG' ? 'green' : p === 'crY' ? 'amber' : 'red';
}
function updateLights(t) { for (const g of chunks.values()) { const L = g.userData.lights, j = g.userData.i === 0 ? g.userData.j : null; const av = lightAt('av', t, j), cr = lightAt('cr', t, j); for (const c of ['red', 'amber', 'green']) { L.av[c].material = c === av ? M[c] : M.lightOff; L.cr[c].material = c === cr ? M[c] : M.lightOff; } } }

/* =================== Nuages, montagnes =================== */
const clouds = [];
{ const cc = document.createElement('canvas'); cc.width = cc.height = 256; const x = cc.getContext('2d'); for (let k = 0; k < 14; k++) { const px = 60 + Math.random() * 136, py = 90 + Math.random() * 80, g = x.createRadialGradient(px, py, 0, px, py, 40 + Math.random() * 50); g.addColorStop(0, 'rgba(255,255,255,.75)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 256, 256); }
  const ct = new THREE.CanvasTexture(cc); ct.colorSpace = THREE.SRGBColorSpace; const cm = new THREE.SpriteMaterial({ map: ct, transparent: true, depthWrite: false, opacity: .9, fog: false });
  for (let k = 0; k < 14; k++) { const sp = new THREE.Sprite(cm); const sz = 90 + Math.random() * 120; sp.scale.set(sz, sz * .45, 1); sp.userData = { ox: (Math.random() - .5) * 900, oz: (Math.random() - .5) * 900, y: 150 + Math.random() * 90 }; scene.add(sp); clouds.push(sp); } }
const mountains = new THREE.Group(); scene.add(mountains);
[['#9fb2c4', 520, 150, 11], ['#b5c4d2', 640, 210, 7], ['#8aa0b4', 430, 95, 17]].forEach(([col, dist, hmax, seed]) => { const pts = []; let r = seed; const R = () => (r = (r * 9301 + 49297) % 233280) / 233280; for (let i = 0; i <= 80; i++) pts.push(new THREE.Vector2(-900 + i * 22.5, hmax * (.35 + .65 * Math.abs(Math.sin(i * .21 + seed)) * (.6 + .4 * R())))); const sh = new THREE.Shape(); sh.moveTo(-900, -20); pts.forEach(p => sh.lineTo(p.x, p.y)); sh.lineTo(900, -20); sh.closePath(); const m = new THREE.Mesh(new THREE.ShapeGeometry(sh), new THREE.MeshBasicMaterial({ color: col, fog: false })); m.position.set(0, 0, -dist); mountains.add(m); if (hmax > 120) { const sn = new THREE.Shape(); sn.moveTo(-900, hmax * .78); pts.forEach(p => sn.lineTo(p.x, Math.max(p.y, hmax * .78))); sn.lineTo(900, hmax * .78); sn.closePath(); const s = new THREE.Mesh(new THREE.ShapeGeometry(sn), new THREE.MeshBasicMaterial({ color: '#f4f7fa', fog: false })); s.position.set(0, 0, -dist + .5); mountains.add(s); } });

/* =================== Humains =================== */
let AV = null, CLIPS = null;
const humansReady = (window.AVATAR_B64 && window.ANIM_B64) ? Promise.all([loadGLB(window.AVATAR_B64), loadGLB(window.ANIM_B64)]).then(([av, an]) => { AV = av; CLIPS = retargetClips(an, av); }).catch(e => console.warn(e)) : Promise.resolve();
function human(outfit) { if (!AV) { const g = new THREE.Group(); const b = new THREE.Mesh(new THREE.CapsuleGeometry(.25, 1.2, 4, 8), new THREE.MeshStandardMaterial({ color: outfit?.[0] || '#557' })); b.position.y = .9; g.add(b); g.userData = { mixer: null }; return g; } return makeHuman(AV, CLIPS, outfit); }
function animHuman(h, v, dt) { if (h.userData.mixer) animateHuman(h, v, dt); }

/* =================== La GT du joueur =================== */
const car = makeGT(); scene.add(car);
const P = { x: 1.5, z: -20, h: 0, v: 0, steer: 0, blink: 0, auto: null, frozen: false };
const VMAX = 55 / 3.6; // bridée en ville
let blinkT = 0;

/* =================== Circulation d'ambiance =================== */
const traffic = [];
for (let i = 0; i < 16; i++) { const c = makeCar(M, G, i); c.userData.vmax = 8 + (i * 1.3) % 4; scene.add(c); traffic.push(c); spawnTraffic(c, true); }
function spawnTraffic(c, anywhere) {
  const [ci, cj] = chunkAt(P.x, P.z); const u = c.userData;
  const onAv = Math.random() < .5; const line = (onAv ? ci : cj) + Math.floor(Math.random() * 5) - 2;
  u.kind = onAv ? 'av' : 'cr'; u.line = line * CELL; u.dir = Math.random() < .5 ? 1 : -1; if (onAv && line === 0) u.dir = -1; u.speed = u.vmax * .6;
  const far = anywhere ? (Math.random() - .5) * 360 : (Math.random() < .5 ? -1 : 1) * (150 + Math.random() * 60);
  if (onAv) { c.position.set(u.line + u.dir * 1.5, 0, P.z + far); c.rotation.y = u.dir > 0 ? 0 : Math.PI; } else { c.position.set(P.x + far, 0, u.line + u.dir * -1.75); c.rotation.y = u.dir > 0 ? -Math.PI / 2 : Math.PI / 2; }
}
function updateTraffic(dt, t) {
  traffic.forEach(c => {
    const u = c.userData, alongZ = u.kind === 'av', pos = alongZ ? c.position.z : c.position.x, fwd = alongZ ? -u.dir : u.dir;
    const next = fwd > 0 ? Math.floor(pos / CELL + 1e-6) * CELL + CELL : Math.ceil(pos / CELL - 1e-6) * CELL - CELL;
    const half = alongZ ? CW : RW, stop = next - fwd * (half + 4.6), dStop = (stop - pos) * fwd;
    const jj = alongZ ? (u.line === 0 ? Math.round(next / CELL) : null) : (Math.round(u.line / CELL));
    const light = alongZ ? lightAt('av', t, u.line === 0 ? jj : null) : lightAt('cr', t, Math.abs(c.position.x) < 40 ? jj : null);
    let target = u.vmax;
    if (light !== 'green' && light !== 'off' && dStop > -1 && dStop < 14) target = Math.max(0, Math.min(target, dStop < 1.2 ? 0 : dStop * .9));
    for (const o of [...traffic, car]) { if (o === c) continue; const dx = o.position.x - c.position.x, dz = o.position.z - c.position.z; const ahead = alongZ ? -dz * u.dir : dx * u.dir; const lat = alongZ ? Math.abs(dx) : Math.abs(dz); if (ahead > 0 && ahead < 12 && lat < 2.2) target = Math.min(target, Math.max(0, (ahead - 6) * 1.4)); }
    u.speed += (target - u.speed) * Math.min(1, dt * (target < u.speed ? 4 : 1.2));
    const step = u.speed * dt; if (alongZ) c.position.z += fwd * step; else c.position.x += fwd * step;
    u.wheels.forEach(w => w.rotation.x -= step / .34);
    const dx = c.position.x - P.x, dz = c.position.z - P.z; if (Math.abs(dx) > 230 || Math.abs(dz) > 230) spawnTraffic(c, false);
    if (SIT && SIT.focus && c.position.distanceTo(SIT.focus) < 45) spawnTraffic(c, false);
  });
}
const walkers = [];
function updateWalkers(dt) { walkers.forEach(h => { const u = h.userData; if (!u.kind) spawnWalker(h, true); const st = u.speed * dt; if (u.kind === 'av') h.position.z -= u.dir * st; else h.position.x += u.dir * st; h.position.y = groundY(h.position.x, h.position.z); animHuman(h, u.speed, dt); if (Math.abs(h.position.x - P.x) > 170 || Math.abs(h.position.z - P.z) > 170 || (SIT && SIT.focus && h.position.distanceTo(SIT.focus) < 25)) spawnWalker(h, false); }); }
function spawnWalker(h, anywhere) { const [ci, cj] = chunkAt(P.x, P.z), u = h.userData; const onAv = Math.random() < .65, line = (onAv ? ci : cj) + Math.floor(Math.random() * 5) - 2; u.kind = onAv ? 'av' : 'cr'; u.dir = Math.random() < .5 ? 1 : -1; u.speed = 1.15 + Math.random() * .5; const side = Math.random() < .5 ? 1 : -1; u.off = onAv ? line * CELL + side * (RW + 1.4 + Math.random() * 2) : line * CELL + side * (CW + .9 + Math.random() * 1.6); const far = anywhere ? (Math.random() - .5) * 300 : (Math.random() < .5 ? -1 : 1) * (110 + Math.random() * 60); if (onAv) { h.position.set(u.off, CURB, P.z + far); h.rotation.y = u.dir > 0 ? 0 : Math.PI; } else { h.position.set(P.x + far, CURB, u.off); h.rotation.y = u.dir > 0 ? -Math.PI / 2 : Math.PI / 2; } }

/* =================== Sons =================== */
let AC = null, muted = false, engine = null, siren = null;
function ac() { if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } if (AC && AC.state === 'suspended') AC.resume(); return AC; }
function startEngine() { const a = ac(); if (!a || engine) return; const o1 = a.createOscillator(), o2 = a.createOscillator(), f = a.createBiquadFilter(), g = a.createGain(); o1.type = 'sawtooth'; o2.type = 'square'; f.type = 'lowpass'; f.frequency.value = 500; g.gain.value = 0; o1.connect(f); o2.connect(f); f.connect(g); g.connect(a.destination); o1.start(); o2.start(); engine = { o1, o2, f, g }; }
function updateEngine(v, thr) { if (!engine) return; const rpm = 750 + Math.abs(v) / VMAX * 4800 + thr * 900; engine.o1.frequency.value = rpm / 60 * 2; engine.o2.frequency.value = rpm / 60; engine.f.frequency.value = 300 + rpm * .25; engine.g.gain.value = muted ? 0 : .035 + thr * .03; }
function tone(freqs, type = 'sine', dur = .18, vol = .16) { const a = ac(); if (!a || muted) return; freqs.forEach((fq, i) => { const o = a.createOscillator(), g = a.createGain(); o.type = type; o.frequency.value = fq; const t = a.currentTime + i * .11; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + .02); g.gain.exponentialRampToValueAtTime(.001, t + dur); o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + dur + .05); }); }
const sfx = { good: () => tone([660, 880, 1320], 'sine', .25), bad: () => tone([200, 150], 'square', .3, .07), tick: () => tone([1500], 'square', .02, .03), horn: () => tone([392, 494], 'sawtooth', .5, .06), done: () => tone([523, 659, 784, 1046], 'triangle', .35) };
function setSiren(on) { const a = ac(); if (!a) return; if (on && !siren) { const o = a.createOscillator(), g = a.createGain(), l = a.createOscillator(), lg = a.createGain(); o.type = 'triangle'; o.frequency.value = 600; l.type = 'square'; l.frequency.value = .9; lg.gain.value = 140; l.connect(lg); lg.connect(o.frequency); g.gain.value = muted ? 0 : .045; o.connect(g); g.connect(a.destination); o.start(); l.start(); siren = { o, g, l }; } if (!on && siren) { siren.o.stop(); siren.l.stop(); siren = null; } }
function applause() { const a = ac(); if (!a || muted) return; const b = a.createBuffer(1, a.sampleRate * .05, a.sampleRate); const d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 3); for (let i = 0; i < 180; i++) { const t = a.currentTime + Math.pow(Math.random(), .8) * 3; const s = a.createBufferSource(); s.buffer = b; const f = a.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 900 + Math.random() * 1800; const g = a.createGain(); g.gain.value = .25 + Math.random() * .4; s.connect(f); f.connect(g); g.connect(a.destination); s.start(t); } }

/* =================== Confettis =================== */
const CN = 500, conf = new THREE.InstancedMesh(new THREE.PlaneGeometry(.08, .13), new THREE.MeshBasicMaterial({ side: THREE.DoubleSide, toneMapped: false }), CN); conf.frustumCulled = false; scene.add(conf);
const confP = Array.from({ length: CN }, () => ({ life: 0, p: V(0, 0, 0), v: V(0, 0, 0), r: new THREE.Euler(), w: V(0, 0, 0) }));
['#ff3b5c', '#ffd23f', '#3bceac', '#2f80ed', '#9b51e0', '#39ff14', '#ff8c42'].forEach((c, k) => { for (let i = k; i < CN; i += 7) conf.setColorAt(i, new THREE.Color(c)); });
const dummy = new THREE.Object3D();
function burst(c, n = 300) { let k = 0; for (const p of confP) { if (k >= n) break; if (p.life > 0) continue; k++; p.life = 3 + Math.random(); p.p.copy(c).add(V((Math.random() - .5) * 2, Math.random(), (Math.random() - .5) * 2)); const a = Math.random() * 6.3, s = 2 + Math.random() * 4; p.v.set(Math.cos(a) * s * .6, 4 + Math.random() * 5, Math.sin(a) * s * .6); p.w.set(Math.random() * 10, Math.random() * 10, Math.random() * 10); } }
function updateConf(dt) { for (let i = 0; i < CN; i++) { const p = confP[i]; if (p.life > 0) { p.life -= dt; p.v.y -= 6.5 * dt; p.v.multiplyScalar(1 - 1.6 * dt); p.p.addScaledVector(p.v, dt); p.r.x += p.w.x * dt; p.r.y += p.w.y * dt; if (p.p.y < .1) { p.p.y = .1; p.v.set(0, 0, 0); } dummy.position.copy(p.p); dummy.rotation.copy(p.r); dummy.scale.setScalar(1); } else { dummy.position.set(0, -50, 0); dummy.scale.setScalar(0); } dummy.updateMatrix(); conf.setMatrixAt(i, dummy.matrix); } conf.instanceMatrix.needsUpdate = true; }

/* =================== Parcours : chapitre → sous-chapitre → situations =================== */
const CH = Object.fromEntries(DATA.chapters.map(c => [c.id, c]));
const GROUP_OF = Object.fromEntries(DATA.groups.flatMap(g => g.chapters.map(c => [c, g])));
const inInt = z => Math.abs(z - Math.round(z / CELL) * CELL) < 14;
function buildRoute() {
  const items = []; let cur = -30;
  const nextFree = (z) => { while (inInt(z)) z -= 4; return z; };
  const nextInt = (z) => Math.floor(z / CELL) * CELL === z ? z - CELL : Math.floor(z / CELL) * CELL;
  for (const g of DATA.groups) for (const cid of g.chapters) {
    const c = CH[cid]; if (!c) continue; const ready = CHAPTERS_READY.includes(cid);
    if (!ready) { items.push({ type: 'locked', c, g, z: null }); continue; }
    let z = nextFree(cur - 20); items.push({ type: 'chapGate', c, g, z }); cur = z;
    for (const s of c.sections) {
      z = nextFree(cur - 45); items.push({ type: 'secGate', c, g, s, z }); cur = z;
      const list = (SCENARIOS[cid] && SCENARIOS[cid][s.id]) || [];
      for (const sc of list) {
        if (sc.slot === 'int') { let zc = nextInt(cur - 50); items.push({ type: 'sit', sc, c, g, s, z: zc }); cur = zc - 22; }
        else { let zm = cur - 70; zm = Math.round((zm + 40) / CELL) * CELL - 40; if (zm > cur - 55) zm -= CELL; items.push({ type: 'sit', sc, c, g, s, z: zm }); cur = zm - 22; }
      }
      z = nextFree(cur - 25); items.push({ type: 'secEnd', c, g, s, z }); cur = z;
    }
  }
  return items.filter(i => i.z !== null);
}
const ITEMS = buildRoute();
const SECS = ITEMS.filter(i => i.type === 'secGate');

/* =================== Sauvegarde =================== */
const KEY = 'permisGT.v1';
let ST = { idx: 0, xp: 0, done: [], secDone: [], errors: 0 };
try { const s = JSON.parse(localStorage.getItem(KEY) || 'null'); if (s && typeof s.idx === 'number') ST = { ...ST, ...s }; } catch (e) {}
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(ST)); } catch (e) {} };

/* =================== Portiques =================== */
function cv(w, h, d) { const c = document.createElement('canvas'); c.width = w; c.height = h; d(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; }
function wrapLines(x, text, maxW) { const words = String(text).split(' '); const lines = []; let cur = ''; for (const w of words) { const t = cur ? cur + ' ' + w : w; if (x.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; } if (cur) lines.push(cur); return lines; }
const frameMat = new THREE.MeshStandardMaterial({ color: '#2f3a45', roughness: .4, metalness: .6 });
function makeGate(it) {
  const g = new THREE.Group(); const kind = it.type;
  [-6.2, 6.2].forEach(x => { const p = new THREE.Mesh(G.unit, frameMat); p.scale.set(.5, 6.6, .5); p.position.set(x, 3.3, it.z); p.castShadow = true; g.add(p); });
  const t = cv(2048, 520, (x, w, h) => {
    const gr = x.createLinearGradient(0, 0, w, 0); const col = kind === 'chapGate' ? ['#173e6b', '#1d5cb0'] : kind === 'secEnd' ? ['#145c3a', '#1f7a4f'] : ['#1d5cb0', '#2b78d0'];
    gr.addColorStop(0, col[0]); gr.addColorStop(1, col[1]); x.fillStyle = gr; x.fillRect(0, 0, w, h); x.fillStyle = '#39ff14'; x.fillRect(0, h - 14, w, 14);
    x.fillStyle = '#fff'; x.textAlign = 'center';
    const lab = kind === 'chapGate' ? 'CHAPITRE · ' + it.g.official.toUpperCase() : kind === 'secEnd' ? 'SOUS-CHAPITRE RÉUSSI' : 'COURS · ' + it.c.otitle.toUpperCase();
    x.font = '800 54px "Segoe UI", Helvetica, Arial, sans-serif'; x.fillText(lab, w / 2, 96);
    x.font = '700 120px Georgia, serif'; const title = kind === 'chapGate' ? it.c.otitle : it.s.otitle; const ls = wrapLines(x, title, w - 160).slice(0, 2); ls.forEach((l, i) => x.fillText(l, w / 2, 240 + i * 130 - (ls.length - 1) * 50));
    x.font = '500 46px "Segoe UI", Helvetica, Arial, sans-serif'; x.fillStyle = '#d6e8fb'; x.fillText(kind === 'secEnd' ? 'Suite du parcours tout droit' : 'Roulez sous le portique : le cours s’ouvre', w / 2, h - 50);
  });
  const beam = new THREE.Mesh(new THREE.PlaneGeometry(12, 3.05), new THREE.MeshBasicMaterial({ map: t, toneMapped: false })); beam.position.set(0, 5.7, it.z + .27); g.add(beam);
  const bb = new THREE.Mesh(G.unit, frameMat); bb.scale.set(12.9, 3.25, .45); bb.position.set(0, 5.7, it.z); bb.castShadow = true; g.add(bb);
  if (kind !== 'secEnd') { const stripe = new THREE.Mesh(new THREE.PlaneGeometry(10, .6), new THREE.MeshBasicMaterial({ color: '#39ff14', toneMapped: false, transparent: true, opacity: .55 })); stripe.rotation.x = -Math.PI / 2; stripe.position.set(0, .03, it.z); g.add(stripe); }
  return g;
}

/* =================== Chemins =================== */
class Path {
  constructor(pts) { this.p = pts.map(p => p.clone ? p.clone() : V(p[0], 0, p[1])); this.L = [0]; for (let i = 1; i < this.p.length; i++) this.L.push(this.L[i - 1] + this.p[i].distanceTo(this.p[i - 1])); this.len = this.L[this.L.length - 1]; }
  at(s, out = V(0, 0, 0)) { s = Math.max(0, Math.min(this.len, s)); let i = 1; while (i < this.L.length - 1 && this.L[i] < s) i++; const a = this.p[i - 1], b = this.p[i], t = (s - this.L[i - 1]) / Math.max(1e-6, this.L[i] - this.L[i - 1]); return out.copy(a).lerp(b, t); }
  yaw(s) { const a = this.at(Math.max(0, s - .6)), b = this.at(Math.min(this.len, s + .6)); return Math.atan2(-(b.x - a.x), -(b.z - a.z)); }
  sAtZ(z) { let best = 0, bd = 1e9; for (let s = 0; s <= this.len; s += .25) { const d = Math.abs(this.at(s).z - z); if (d < bd) { bd = d; best = s; } } return best; }
  sAtX(x) { let best = 0, bd = 1e9; for (let s = 0; s <= this.len; s += .25) { const d = Math.abs(this.at(s).x - x); if (d < bd) { bd = d; best = s; } } return best; }
}
const bez = (a, c, b, n = 12) => { const o = []; for (let i = 0; i <= n; i++) { const t = i / n; o.push(V((1 - t) ** 2 * a[0] + 2 * (1 - t) * t * c[0] + t * t * b[0], 0, (1 - t) ** 2 * a[1] + 2 * (1 - t) * t * c[1] + t * t * b[1])); } return o; };
const arc = (cx, cz, r, t0, t1, n = 24) => { const o = []; for (let i = 0; i <= n; i++) { const t = t0 + (t1 - t0) * i / n; o.push(V(cx + r * Math.cos(t), 0, cz - r * Math.sin(t))); } return o; };
const pts = (...a) => a.flatMap(x => Array.isArray(x[0]) || x[0]?.isVector3 ? x : [x]).map(p => p.isVector3 ? p : V(p[0], 0, p[1]));

/* =================== Acteurs =================== */
function actor(mesh, path, o = {}) { const a = { mesh, path, s: o.s0 || 0, v: o.v0 ?? 0, vmax: o.vmax || 8, hold: o.hold ?? null, released: !!o.released, prio: !!o.prio, clear: o.clear ?? 1e9, kind: o.kind || 'car', len: o.len || 4.4, followBehind: o.followBehind ?? null, segs: o.segs || null, rad: o.rad || 2.4 }; scene.add(mesh); a.segs?.forEach(m => scene.add(m)); place(a); return a; }
function place(a) {
  const p = a.path.at(a.s); a.mesh.position.set(p.x, a.kind === 'ped' || a.kind === 'agent' ? groundY(p.x, p.z) : 0, p.z); a.mesh.rotation.y = a.path.yaw(a.s);
  if (a.segs) a.segs.forEach((m, k) => { const s2 = a.s - (k + 1) * 9.2; const q = a.path.at(s2); m.position.set(q.x, 0, q.z); m.rotation.y = a.path.yaw(Math.max(.5, s2)); });
}
function stepActor(a, dt) {
  let target = a.vmax;
  if (a.followBehind !== null && !a.released) { const want = Math.max(0, P.sAlong - a.followBehind); const d = want - a.s; target = THREE.MathUtils.clamp(d * 2 + P.v, 0, a.vmax * 1.3); }
  else if (!a.released && a.hold !== null) { const d = a.hold - a.s; target = d <= .05 ? 0 : Math.min(a.vmax, Math.sqrt(2 * 3 * Math.max(0, d))); }
  if (a.kind === 'static') target = 0;
  a.v += (target - a.v) * Math.min(1, dt * (target < a.v ? 3.5 : 1.6));
  a.s = Math.min(a.path.len, a.s + a.v * dt); place(a);
  if (a.mesh.userData.wheels) a.mesh.userData.wheels.forEach(w => w.rotation.x -= a.v * dt / .36);
  if (a.kind === 'ped' || a.kind === 'agent') animHuman(a.mesh, a.kind === 'agent' ? 0 : a.v, dt);
  if (a.kind === 'amb') { const on = Math.floor(performance.now() / 160) % 2; a.mesh.userData.beacons.forEach((b, i) => b.material.color.set((i + on) % 2 ? '#1f6dff' : '#0b1d4a')); a.mesh.userData.beaconLight.intensity = on ? 18 : 2; }
}
function removeActor(a) { scene.remove(a.mesh); a.segs?.forEach(m => scene.remove(m)); }

// cycliste simple
function makeCyclist() { const g = new THREE.Group(); const dark = new THREE.MeshStandardMaterial({ color: '#222', roughness: .6 }), frame = new THREE.MeshStandardMaterial({ color: '#2f80ed', metalness: .5, roughness: .4 }); [-.55, .55].forEach(z => { const w = new THREE.Mesh(new THREE.TorusGeometry(.34, .04, 8, 24), dark); w.rotation.y = Math.PI / 2; w.position.set(0, .36, z); g.add(w); }); const f1 = new THREE.Mesh(new THREE.CylinderGeometry(.03, .03, 1.1, 8), frame); f1.rotation.x = Math.PI / 2; f1.position.set(0, .62, 0); g.add(f1); const f2 = new THREE.Mesh(new THREE.CylinderGeometry(.03, .03, .55, 8), frame); f2.position.set(0, .62, .25); f2.rotation.x = .4; g.add(f2); const body = new THREE.Mesh(new THREE.CapsuleGeometry(.2, .5, 4, 8), new THREE.MeshStandardMaterial({ color: '#f2c94c' })); body.position.set(0, 1.25, .1); body.rotation.x = -.5; g.add(body); const head = new THREE.Mesh(new THREE.SphereGeometry(.15, 12, 10), new THREE.MeshStandardMaterial({ color: '#c99a78' })); head.position.set(0, 1.72, -.15); g.add(head); const helm = new THREE.Mesh(new THREE.SphereGeometry(.17, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: '#e5484d' })); helm.position.copy(head.position).add(V(0, .03, 0)); g.add(helm); g.traverse(o => { if (o.isMesh) o.castShadow = true; }); return g; }

/* =================== Situations =================== */
let SIT = null; // situation active
const PL = 1.5;
const straightPath = (z0) => new Path(pts([PL, z0 + 75], [PL, z0 - 70]));
function buildSit(it) {
  const sc = it.sc, z = it.z, k = sc.kind, S = { it, sc, actors: [], props: new THREE.Group(), focus: V(0, 0, z), light: null, phase: 'approach', t: 0, cam: null };
  scene.add(S.props);
  const P0 = straightPath(z); S.pPath = P0; S.decS = P0.sAtZ(z + 17); S.stopS = P0.sAtZ(z + 8.4); S.clearS = P0.sAtZ(z - 5); S.endS = P0.sAtZ(z - 30);
  const add = o => (S.props.add(o), o);
  const carFrom = (dir, o = {}) => { // 'right' (vient de x+ vers x−), 'left', 'oncoming'
    let path; if (dir === 'right') path = new Path(pts([60, z - 1.75], [-60, z - 1.75])); else if (dir === 'left') path = new Path(pts([-60, z + 1.75], [60, z + 1.75])); else path = new Path(pts([-1.5, z - 80], [-1.5, z + 80]));
    const hold = dir === 'oncoming' ? path.sAtZ(z - (o.holdD || 14)) : path.sAtX(dir === 'right' ? (o.holdD || 13) : -(o.holdD || 13));
    const clear = dir === 'oncoming' ? path.sAtZ(z + 5) : path.sAtX(dir === 'right' ? -3.5 : 4.5);
    const a = actor(makeCar(M, G, o.paint ?? 3), path, { s0: Math.max(0, hold - 30), v0: 7, vmax: o.vmax || 8.5, hold, prio: o.prio ?? true, clear }); S.actors.push(a); return a;
  };
  const lightsOff = () => { S.light = 'off'; add(signAt('stopText', 5.6, z + 31)); };
  function signAt(kind, x, zz, ry = 0, poleH) { const s = sign(kind, poleH); s.position.set(x, CURB, zz); s.rotation.y = ry; return add(s); }
  switch (k) {
    case 'agent': { S.light = 'red'; const ag = human(['#e8ff3a', '#1f2a44']); const a = actor(ag, new Path(pts([.4, z - .3], [.4, z - .31])), { kind: 'agent', released: true, vmax: 0 }); ag.rotation.y = Math.PI; a.mesh.userData.wave = true; S.actors.push(a);
      const cc = carFrom('right', { prio: false, holdD: 11 }); cc.hold = cc.path.sAtX(11); break; }
    case 'lightsOffYield': case 'yieldLeft': case 'sideYield': { lightsOff(); signAt('yield', 5.6, z + 8.6); add(yieldMarking(PL + 1, z + 8.2)); if (k === 'sideYield') { const m = signAt('main', -6.2, z + 6, Math.PI / 2); } carFrom('left', { holdD: 15, paint: 1 }); break; }
    case 'blockedGreen': case 'blockedQueue': { if (k === 'blockedGreen') S.light = 'green'; else lightsOff(); const qp = new Path(pts([PL, z - 8], [PL, z - 160])); [0, 6.5, 13].forEach((d, i) => { const a = actor(makeCar(M, G, 4 + i), qp, { s0: 4 + d, kind: 'queue', vmax: 7, hold: 4 + d, prio: false }); a.queue = true; S.actors.push(a); }); S.actors.forEach(a => a.s = a.hold); S.actors.forEach(place); if (k === 'blockedQueue') { const cr = carFrom('right', { prio: false, holdD: 16, paint: 7 }); cr.blocker = true; } else { const cr = carFrom('right', { prio: false, holdD: 12, paint: 7 }); cr.blocker = true; } break; }
    case 'rightCar': case 'rightCarLate': case 'mainEnd': { lightsOff(); if (k === 'mainEnd') signAt('mainEnd', 5.6, z + 32); carFrom('right', { holdD: k === 'rightCarLate' ? 22 : 13 }); break; }
    case 'leftTurn': { lightsOff(); carFrom('oncoming', { holdD: 15 });
      const lp = new Path(pts([PL, z + 75], [PL, z + 4], ...bez([PL, z + 4], [PL, z - 1.75], [-5, z - 1.75]).slice(1), [-60, z - 1.75])); S.pPath = lp; S.decS = lp.sAtZ(z + 17); S.stopS = lp.sAtZ(z + 3.6) - .2; S.clearS = lp.sAtX(-3.5); S.endS = lp.sAtX(-30); S.turnBack = true; S.blinkSide = 'L'; break; }
    case 'roundEntry': case 'roundSignal': case 'roundExitPed': {
      lightsOff();
      const isl = new THREE.Mesh(new THREE.CylinderGeometry(3, 3.1, .3, 40), M.grass); isl.position.set(0, .15, z); isl.receiveShadow = true; add(isl);
      const ring = new THREE.Mesh(new THREE.CylinderGeometry(3.25, 3.3, .2, 40), M.concrete); ring.position.set(0, .1, z); add(ring);
      for (let q = 0; q < 6; q++) { const bush = new THREE.Mesh(G.leaf, M.hedge); bush.scale.setScalar(.7); bush.position.set(Math.cos(q) * 1.6, .8, z + Math.sin(q) * 1.6); add(bush); }
      signAt('round', 5.6, z + 10); signAt('round', -5.6, z - 10, Math.PI); signAt('round', 9.5, z - 4.6, -Math.PI / 2); signAt('round', -9.5, z + 4.6, Math.PI / 2);
      const thIn = -1.27, thOut = 1.27;
      const rp = new Path(pts([PL, z + 75], [PL, z + 5.6], ...arc(0, z, 5, thIn, thOut, 26).slice(1), [PL, z - 6], [PL, z - 70])); S.pPath = rp; S.decS = rp.sAtZ(z + 17); S.stopS = rp.sAtZ(z + 7.4); S.clearS = rp.sAtZ(z - 6); S.endS = rp.sAtZ(z - 30);
      if (k === 'roundEntry') { const cp = new Path(pts(...arc(0, z, 5, 2.6, 5.92, 40), [40, z + 1.75])); const a = actor(makeCar(M, G, 2), cp, { s0: 0, v0: 5, vmax: 6, hold: cp.L[cp.L.length - 1] * 0 + 2.2, prio: true, clear: 5 * (5.6 - 2.6) }); S.actors.push(a); S.ringCar = a; }
      if (k === 'roundSignal') { S.signalTrick = true; }
      if (k === 'roundExitPed') { S.decS = rp.sAtX(4.6) + 2; S.stopS = rp.sAtZ(z - 3.2); S.clearS = rp.sAtZ(z - 8);
        const pp = new Path(pts([6.5, z - 7.2], [-7, z - 7.2])); const ped = actor(human(['#d9435a', '#2b2f36']), pp, { kind: 'ped', vmax: 1.3, hold: 1.5, prio: true, clear: pp.sAtX(-.4), rad: 1.3 }); S.actors.push(ped);
        const cyp = new Path(pts(...arc(0, z, 6.6, -.6, 1.3, 18), [2.9, z - 9], [2.9, z - 80])); const cy = actor(makeCyclist(), cyp, { kind: 'bike', vmax: 4.2, hold: 2.6, prio: true, clear: cyp.sAtZ(z - 14), rad: 1.4 }); S.actors.push(cy); }
      break; }
    case 'drivewayLeft': case 'drivewayPed': case 'drivewayHedge': {
      const dp = new Path(pts([11.4, z], [6.4, z], ...bez([6.4, z], [PL, z], [PL, z - 6]).slice(1), [PL, z - 70])); S.pPath = dp; S.teleport = { s: 0 }; S.decS = .1;
      S.stopS = k === 'drivewayPed' ? dp.sAtX(9.9) : dp.sAtX(6.6); S.clearS = dp.sAtZ(z - 4); S.endS = dp.sAtZ(z - 30); S.blinkSide = 'R';
      [z - 1.9, z + 1.9].forEach(zz => { const p = new THREE.Mesh(G.unit, M.concrete); p.scale.set(.5, 2.2, .5); p.position.set(12.3, CURB + 1.1, zz); add(p); });
      const road = new Path(pts([PL, z + 90], [PL, z - 90])); const rc = actor(makeCar(M, G, 6), road, { s0: 10, v0: 8, vmax: 8.5, hold: road.sAtZ(z + (k === 'drivewayHedge' ? 14 : 18)), prio: true, clear: road.sAtZ(z - 7) }); S.actors.push(rc);
      if (k === 'drivewayPed') { const pp = new Path(pts([8.4, z - 14], [8.4, z + 14])); S.actors.push(actor(human(['#4a6f9a', '#2b2b2b']), pp, { kind: 'ped', vmax: 1.3, hold: pp.sAtZ(z - 3.2), prio: true, clear: pp.sAtZ(z + 2), rad: 1.3 })); rc.hold = road.sAtZ(z + 40); rc.prio = false; }
      if (k === 'drivewayHedge') { const hd = new THREE.Mesh(G.unit, M.hedge); hd.scale.set(5.2, 1.9, .9); hd.position.set(8.6, CURB + .95, z + 2.2); hd.castShadow = true; add(hd); S.creep = true; }
      S.cam = { pos: V(10.5, 6.5, z + 11), look: V(4, .6, z - 1.5) };
      break; }
    case 'narrowMine': case 'narrowSign': {
      const zm = z; S.focus = V(0, 0, zm);
      if (k === 'narrowMine') { const van = makeTruck('#f2f0ea', 'van'); van.position.set(PL, 0, zm); add(van); const cones = makeCones(3); cones.position.set(PL + .3, 0, zm + 3.4); add(cones);
        S.pPath = new Path(pts([PL, zm + 75], [PL, zm + 8.5], ...bez([PL, zm + 8.5], [-1.2, zm + 6], [-1.2, zm + 3.5]).slice(1), [-1.2, zm - 3.5], ...bez([-1.2, zm - 3.5], [-1.2, zm - 6.5], [PL, zm - 9]).slice(1), [PL, zm - 70])); S.stopS = S.pPath.sAtZ(zm + 10.5); }
      else { [[2.6, 4.6], [-4.6, -2.6]].forEach(([a, b]) => { for (let q = -6; q <= 6; q += 1.5) { const c = makeCones(1); c.position.set((a + b) / 2 + (b > 0 ? -.4 : .4) * 0, 0, zm + q); add(c); } const bar = new THREE.Mesh(G.unit, new THREE.MeshStandardMaterial({ color: '#d9262c' })); bar.scale.set(b - a, .25, 12); bar.position.set((a + b) / 2, .7, zm); add(bar); });
        signAt('narrowPrio', 5.6, zm + 18);
        S.pPath = new Path(pts([PL, zm + 75], [PL, zm + 10], [0, zm + 6.5], [0, zm - 6.5], [PL, zm - 10], [PL, zm - 70])); S.stopS = S.pPath.sAtZ(zm + 11.5); }
      S.decS = S.pPath.sAtZ(zm + 21); S.clearS = S.pPath.sAtZ(zm - 9); S.endS = S.pPath.sAtZ(zm - 30);
      const op = k === 'narrowSign' ? new Path(pts([-1.5, zm - 80], [-1.5, zm - 10], [0, zm - 6.5], [0, zm + 6.5], [-1.5, zm + 10], [-1.5, zm + 80])) : new Path(pts([-1.5, zm - 80], [-1.5, zm + 80]));
      const holdS = k === 'narrowSign' ? op.sAtZ(zm - 1) : op.sAtZ(zm - 17);
      S.actors.push(actor(makeCar(M, G, 1), op, { s0: holdS - (k === 'narrowSign' ? 8 : 25), v0: 5, vmax: k === 'narrowSign' ? 4.5 : 8, hold: holdS, prio: true, clear: op.sAtZ(zm + (k === 'narrowSign' ? 9 : 6)) }));
      break; }
    case 'narrowTheirs': case 'narrowTruck': {
      const zm = z; const obst = makeCar(M, G, 8); obst.position.set(-1.6, 0, zm - 1); obst.rotation.y = Math.PI; add(obst); if (k === 'narrowTruck') { const cones = makeCones(3); cones.position.set(-1.2, 0, zm - 5.5); add(cones); }
      const op = new Path(pts([-1.5, zm - 80], [-1.5, zm - 9], ...bez([-1.5, zm - 9], [1.2, zm - 6.5], [1.2, zm - 3.8]).slice(1), [1.2, zm + 2], ...bez([1.2, zm + 2], [1.2, zm + 5], [-1.5, zm + 7.5]).slice(1), [-1.5, zm + 80]));
      const mesh = k === 'narrowTruck' ? makeTruck('#e9e5d8') : makeCar(M, G, 5); const holdS = op.sAtZ(zm - 13);
      const a = actor(mesh, op, { s0: holdS - 25, v0: 6, vmax: 6.5, hold: holdS, prio: false, len: k === 'narrowTruck' ? 8.5 : 4.4, rad: k === 'narrowTruck' ? 3.2 : 2.4 }); S.actors.push(a);
      S.pPath = straightPath(zm); S.decS = S.pPath.sAtZ(zm + 21); S.stopS = S.pPath.sAtZ(zm + 10); S.clearS = S.pPath.sAtZ(zm - 13); S.endS = S.pPath.sAtZ(zm - 30); S.focus = V(0, 0, zm);
      break; }
    case 'mainGo': { lightsOff(); signAt('main', 5.6, z + 26); const a = carFrom('right', { prio: false, holdD: 9.8, paint: 9 }); break; }
    case 'mainTurns': { lightsOff(); const sg = signAt('main', 5.6, z + 26); sg.add(plate('plateLeft', sg.userData.top - .95 - .3)); sg.children[0].scale.y = 1;
      const cp = new Path(pts([-60, z + 1.75], [-5, z + 1.75], ...bez([-5, z + 1.75], [PL, z + 1.75], [PL, z - 4]).slice(1), [PL, z - 120])); const hold = cp.sAtX(-15);
      const a = actor(makeCar(M, G, 1), cp, { s0: hold - 30, v0: 7, vmax: 8, hold, prio: true, clear: cp.sAtZ(z - 12) }); S.actors.push(a); S.follow = a; break; }
    case 'ambulance': case 'ambulanceRed': {
      const zz = z; S.focus = V(0, 0, zz);
      const amb = makeAmbulance(); const ap = new Path(pts([PL, zz + 140], [PL, zz + 40], [k === 'ambulanceRed' ? -.6 : .6, zz + 20], [k === 'ambulanceRed' ? -.6 : .6, zz - 30], [PL, zz - 60], [PL, zz - 160]));
      const a = actor(amb, ap, { s0: 0, v0: 12, vmax: k === 'ambulanceRed' ? 7 : 15, followBehind: 26, prio: true, kind: 'amb', clear: 1e9, len: 6.5, rad: 3 }); S.actors.push(a); S.amb = a; S.ambPath = ap; S.siren = true;
      if (k === 'ambulanceRed') { S.light = 'red'; S.stopFirst = true; S.decS = S.pPath.sAtZ(zz + 8.6); S.stopS = S.pPath.sAtZ(zz + 8.6);
        const xp = new Path(pts([-70, zz + 1.75], [70, zz + 1.75])); const xc = actor(makeCar(M, G, 2), xp, { s0: 30, v0: 8, vmax: 8.5, released: true, prio: true, clear: xp.sAtX(5) }); S.actors.push(xc); S.cross = xc;
        const xp2 = new Path(pts([70, zz - 1.75], [-70, zz - 1.75])); S.actors.push(actor(makeCar(M, G, 6), xp2, { s0: 8, v0: 8, vmax: 8.5, released: true, prio: true, clear: xp2.sAtX(-4) })); }
      else { S.decS = S.pPath.sAtZ(zz + 20); }
      break; }
    case 'tramLeft': { lightsOff();
      const tp = new Path(pts([-1.5, z - 90], [-1.5, z - 7], ...bez([-1.5, z - 7], [-1.5, z + 1.75], [6, z + 1.75]).slice(1), [80, z + 1.75]));
      const rail = new THREE.MeshStandardMaterial({ color: '#4a4f55', metalness: .8, roughness: .3 });
      for (let s = 0; s < tp.len; s += 1) { const p = tp.at(s), y = tp.yaw(s); [-.72, .72].forEach(o => { const r = new THREE.Mesh(G.unit, rail); r.scale.set(.1, .03, 1.05); r.position.set(p.x + Math.cos(y) * o, .02, p.z - Math.sin(y) * o); r.rotation.y = y; S.props.add(r); }); }
      const hold = tp.sAtZ(z - 17);
      const a = actor(makeTramCar(true), tp, { s0: hold - 20, v0: 5, vmax: 6, hold, prio: true, kind: 'tram', segs: [makeTramCar(false)], len: 18.4, rad: 2.8, clear: tp.sAtX(4) + 18.5 }); S.actors.push(a); break; }
  }
  if (S.light !== null) LIGHT_OVR.set(Math.round(z / CELL), S.light);
  return S;
}
function clearSit(S) { if (!S) return; S.actors.forEach(removeActor); scene.remove(S.props); LIGHT_OVR.delete(Math.round(S.it.z / CELL)); setSiren(false); }

/* =================== Interfaces =================== */
let TIME_SCALE = 1, mode = 'drive'; // drive | course | decide | resolve | explain | title
const ui = { course: $('#course'), decide: $('#decide'), explain: $('#explain'), toast: $('#toast') };
let toastT = 0;
function toast(html, cls = '') { ui.toast.className = 'toast on ' + cls; ui.toast.innerHTML = html; clearTimeout(toastT); toastT = setTimeout(() => ui.toast.classList.remove('on'), 3200); }

// --- Cours ---
let COURSE = null;
function coursePages(it) {
  const c = it.c, s = it.s, g = it.g; const pages = [];
  const memoBox = (m) => m?.code ? `<div class="memo"><span>${md(m.code)}</span><p>${md(m.text)}</p></div>` : '';
  if (it.type === 'chapGate') {
    pages.push(`<p class="kick">Partie · ${md(g.official)}</p><h2>${md(c.otitle)}</h2><p class="clear">En clair : ${md(c.title)}</p><p class="lead">${md(c.oscope)}</p><p>${md(c.tagline)}</p>`);
    pages.push(`<h3>Introduction</h3>${c.intro.map(p => `<p>${md(p)}</p>`).join('')}`);
    pages.push(`<h3>L’essentiel du chapitre</h3><div class="box ok"><b>L’idée clé</b><p>${md(c.keyIdea)}</p></div>${memoBox(c.memo)}`);
    return pages;
  }
  pages.push(`<p class="kick">Partie · ${md(g.official)} › ${md(c.otitle)}</p><h2>${md(s.otitle)}</h2>${plain(s.title) !== plain(s.otitle) ? `<p class="clear">En clair : ${md(s.title)}</p>` : ''}<div class="box info"><b>Objectif du programme</b><p>${md(s.ogoal)}</p></div><p class="q">${md(s.question)}</p>${(s.lead || []).map(p => `<p>${md(p)}</p>`).join('')}`);
  s.parts.forEach(p => pages.push(`<h3>${md(p.title)}</h3>${p.body.map(b => `<p>${md(b)}</p>`).join('')}`));
  if (s.words?.length) pages.push(`<h3>Les mots à connaître</h3><dl>${s.words.map(w => `<div><dt>${md(w.term)}</dt><dd>${md(w.def)}</dd></div>`).join('')}</dl>`);
  if (s.method?.length) pages.push(`<h3>Comment faire</h3><ol class="steps">${s.method.map(m => `<li>${md(m)}</li>`).join('')}</ol>`);
  if (s.example) pages.push(`<h3>Une situation concrète</h3><p><b>${md(plain(s.example.title))}</b></p><p>${md(s.example.scene)}</p>${(s.example.reasoning || []).map(r => `<p>${md(r)}</p>`).join('')}<div class="box ok"><b>La bonne décision</b><p>${md(s.example.answer)}</p></div>`);
  pages.push(`<h3>À retenir avant la zone d’épreuve</h3>${s.trap ? `<div class="box warn"><b>Attention au piège</b><p>${md(s.trap)}</p></div>` : ''}${s.remember ? `<div class="box ok"><b>À retenir</b><p>${md(s.remember)}</p></div>` : ''}${s.law ? `<p class="law">Base légale : ${md(s.law)}</p>` : ''}`);
  return pages;
}
function openCourse(it, fromKey) {
  COURSE = { it, pages: coursePages(it), i: 0, fromKey }; mode = 'course'; drawCourse(); ui.course.hidden = false;
}
function drawCourse() {
  const C = COURSE, it = C.it, memo = it.type === 'chapGate' ? it.c.memo : it.s.memo;
  ui.course.querySelector('.cbody').innerHTML = C.pages[C.i];
  ui.course.querySelector('.cmemo').innerHTML = memo?.code ? `<b>Mnémo · ${md(memo.code)}</b> ${md(memo.text)}` : '';
  ui.course.querySelector('.cpage').textContent = `Page ${C.i + 1} / ${C.pages.length}`;
  ui.course.querySelector('.cbar i').style.width = ((C.i + 1) / C.pages.length * 100) + '%';
  const last = C.i === C.pages.length - 1; ui.course.querySelector('.cnext').textContent = last ? (C.fromKey ? 'Fermer (Entrée)' : 'Prendre la route (Entrée)') : 'Page suivante →';
  ui.course.querySelector('.cbody').scrollTop = 0;
}
function closeCourse() { ui.course.hidden = true; const it = COURSE.it; const was = COURSE.fromKey; COURSE = null; mode = 'drive';
  if (!was && ITEMS[ST.idx] === it) { advance(); if (it.type === 'secGate') { const n = sitCount(it.s); toast(`<b>Zone d’épreuve</b> · ${n} situation${n > 1 ? 's' : ''} pour « ${md(it.s.otitle)} »`, 'info'); } } }
const sitCount = s => ITEMS.filter(i => i.type === 'sit' && i.s === s).length;

// --- Décision ---
let DEC = null;
function openDecision(S) {
  const sc = S.sc; const order = [0, 1, 2].sort(() => Math.random() - .5); DEC = { S, order };
  ui.decide.querySelector('.dtitle').innerHTML = `<span>Situation · ${md(S.it.s.otitle)}</span>${md(sc.title)}`;
  ui.decide.querySelector('.dscene').innerHTML = md(sc.scene);
  ui.decide.querySelector('.dchoices').innerHTML = order.map((ci, k) => `<button data-k="${k}"><kbd>${k + 1}</kbd><span>${md(sc.choices[ci].t)}</span></button>`).join('');
  ui.decide.hidden = false; mode = 'decide'; TIME_SCALE = .06;
}
function choose(k) {
  if (!DEC) return; const ci = DEC.order[k]; const S = DEC.S; ui.decide.hidden = true; DEC = null; TIME_SCALE = 1; mode = 'resolve';
  S.choice = ci; S.good = ci === S.sc.ok; S.act = S.sc.choices[ci].act; S.phase = 'resolve'; S.rt = 0;
  startResolve(S);
}

// --- Explication ---
function openExplain(S) {
  mode = 'explain'; TIME_SCALE = 0; sfx.bad(); ST.errors++; save();
  const sc = S.sc, ch = sc.choices[S.choice];
  ui.explain.querySelector('.ebody').innerHTML = `
    <p class="ekick">${md(S.it.s.otitle)} · ${md(sc.title)}</p>
    <h2>${S.crash ? 'Collision évitée de justesse' : 'Ce n’était pas la bonne décision'}</h2>
    <div class="erow bad"><b>Ce que vous avez fait</b><p>${md(ch.did || plain(ch.t))}</p></div>
    <div class="erow ok"><b>Ce qu’il fallait faire</b><p>${md(sc.should)}</p></div>
    <div class="erow why"><b>Pourquoi</b><p>${md(sc.why)}</p></div>
    <div class="memo"><span>Mnémo</span><p>${md(sc.memo)}</p></div>`;
  ui.explain.hidden = false;
}
function replay() { ui.explain.hidden = true; const it = SIT.it; clearSit(SIT); SIT = null; TIME_SCALE = 1; mode = 'drive'; P.auto = null; P.v = 0; const z = it.sc.slot === 'int' ? it.z + 58 : it.z + 62; P.x = PL; P.z = z; P.h = 0; camSnap = true; }

/* =================== Résolution des situations =================== */
function prioActors(S) { return S.actors.filter(a => a.prio); }
function startResolve(S) {
  const good = S.good, act = S.act;
  P.auto = { path: S.pPath, s: S.pPath === S.pPathCur ? P.sAlong : P.sAlong, target: 7, stopAt: null };
  if (S.blinkSide) P.blink = S.blinkSide === 'L' ? -1 : 1;
  if (good) {
    sfx.good();
    if (act === 'wait' || act === 'creep') { prioActors(S).forEach(a => a.released = true); S.waiting = true; P.auto.stopAt = S.stopS; if (act === 'creep') P.auto.target = 1.1; }
    if (act === 'go') { P.auto.target = 7; S.yieldersAfter = true; }
    if (act === 'pull') { S.pulling = true; if (S.amb) { S.amb.released = true; S.amb.followBehind = null; } P.blink = 1; }
    S.queueGoT = S.actors.some(a => a.queue) ? 2.2 : null;
    toast(`<b>Bonne décision</b> · ${md(S.sc.should)}`, 'ok');
  } else {
    if (act === 'go' || act === 'rush') { prioActors(S).forEach(a => a.released = true); P.auto.target = act === 'rush' ? 13 : 7.5; if (S.actors.some(a => a.queue)) { P.auto.stopAt = S.pPath.sAtZ(S.it.z - 1); S.blockFail = true; } if (S.cross) S.cross.released = true; }
    else if (act === 'wait' || act === 'info') { P.auto.stopAt = Math.max(P.sAlong + 4, S.stopS); P.auto.target = 5; if (S.amb) { S.amb.released = true; S.amb.followBehind = null; S.ambStuck = true; } }
    else if (act === 'pull') { S.pulling = true; if (S.amb) { S.amb.released = true; S.amb.followBehind = null; } }
    S.failT = act === 'rush' ? 1.9 : (act === 'go' ? 3.4 : 2.6);
  }
}
function updateSit(S, dt) {
  S.t += dt;
  // approche : déclencheur de décision
  if (S.phase === 'approach') {
    if (S.teleport && !S.tp) { S.tp = true; fadeTo(() => { const p0 = S.pPath.at(0); P.x = p0.x; P.z = p0.z; P.h = S.pPath.yaw(.5); P.v = 0; camSnap = true; P.auto = { path: S.pPath, s: 0, target: 0, stopAt: .1 }; S.decT = 1.4; }); return; }
    if (S.decT !== undefined) { S.decT -= dt; if (S.decT <= 0 && mode === 'drive') { S.phase = 'decide'; openDecision(S); } return; }
    if (S.stopFirst) { if (!P.auto && P.sAlong > S.pPath.sAtZ(S.it.z + 40)) P.auto = { path: S.pPath, s: P.sAlong, target: 7, stopAt: S.stopS }; if (P.auto && P.auto.s > S.stopS - .6 && P.v < .3 && S.t > 1) { if (!S.stopT) S.stopT = 0; S.stopT += dt; if (S.stopT > 1.4 && mode === 'drive') { S.phase = 'decide'; openDecision(S); } } return; }
    if (onRoute() && P.sAlong >= S.decS && mode === 'drive') { P.auto = { path: S.pPath, s: P.sAlong, target: Math.min(P.v, 7), stopAt: null }; S.phase = 'decide'; openDecision(S); }
    return;
  }
  if (S.phase !== 'resolve') return;
  S.rt += dt;
  const A = P.auto;
  // feux et attentes
  if (S.waiting) { const all = prioActors(S).every(a => a.s >= a.clear || a.s >= a.path.len - .5); if (all && (S.queueGoT === null || S.queueGone)) { S.waiting = false; A.stopAt = null; A.target = 7; } }
  if (S.queueGoT !== null && S.queueGoT !== undefined) { S.queueGoT -= dt; if (S.queueGoT <= 0 && !S.queueGone) { S.actors.filter(a => a.queue).forEach(a => { a.released = true; }); S.queueGone = S.actors.filter(a => a.queue).every(a => a.mesh.position.z < S.it.z - 28); if (!S.queueGone) S.queueGoT = .01; } }
  if (S.good && A && A.s > S.clearS) S.actors.filter(a => !a.prio && !a.queue).forEach(a => a.released = true);
  if (S.pulling && S.good) { A.lat = Math.min(2.3, (A.lat || 0) + dt * 1.6); A.target = Math.max(0, A.target - dt * 4); if (S.amb && S.amb.mesh.position.z < car.position.z - 16) { S.pulling = false; A.target = 7; S.returning = true; P.blink = -1; } }
  if (S.returning) { A.lat = Math.max(0, A.lat - dt * 1.2); if (A.lat <= 0) { S.returning = false; P.blink = 0; } }
  if (!S.good && S.pulling) { A.lat = Math.min(2.3, (A.lat || 0) + dt * 1.6); A.target = 0; }
  if (S.ambStuck && S.amb) { const d = S.amb.mesh.position.z - car.position.z; S.amb.vmax = d < 9 ? 0 : 15; if (d < 9 && !S.honked) { S.honked = true; sfx.horn(); } }
  if (S.follow && A) { const d = car.position.distanceTo(S.follow.mesh.position); if (d < 11 && S.follow.s < S.follow.path.len - 1) A.target = Math.min(A.target, Math.max(0, (d - 7) * 1.5)); }
  if (S.signalTrick && S.good && A) { const p = A.path.at(A.s); const th = Math.atan2(-(p.z - S.it.z), p.x); P.blink = (p.z < S.it.z + 2 && th > .1 && th < 1.4) ? 1 : 0; }
  // échec : collision ou délai
  if (!S.good) {
    for (const a of S.actors) { if (a.kind === 'static' || a.kind === 'agent' || a.queue) continue; const d = a.mesh.position.distanceTo(car.position); if (d < a.rad + .2 && (a.prio || a.blocker)) { S.crash = true; sfx.horn(); openExplain(S); return; } }
    if (S.blockFail && A && A.s >= A.stopAt - .3 && !S.blkT) { S.blkT = 0; LIGHT_OVR.set(Math.round(S.it.z / CELL), S.light === 'off' ? 'off' : 'red'); S.actors.filter(a => a.blocker).forEach(a => { a.released = true; a.hold = a.path.sAtX(4.5); }); }
    if (S.blkT !== undefined) { S.blkT += dt; if (S.blkT > 2.4) { sfx.horn(); openExplain(S); return; } return; }
    S.failT -= dt; if (S.failT <= 0) { openExplain(S); return; }
    return;
  }
  // réussite : fin du chemin
  if (A && A.s >= S.endS) succeed(S);
}
function succeed(S) {
  ST.xp += 50; if (!ST.done.includes(S.sc.id)) ST.done.push(S.sc.id); save();
  const it = S.it; clearSitSoon(S); SIT = null; mode = 'drive'; P.blink = 0;
  const back = S.turnBack;
  const a = P.auto; P.auto = null; P.v = Math.min(P.v, 7);
  advance();
  if (back) fadeTo(() => { P.x = PL; P.z = it.z - 28; P.h = 0; camSnap = true; });
  burst(car.position.clone().add(V(0, 2, -3)), 120);
  toast(`<b>+50 XP</b> · ${md(S.sc.title)} réussie`, 'ok');
}
function clearSitSoon(S) { setTimeout(() => clearSit(S), 6000); LIGHT_OVR.delete(Math.round(S.it.z / CELL)); setSiren(false); }

function advance() { ST.idx++; save(); updateHud(); }

/* =================== Fondu =================== */
function fadeTo(fn) { const f = $('#fade'); f.classList.add('on'); setTimeout(() => { fn(); setTimeout(() => f.classList.remove('on'), 120); }, 380); }

/* =================== Itinéraire / suivi =================== */
const onRoute = () => Math.abs(P.x) < 5.5 && Math.cos(P.h) > .5;
function current() { return ITEMS[ST.idx] || null; }

/* =================== HUD =================== */
function updateHud() {
  const it = current(); const sec = it && it.s ? it.s : null;
  $('#hPart').textContent = it ? it.g.official : 'Parcours terminé';
  $('#hChap').textContent = it ? it.c.otitle : '';
  $('#hSec').textContent = it ? (it.type === 'chapGate' ? 'Présentation du chapitre' : sec.otitle) : '';
  if (sec) { const list = ITEMS.filter(i => i.type === 'sit' && i.s === sec); const done = list.filter(i => ST.done.includes(i.sc.id)).length; $('#hZone').textContent = `Zone d’épreuve : ${done} / ${list.length} situations`; $('#hBar').style.width = (list.length ? done / list.length * 100 : 0) + '%'; } else { $('#hZone').textContent = ''; $('#hBar').style.width = '0%'; }
  $('#hXp').textContent = ST.xp + ' XP';
  const total = ITEMS.filter(i => i.type === 'sit').length; $('#hAll').textContent = `${ST.done.length} / ${total} situations du chapitre`;
}
function objective() { const it = current(); if (!it) return null; return { z: it.z, label: it.type === 'sit' ? 'Situation' : it.type === 'secEnd' ? 'Fin du sous-chapitre' : 'Portique de cours' }; }

/* =================== Entrées =================== */
const keys = {};
addEventListener('keydown', e => {
  ac(); startEngine(); const k = e.key.toLowerCase();
  if (!$('#start').hidden) { if (k === 'enter' || k === ' ') startGame(); return; }
  if (!$('#plan').hidden) { if (k === 'escape' || k === 'm') togglePlan(false); return; }
  if (mode === 'course') { if (k === 'enter') { if (COURSE.i < COURSE.pages.length - 1 && !e.shiftKey && false) {} closeCourse(); } else if (k === 'arrowright' || k === ' ') { if (COURSE.i < COURSE.pages.length - 1) { COURSE.i++; drawCourse(); } else closeCourse(); } else if (k === 'arrowleft') { if (COURSE.i > 0) { COURSE.i--; drawCourse(); } } e.preventDefault(); return; }
  if (mode === 'decide') { if (['1', '2', '3'].includes(k)) choose(+k - 1); e.preventDefault(); return; }
  if (mode === 'explain') { if (k === 'enter') replay(); else if (k === 'c') { const sec = SECS.find(s => s.s === SIT.it.s); ui.explain.hidden = true; openCourse(sec, true); COURSE.after = 'explain'; } e.preventDefault(); return; }
  if (k === 'c') { const it = current(); const sec = it && (it.s ? SECS.find(s => s.s === it.s) : null); if (sec) openCourse(sec, true); else if (it && it.type === 'chapGate') openCourse(it, true); return; }
  if (k === 'q') { P.blink = P.blink === -1 ? 0 : -1; return; }
  if (k === 'e') { P.blink = P.blink === 1 ? 0 : 1; return; }
  if (k === 'm') { togglePlan(true); return; }
  if (k === 'n') { muted = !muted; toast(muted ? 'Son coupé' : 'Son activé'); return; }
  if (k === 'h') { $('#keys').classList.toggle('hide'); return; }
  if (k === 'r') { returnToRoute(); return; }
  if (k === 'v') { camMode = (camMode + 1) % 2; return; }
  keys[k] = true; if (e.key.startsWith('Arrow') || k === ' ') e.preventDefault();
});
addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });
addEventListener('blur', () => Object.keys(keys).forEach(k => keys[k] = false));
ui.decide.addEventListener('click', e => { const b = e.target.closest('[data-k]'); if (b) choose(+b.dataset.k); });
ui.course.querySelector('.cnext').onclick = () => { if (COURSE.i < COURSE.pages.length - 1) { COURSE.i++; drawCourse(); } else closeCourse(); };
ui.course.querySelector('.cprev').onclick = () => { if (COURSE.i > 0) { COURSE.i--; drawCourse(); } };
const _close = closeCourse;
ui.explain.querySelector('.ereplay').onclick = () => replay();
ui.explain.querySelector('.ecourse').onclick = () => { const sec = SECS.find(s => s.s === SIT.it.s); ui.explain.hidden = true; openCourse(sec, true); COURSE.after = 'explain'; };
function returnToRoute() { const it = current(); if (!it) return; if (SIT) { replay(); return; } P.x = PL; P.z = it.z + (it.type === 'sit' ? 60 : 25); P.h = 0; P.v = 0; camSnap = true; toast('Retour sur l’itinéraire'); }

/* =================== Plan =================== */
function togglePlan(on) {
  if (on) {
    $('#planList').innerHTML = DATA.groups.map(g => `<section><h3><small>PARTIE</small>${md(g.official)}</h3>${g.chapters.map(cid => CH[cid]).filter(Boolean).map(c => { const ready = CHAPTERS_READY.includes(c.id); return `<div class="pc ${ready ? '' : 'locked'}"><h4>${md(c.otitle)} ${ready ? '' : '<em>en construction</em>'}</h4>${ready ? c.sections.map(s => { const gi = ITEMS.findIndex(i => i.type === 'secGate' && i.s === s); const sits = ITEMS.filter(i => i.type === 'sit' && i.s === s); const d = sits.filter(i => ST.done.includes(i.sc.id)).length; const reach = gi <= ST.idx; return `<button data-gi="${gi}" ${reach ? '' : 'disabled'} class="${d === sits.length && sits.length ? 'ok' : ''}"><span>${d}/${sits.length}</span>${md(s.otitle)}</button>`; }).join('') : ''}</div>`; }).join('')}</section>`).join('');
    $('#planList').onclick = e => { const b = e.target.closest('[data-gi]'); if (!b || b.disabled) return; const gi = +b.dataset.gi; if (SIT) { clearSit(SIT); SIT = null; } ST.idx = gi; save(); P.x = PL; P.z = ITEMS[gi].z + 30; P.h = 0; P.v = 0; P.auto = null; camSnap = true; mode = 'drive'; TIME_SCALE = 1; togglePlan(false); updateHud(); };
  }
  $('#plan').hidden = !on;
}

/* =================== Mini-carte =================== */
function drawMinimap() {
  const c = $('#minimap'); const x = c.getContext('2d'); const MM = c.width, sc = MM / 230, cx = MM / 2, cy = MM / 2;
  x.fillStyle = '#e4ecd9'; x.fillRect(0, 0, MM, MM); const [ci, cj] = chunkAt(P.x, P.z);
  for (let j = cj - 2; j <= cj + 2; j++) for (let i = ci - 2; i <= ci + 2; i++) { const t = cellType(i, j); x.fillStyle = t === 'park' ? '#9fcf8a' : t === 'plaza' ? '#e9dcc2' : '#cfc7b8'; x.fillRect(cx + (i * CELL + RW + 4 - P.x) * sc, cy + (j * CELL + CW + 3 - P.z) * sc, (CELL - 2 * RW - 8) * sc, (CELL - 2 * CW - 6) * sc); }
  x.strokeStyle = '#8d949b'; x.lineWidth = 2 * RW * sc; for (let i = ci - 3; i <= ci + 3; i++) { x.beginPath(); x.moveTo(cx + (i * CELL - P.x) * sc, 0); x.lineTo(cx + (i * CELL - P.x) * sc, MM); x.stroke(); }
  x.lineWidth = 2 * CW * sc; for (let j = cj - 3; j <= cj + 3; j++) { x.beginPath(); x.moveTo(0, cy + (j * CELL - P.z) * sc); x.lineTo(MM, cy + (j * CELL - P.z) * sc); x.stroke(); }
  x.strokeStyle = '#1d5cb0'; x.lineWidth = 3; x.beginPath(); x.moveTo(cx + (PL - P.x) * sc, 0); x.lineTo(cx + (PL - P.x) * sc, MM); x.stroke();
  ITEMS.forEach((it, i) => { if (i < ST.idx || i > ST.idx + 6) return; const yy = cy + (it.z - P.z) * sc; if (yy < -6 || yy > MM + 6) return; x.fillStyle = it.type === 'sit' ? '#f2a516' : '#39c14a'; x.beginPath(); x.arc(cx + (PL - P.x) * sc, yy, i === ST.idx ? 5 : 3.5, 0, 7); x.fill(); });
  x.save(); x.translate(cx, cy); x.rotate(-P.h); x.fillStyle = '#c8102e'; x.beginPath(); x.moveTo(0, -8); x.lineTo(5.5, 6); x.lineTo(-5.5, 6); x.closePath(); x.fill(); x.restore();
}

/* =================== Boucle =================== */
const clock = new THREE.Clock();
let camSnap = true, camMode = 0; const camPos = V(0, 3, 6), camLook = V(0, 1, 0);
let started = false, hudT = 0, FR = 0;
P.sAlong = 0;
function step() {
  requestAnimationFrame(step);
  const rdt = Math.min(clock.getDelta(), window.__DTMAX || .05), dt = rdt * TIME_SCALE, t = clock.elapsedTime;
  const it = current();
  // --- pilotage ---
  let thr = 0;
  if (P.auto && mode !== 'explain') {
    const A = P.auto; let target = A.target;
    if (A.stopAt !== null && A.stopAt !== undefined) { const d = A.stopAt - A.s; target = d <= .05 ? 0 : Math.min(target, Math.sqrt(2 * 3.2 * Math.max(0, d))); }
    // sécurité : ne pas percuter un acteur devant pendant une bonne réponse
    if (SIT && SIT.good) for (const a of SIT.actors) { if (a.kind === 'agent') continue; const ahead = a.mesh.position.clone().sub(car.position); const fwd = V(-Math.sin(P.h), 0, -Math.cos(P.h)); const along = ahead.dot(fwd), lat = Math.abs(ahead.x * fwd.z - ahead.z * fwd.x); if (along > 0 && along < a.rad + 4.5 && lat < 2.1) target = Math.min(target, 0); }
    P.v += (target - P.v) * Math.min(1, dt * (target < P.v ? 3 : 1.4)); A.s += P.v * dt;
    const p = A.path.at(A.s); const yaw = A.path.yaw(A.s); const lat = A.lat || 0;
    P.x = p.x + Math.cos(yaw) * lat; P.z = p.z - Math.sin(yaw) * lat; P.h = yaw; P.steer *= .9; P.sAlong = A.s; thr = target > P.v ? .5 : 0;
  } else if (started && mode === 'drive') {
    const up = keys['w'] || keys['arrowup'], dn = keys['s'] || keys['arrowdown'];
    const left = keys['a'] || keys['arrowleft'], right = keys['d'] || keys['arrowright'];
    if (up) { P.v += (P.v < 0 ? 9 : 3.6 * (1 - P.v / VMAX)) * dt; thr = 1; }
    if (dn) { if (P.v > .3) P.v -= 8 * dt; else P.v = Math.max(-3, P.v - 2.5 * dt); }
    if (keys[' ']) P.v *= Math.max(0, 1 - 4 * dt);
    if (!up && !dn) P.v *= 1 - .35 * dt;
    if (Math.abs(P.v) < .02 && !up && !dn) P.v = 0;
    const steerT = (left ? 1 : 0) - (right ? 1 : 0); const maxSt = .55 - Math.min(.35, Math.abs(P.v) / VMAX * .35);
    P.steer += (steerT * maxSt - P.steer) * Math.min(1, dt * 5);
    const nh = P.h + P.v / 2.7 * Math.tan(P.steer) * dt;
    const nx = P.x - Math.sin(nh) * P.v * dt, nz = P.z - Math.cos(nh) * P.v * dt;
    if (!hitsWorld(nx, nz, 1.0)) { P.x = nx; P.z = nz; P.h = nh; } else { P.v = -P.v * .2; sfx.tick(); }
    // trajectoire de référence pour les situations : position le long de l'avenue
    P.sAlong = SIT ? SIT.pPath.sAtZ(P.z) : 0;
    // feu rouge franchi hors situation
    if (onRoute() && !SIT) { const zc = Math.round(P.z / CELL) * CELL, line = zc + CW + 4.6; if (P.prevZ !== undefined && P.prevZ - P.z < 3 && P.prevZ > line && P.z <= line && P.x > 0) { const l = lightAt('av', t, Math.round(zc / CELL)); if (l === 'red') redLightFault(); } }
    P.prevZ = P.z;
  }
  // --- situations ---
  if (it && mode === 'drive' && !SIT) {
    if ((it.type === 'chapGate' || it.type === 'secGate') && onRoute() && P.z < it.z + 3 && P.z > it.z - 40) { P.v = 0; openCourse(it, false); }
    else if (it.type === 'secEnd' && P.z < it.z + 3 && P.z > it.z - 40) { ST.secDone.push(it.s.id); ST.xp += 100; advance(); sfx.done(); applause(); burst(car.position.clone().add(V(0, 2, -4)), 400); toast(`<b>Sous-chapitre réussi</b> · ${md(it.s.otitle)} · +100 XP`, 'ok'); }
    else if (it.type === 'sit' && P.z < it.z + 95 && P.z > it.z - 25) { SIT = buildSit(it); if (SIT.siren) setSiren(true); }
  }
  if (SIT) updateSit(SIT, dt);
  if (SIT) SIT.actors.forEach(a => stepActor(a, dt));
  if (SIT && SIT.siren && SIT.amb) { /* sirène déjà active */ }
  // --- monde ---
  if (t - colT > .5) { colT = t; COLL = colliders(); }
  updateChunks(P.x, P.z, camSnap ? 30 : 1); updateLights(t);
  updateTraffic(dt, t); updateWalkers(dt); updateConf(rdt);
  clouds.forEach(sp => { sp.userData.ox += rdt * 1.2; if (sp.userData.ox > 450) sp.userData.ox -= 900; sp.position.set(P.x + sp.userData.ox, sp.userData.y, P.z + sp.userData.oz); });
  mountains.position.set(0, 0, P.z);
  sunL.position.set(P.x + 30, 52, P.z + 20); sunL.target.position.set(P.x, 0, P.z - 8);
  // --- voiture ---
  car.position.set(P.x, 0, P.z); car.rotation.y = P.h;
  car.userData.wheels.forEach(w => w.rotation.x -= P.v * dt / .36); car.userData.front.forEach(f => f.rotation.y = P.steer);
  blinkT += rdt; const on = Math.floor(blinkT * 2.6) % 2 === 0; car.userData.blink.L.forEach(b => b.material.color.set(P.blink === -1 && on ? '#ffb020' : '#5a3a10')); car.userData.blink.R.forEach(b => b.material.color.set(P.blink === 1 && on ? '#ffb020' : '#5a3a10'));
  if (P.blink && on !== P.lastOn) { if (on) sfx.tick(); } P.lastOn = on;
  updateEngine(P.v, thr);
  // --- caméra ---
  const fwd = V(-Math.sin(P.h), 0, -Math.cos(P.h));
  let wantPos, wantLook;
  if (mode === 'explain' && SIT) { const f = SIT.focus.clone().lerp(car.position, .35); wantPos = f.clone().add(V(0, 26, 9)); wantLook = f; }
  else if ((mode === 'decide' || (SIT && SIT.phase === 'resolve')) && SIT) { if (SIT.cam) { wantPos = SIT.cam.pos; wantLook = SIT.cam.look; } else { wantPos = car.position.clone().addScaledVector(fwd, -10).add(V(-1.5, 6.5, 0)); wantLook = SIT.focus.clone().lerp(car.position, .3).add(V(0, .5, 0)); } }
  else if (SIT && SIT.cam && SIT.phase !== 'approach') { wantPos = SIT.cam.pos; wantLook = SIT.cam.look; }
  else if (camMode === 1) { wantPos = car.position.clone().addScaledVector(fwd, .3).add(V(0, 1.15, 0)); wantLook = car.position.clone().addScaledVector(fwd, 12).add(V(0, 1, 0)); }
  else { wantPos = car.position.clone().addScaledVector(fwd, -7.2).add(V(0, 2.6, 0)); wantLook = car.position.clone().addScaledVector(fwd, 6).add(V(0, 1.1, 0)); }
  if (camSnap) { camPos.copy(wantPos); camLook.copy(wantLook); camSnap = false; } else { const k = 1 - Math.exp(-rdt * (mode === 'explain' ? 2 : 4)); camPos.lerp(wantPos, k); camLook.lerp(wantLook, k); }
  camera.position.copy(camPos); camera.lookAt(camLook);
  // --- HUD ---
  const kmh = Math.abs(P.v) * 3.6; $('#spd').textContent = Math.round(kmh); $('#spdWrap').classList.toggle('over', kmh > 52);
  $('#blL').classList.toggle('on', P.blink === -1 && on); $('#blR').classList.toggle('on', P.blink === 1 && on);
  if (t - hudT > .35) { hudT = t; drawMinimap(); const ob = objective(); if (ob) { const d = Math.max(0, P.z - ob.z); $('#obj').textContent = `${ob.label} · ${d < 1000 ? Math.round(d) + ' m' : (d / 1000).toFixed(1) + ' km'}`; } }
  if (!window.__NORENDER) renderer.render(scene, camera); FR++;
}
function redLightFault() {
  mode = 'explain'; TIME_SCALE = 0; sfx.bad(); P.v = 0;
  ui.explain.querySelector('.ebody').innerHTML = `<p class="ekick">Règle de base · Priorités</p><h2>Feu rouge franchi</h2>
    <div class="erow bad"><b>Ce que vous avez fait</b><p>Vous avez franchi la ligne d’arrêt alors que votre feu était **rouge**.</p></div>
    <div class="erow ok"><b>Ce qu’il fallait faire</b><p>S’arrêter **avant la ligne** et attendre le vert.</p></div>
    <div class="erow why"><b>Pourquoi</b><p>Quand les feux fonctionnent et concernent votre voie, ils règlent l’ordre de passage. Seul un **agent** peut passer avant eux.</p></div>
    <div class="memo"><span>Mnémo</span><p>P–F–S–M–R : **P**olice, puis **F**eux.</p></div>`.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  ui.explain.hidden = false; RED = true;
}
let RED = false;
ui.explain.addEventListener('click', () => {});
const _replay = replay;
replay = function () { if (RED) { RED = false; ui.explain.hidden = true; mode = 'drive'; TIME_SCALE = 1; P.z += 6; P.v = 0; camSnap = true; return; } _replay(); };

function startGame() { $('#start').hidden = true; started = true; ac(); startEngine(); $('#keys').classList.add('hide'); toast('W accélérer · S freiner · A / D tourner · C : revoir le cours'); }
addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
$('#startBtn').onclick = startGame; $('#planBtn').onclick = () => togglePlan(true); $('#planClose').onclick = () => togglePlan(false);
$('#resetBtn').onclick = () => { if (!confirmArm($('#resetBtn'))) return; ST = { idx: 0, xp: 0, done: [], secDone: [], errors: 0 }; save(); if (SIT) { clearSit(SIT); SIT = null; } P.x = PL; P.z = -20; P.h = 0; P.v = 0; P.auto = null; camSnap = true; togglePlan(false); updateHud(); };
function confirmArm(b) { if (b.dataset.arm) { delete b.dataset.arm; b.textContent = 'Recommencer depuis le début'; return true; } b.dataset.arm = 1; b.textContent = 'Cliquez encore pour confirmer'; setTimeout(() => { delete b.dataset.arm; b.textContent = 'Recommencer depuis le début'; }, 3000); return false; }

// départ : devant l'élément en cours
{ const it = current(); if (it) { P.z = it.z + (it.type === 'sit' ? 60 : 30); } }
humansReady.then(() => { for (let i = 0; i < 10; i++) { const h = human([['#7a8fa6', '#3b4250'], ['#b5544a', '#2f3640'], ['#e8e2d4', '#5a6b4f'], ['#3f6b52', '#2b2f36'], ['#c9a46a', '#3a4a66']][i % 5]); scene.add(h); walkers.push(h); } });
updateChunks(P.x, P.z, 30); updateHud();
$('#loading').hidden = true; $('#start').hidden = false;
step();
// accès de test
window.__G = { P, ST, ITEMS, get SIT() { return SIT; }, get mode() { return mode; }, choose, replay: () => replay(), frames: () => FR, rf: () => { FR = 0; }, snap: () => { camSnap = true; }, closeCourse: () => closeCourse(), DEC: () => DEC };
