// Situations de conduite du chapitre « Priorités » (O11).
// Chaque sous-chapitre (sec) a des situations couvrant chacun de ses points officiels (pt = index du point).
// slot : 'int' = à un carrefour, 'mid' = au milieu d'un pâté de maisons.
// choices[].act : ce que fait la voiture une fois le choix fait ('go' passer, 'wait' céder puis passer, 'pull' se serrer à droite, 'creep' avancer très lentement, 'info' simple réponse).
// did : « Ce que vous avez fait » ; should : « Ce qu'il fallait faire » ; why : « Pourquoi ».
export const SCENARIOS = {
  O11: {
    hierarchie: [
      { id: 'h1', pt: 0, slot: 'int', kind: 'agent', title: 'Un agent au carrefour',
        scene: 'Votre feu est **rouge**, mais l’agent de police placé au milieu du carrefour vous fait clairement signe d’avancer.',
        choices: [
          { t: 'Je reste arrêté : le feu est rouge.', act: 'wait', did: 'Vous êtes resté arrêté parce que le feu était rouge.' },
          { t: 'J’avance prudemment, comme l’agent l’indique.', act: 'go' },
          { t: 'J’accélère fort pour libérer vite le carrefour.', act: 'rush', did: 'Vous avez accéléré brusquement dans le carrefour.' }],
        ok: 1, should: 'Suivre le geste de l’agent et avancer **prudemment**.',
        why: 'L’agent voit la situation en direct : ses instructions passent **avant les feux**. Mais une autorisation n’est jamais une obligation de foncer : les autres usagers n’ont peut-être pas compris son geste.',
        memo: 'P–F–S–M–R : **P**olice avant **F**eux.' },
      { id: 'h2', pt: 0, slot: 'int', kind: 'lightsOffYield', title: 'Feux éteints',
        scene: 'Les feux du carrefour sont **éteints**. Sur votre route, un panneau triangulaire pointe vers le bas : **« Cédez le passage »**. Une voiture arrive de votre **gauche**.',
        choices: [
          { t: 'Je passe : la voiture vient de gauche, j’ai la priorité de droite.', act: 'go', did: 'Vous êtes passé en appliquant la priorité de droite.' },
          { t: 'Je cède le passage à la voiture, puis je passe.', act: 'wait' },
          { t: 'J’attends que les feux se rallument.', act: 'info', did: 'Vous avez attendu des feux qui ne fonctionnaient pas.' }],
        ok: 1, should: 'Appliquer le **panneau** : céder le passage, même au véhicule de gauche.',
        why: 'Quand les feux sont éteints, on descend d’un cran dans la hiérarchie : ce sont les **panneaux** qui commandent. Le panneau « Cédez le passage » est plus fort que la règle générale de la priorité de droite.',
        memo: 'P–F–S–M–R : sans **F**eux, on lit les **S**ignaux.' },
      { id: 'h3', pt: 1, slot: 'int', kind: 'yieldLeft', title: 'Le panneau change la règle',
        scene: 'Feux **éteints**. Votre route porte un panneau **« Cédez le passage »** et une ligne pointillée blanche au sol. Une voiture arrive de votre **gauche** sur l’autre route.',
        choices: [
          { t: 'Je passe : celui de gauche doit me céder.', act: 'go', did: 'Vous êtes passé devant la voiture venant de gauche.' },
          { t: 'Je ralentis et je lui cède le passage.', act: 'wait' },
          { t: 'Je klaxonne pour qu’elle s’arrête.', act: 'go', did: 'Vous avez klaxonné et forcé le passage.' }],
        ok: 1, should: 'Céder le passage à la voiture, **même si elle vient de gauche**.',
        why: 'La priorité de droite n’est qu’un « filet de sécurité » : elle ne s’applique que si **rien d’autre** n’est indiqué. Ici, le panneau et la ligne au sol **annulent** la règle générale à cet endroit précis.',
        memo: 'P–F–S–M–R : les **S**ignaux et **M**arquages battent les **R**ègles générales.' },
      { id: 'h4', pt: 2, slot: 'int', kind: 'blockedGreen', title: 'Vert, mais bouché',
        scene: 'Votre feu est **vert**. Mais juste après le carrefour, une file de voitures est **arrêtée** et ne laisse aucune place pour vous.',
        choices: [
          { t: 'J’y vais : c’est vert.', act: 'go', did: 'Vous êtes entré dans le carrefour alors que la sortie était bouchée.' },
          { t: 'Je reste avant la ligne jusqu’à ce que la sortie se libère.', act: 'wait' },
          { t: 'Je m’avance au milieu du carrefour pour être prêt.', act: 'go', did: 'Vous vous êtes avancé au milieu du carrefour.' }],
        ok: 1, should: 'Attendre **avant la ligne** tant que vous ne pouvez pas ressortir du carrefour.',
        why: 'La méthode : la règle la plus forte (ici le feu vert) **autorise**, elle n’oblige pas. Il faut ensuite vérifier que votre mouvement reste possible : arrêté au milieu, vous bloqueriez tout le monde au changement de feu.',
        memo: 'Je cherche la règle la plus forte, **puis** je vérifie que mon mouvement est possible.' }
    ],
    intersections: [
      { id: 'i1', pt: 0, slot: 'int', kind: 'rightCar', title: 'Personne ne règle le carrefour',
        scene: 'Carrefour **sans agent**, feux **éteints**, **aucun panneau**. Une voiture arrive de votre **droite**.',
        choices: [
          { t: 'Je passe : je suis sur la plus grande route.', act: 'go', did: 'Vous êtes passé devant la voiture venant de droite.' },
          { t: 'Je lui cède le passage, puis je passe.', act: 'wait' },
          { t: 'Je fais un appel de phares et je passe.', act: 'go', did: 'Vous avez fait un appel de phares et forcé le passage.' }],
        ok: 1, should: 'Céder à la voiture qui vient de **votre droite**.',
        why: 'Sans police, feu ni panneau, la **règle générale** s’applique : celui qui a quelqu’un à sa droite attend. La largeur de la route ne compte pas.',
        memo: 'D–T–L : qui vient de ma **D**roite ?' },
      { id: 'i2', pt: 0, slot: 'int', kind: 'rightCarLate', title: 'Arrivé le premier',
        scene: 'Feux **éteints**, aucun panneau. Vous arrivez **le premier**. Une voiture arrive un peu après vous, **de votre droite**.',
        choices: [
          { t: 'Je passe : je suis arrivé le premier.', act: 'go', did: 'Vous êtes passé parce que vous étiez arrivé le premier.' },
          { t: 'Je la laisse passer, puis je passe.', act: 'wait' },
          { t: 'Je m’arrête et j’attends qu’elle me fasse signe.', act: 'info', did: 'Vous avez attendu un geste au lieu d’appliquer la règle.' }],
        ok: 1, should: 'La laisser passer : elle vient de votre **droite**.',
        why: 'Ce n’est **pas une course** : l’ordre d’arrivée ne compte jamais. Seule la règle qui s’applique décide, ici la priorité de droite.',
        memo: 'D–T–L : la **D**roite d’abord, quel que soit l’ordre d’arrivée.' },
      { id: 'i3', pt: 1, slot: 'int', kind: 'leftTurn', title: 'Tourner à gauche',
        scene: 'Vous voulez **tourner à gauche**. Une voiture arrive **en face** de vous et va tout droit.',
        choices: [
          { t: 'Je tourne tout de suite, j’ai mis mon clignotant.', act: 'go', did: 'Vous avez tourné devant la voiture qui arrivait en face.' },
          { t: 'Je la laisse passer, puis je tourne.', act: 'wait' },
          { t: 'Je tourne en accélérant pour passer avant elle.', act: 'go', did: 'Vous avez accéléré pour couper sa trajectoire.' }],
        ok: 1, should: 'Céder le passage à la voiture d’en face, **puis** tourner.',
        why: 'En tournant à gauche, votre trajectoire **coupe** celle du véhicule qui arrive en face. Celui qui bifurque devant l’autre attend que le chemin soit libre. Le clignotant annonce, il ne donne aucun droit.',
        memo: 'D–T–L : qui coupe ma **T**rajectoire ?' },
      { id: 'i4', pt: 2, slot: 'int', kind: 'blockedQueue', title: 'Ne pas bloquer le carrefour',
        scene: 'Feux **éteints**, aucun panneau, personne à votre droite. Mais après le carrefour, une **file arrêtée** occupe votre voie.',
        choices: [
          { t: 'Je m’engage : c’est mon tour.', act: 'go', did: 'Vous vous êtes engagé alors que vous ne pouviez pas ressortir.' },
          { t: 'J’attends avant le carrefour que la file avance.', act: 'wait' },
          { t: 'Je m’engage à moitié pour garder ma place.', act: 'go', did: 'Vous vous êtes engagé à moitié dans le carrefour.' }],
        ok: 1, should: 'Attendre **avant** le carrefour, jusqu’à pouvoir le traverser entièrement.',
        why: 'Même quand c’est votre tour, on n’entre que si l’on peut **sortir complètement**. Un véhicule arrêté au milieu empêche tous les autres de passer.',
        memo: 'D–T–L : puis-je **L**ibérer l’intersection ?' }
    ],
    giratoires: [
      { id: 'g1', pt: 0, slot: 'int', kind: 'roundEntry', title: 'Entrer dans le rond-point',
        scene: 'Vous arrivez à un **rond-point** (panneau rond bleu à flèches). Une voiture y circule déjà et arrive **de votre gauche**.',
        choices: [
          { t: 'J’entre : je viens de sa droite, j’ai la priorité.', act: 'go', did: 'Vous êtes entré devant la voiture qui circulait déjà.' },
          { t: 'Je la laisse passer, puis j’entre.', act: 'wait' },
          { t: 'Je m’arrête dans le rond-point pour la laisser passer.', act: 'go', did: 'Vous vous êtes engagé puis arrêté dans l’anneau.' }],
        ok: 1, should: 'Céder à ceux qui sont **déjà dans le rond-point** et qui arrivent de **gauche**.',
        why: 'Ceux qui tournent déjà ne doivent pas être bloqués, sinon le rond-point se remplit et se paralyse. On n’entre que dans un espace suffisant.',
        memo: 'C–O–S : **C**éder à l’entrée.' },
      { id: 'g2', pt: 1, slot: 'int', kind: 'roundSignal', title: 'Le bon clignotant',
        scene: 'Vous entrez dans le rond-point et vous voulez prendre la **sortie tout droit**, la deuxième.',
        choices: [
          { t: 'Clignotant gauche en entrant, puis clignotant droit avant la sortie.', act: 'info', did: 'Vous avez mis le clignotant gauche en entrant.' },
          { t: 'Pas de clignotant en entrant ; clignotant droit après la sortie qui précède la mienne.', act: 'go' },
          { t: 'Clignotant droit dès l’entrée et jusqu’à la sortie.', act: 'info', did: 'Vous avez mis le clignotant droit dès l’entrée.' }],
        ok: 1, should: 'Aucun clignotant en entrant ; **clignotant droit** juste après la sortie qui précède la vôtre.',
        why: 'Le clignotant annonce un **changement**. En entrant, vous suivez simplement le sens du rond-point. Le clignotant droit, mis au bon moment, dit aux autres : « je sors à la prochaine ».',
        memo: 'C–O–S : **S**ortir en annonçant à droite.' },
      { id: 'g3', pt: 2, slot: 'int', kind: 'roundExitPed', title: 'Sortir du rond-point',
        scene: 'Vous allez sortir du rond-point. Sur le **passage piéton** de la sortie, un piéton s’engage. Un **cycliste** longe le bord à votre droite.',
        choices: [
          { t: 'Je sors : dans le rond-point, j’avais la priorité.', act: 'go', did: 'Vous êtes sorti sans laisser passer le piéton.' },
          { t: 'Je contrôle à droite, je laisse passer le cycliste et le piéton, puis je sors.', act: 'wait' },
          { t: 'Je klaxonne pour prévenir et je sors.', act: 'go', did: 'Vous avez klaxonné et forcé la sortie.' }],
        ok: 1, should: 'Contrôler **à droite** et l’angle mort, laisser passer cycliste et piéton, puis sortir.',
        why: 'À l’entrée, le danger vient de gauche ; à la **sortie**, il vient souvent de **droite** : cyclistes au bord et piétons sur le passage.',
        memo: 'C–O–S : **O**bserver avant de sortir.' }
    ],
    'entrees-sorties': [
      { id: 'e1', pt: 0, slot: 'mid', kind: 'drivewayLeft', title: 'Sortir d’une cour',
        scene: 'Vous sortez d’une **cour privée** pour rejoindre l’avenue. Une voiture arrive sur l’avenue, **de votre gauche**.',
        choices: [
          { t: 'Je sors : elle vient de gauche, j’ai la priorité de droite.', act: 'go', did: 'Vous êtes sorti devant la voiture en appliquant la priorité de droite.' },
          { t: 'Je la laisse passer, puis je m’insère.', act: 'wait' },
          { t: 'Je sors vite avant qu’elle arrive.', act: 'go', did: 'Vous êtes sorti en vitesse devant elle.' }],
        ok: 1, should: 'Céder le passage à **tous** les usagers de l’avenue, quelle que soit leur direction.',
        why: 'Une sortie de propriété n’est **pas une intersection** : vous venez d’un accès de rang inférieur. Le trafic établi ne s’attend pas à vous voir surgir ; c’est à vous de vous adapter. La priorité de droite ne s’applique pas.',
        memo: 'S.T.O.P. : **S**ortie de **T**errain, les **A**utres **O**nt **P**riorité.' },
      { id: 'e2', pt: 1, slot: 'mid', kind: 'drivewayPed', title: 'Le trottoir d’abord',
        scene: 'Vous sortez d’un garage. Avant la route, vous traversez le **trottoir** : un piéton y marche, venant de votre droite.',
        choices: [
          { t: 'Je regarde seulement la route et je sors.', act: 'go', did: 'Vous avez regardé la route sans voir le piéton.' },
          { t: 'Je laisse passer le piéton, puis je contrôle la route dans les deux sens.', act: 'wait' },
          { t: 'Je klaxonne pour qu’il s’écarte.', act: 'go', did: 'Vous avez klaxonné pour faire reculer le piéton.' }],
        ok: 1, should: 'Laisser passer le **piéton**, puis contrôler cyclistes et véhicules **des deux côtés**.',
        why: 'En sortant, vous traversez d’abord le trottoir, puis parfois une bande cyclable : les premiers usagers que vous croisez sont les **piétons et les cyclistes**.',
        memo: 'S.T.O.P. : en sortant, **tous** les autres passent.' },
      { id: 'e3', pt: 2, slot: 'mid', kind: 'drivewayHedge', title: 'Une haie cache la vue',
        scene: 'Vous sortez d’une cour. Une **haie haute** vous cache la vue sur l’avenue.',
        choices: [
          { t: 'Je sors normalement, je verrai bien.', act: 'go', did: 'Vous êtes sorti normalement sans rien voir.' },
          { t: 'J’avance très lentement, centimètre par centimètre, jusqu’à voir.', act: 'creep' },
          { t: 'Je klaxonne et je sors vite.', act: 'go', did: 'Vous avez klaxonné puis êtes sorti vite.' }],
        ok: 1, should: 'Avancer **très lentement** pour laisser aux autres le temps de vous voir, et ne s’insérer que si personne ne doit freiner.',
        why: 'Quand la visibilité est mauvaise, vous ne voyez pas les autres et ils ne vous voient pas. Avancer centimètre par centimètre vous laisse le temps de voir et d’être vu.',
        memo: 'S.T.O.P. : je sors sans obliger personne à **freiner**.' }
    ],
    retrecissements: [
      { id: 'r1', pt: 0, slot: 'mid', kind: 'narrowSign', title: 'Panneau de passage étroit',
        scene: 'Un panneau bleu vous donne la **priorité** dans le passage étroit (grande flèche blanche vers vous). Mais une voiture d’en face est **déjà engagée** dans le passage.',
        choices: [
          { t: 'J’entre : le panneau me donne la priorité.', act: 'go', did: 'Vous êtes entré alors qu’une voiture était déjà engagée.' },
          { t: 'J’attends qu’elle ait traversé, puis je passe.', act: 'wait' },
          { t: 'Je fais un appel de phares pour qu’elle recule.', act: 'go', did: 'Vous avez exigé qu’elle recule.' }],
        ok: 1, should: 'Attendre qu’elle sorte : on n’entre pas si quelqu’un est **déjà engagé**.',
        why: 'Le panneau attribue la priorité, mais on n’entre jamais dans un passage qu’on ne peut pas traverser **jusqu’au bout**. Un véhicule déjà engagé doit pouvoir sortir.',
        memo: 'O–V–E : quelqu’un est-il déjà **E**ngagé ?' },
      { id: 'r2', pt: 1, slot: 'mid', kind: 'narrowMine', title: 'Obstacle sur ma voie',
        scene: 'Une camionnette de livraison est arrêtée **sur votre voie**. Pour la contourner, il faut passer sur la voie d’en face, où une voiture arrive.',
        choices: [
          { t: 'Je la contourne tout de suite.', act: 'go', did: 'Vous avez contourné l’obstacle face à la voiture qui arrivait.' },
          { t: 'Je m’arrête un peu avant l’obstacle et je laisse passer la voiture.', act: 'wait' },
          { t: 'Je contourne en klaxonnant.', act: 'go', did: 'Vous avez contourné en klaxonnant.' }],
        ok: 1, should: 'S’arrêter **un peu avant** l’obstacle et laisser passer le trafic d’en face.',
        why: 'Celui qui garde sa trajectoire normale n’a rien à changer : c’est **celui qui doit sortir de sa voie** qui attend. S’arrêter un peu avant laisse de la place à l’autre.',
        memo: 'O–V–E : qui doit envahir la **V**oie de l’autre ?' },
      { id: 'r3', pt: 1, slot: 'mid', kind: 'narrowTheirs', title: 'Obstacle en face',
        scene: 'Une voiture est garée sur la **voie d’en face**. La voiture qui arrive en face doit la contourner. Votre voie est libre.',
        choices: [
          { t: 'Je m’arrête pour la laisser passer.', act: 'info', did: 'Vous vous êtes arrêté alors que votre voie était libre.' },
          { t: 'Je continue prudemment sur ma voie.', act: 'go' },
          { t: 'Je me décale à gauche pour l’aider.', act: 'info', did: 'Vous vous êtes décalé vers la voie d’en face.' }],
        ok: 1, should: 'Continuer **prudemment** sur votre voie : c’est l’autre qui doit attendre.',
        why: 'L’obstacle est sur la voie d’en face : c’est donc l’autre conducteur qui devrait envahir votre voie. Il attend ; vous gardez votre trajectoire en restant attentif.',
        memo: 'O–V–E : où est l’**O**bstacle ?' },
      { id: 'r4', pt: 2, slot: 'mid', kind: 'narrowTruck', title: 'Face à un camion',
        scene: 'Un **camion** arrive en face. Un obstacle se trouve **sur sa voie**, pas sur la vôtre. Il ralentit.',
        choices: [
          { t: 'Je m’arrête : un camion est prioritaire parce qu’il est grand.', act: 'info', did: 'Vous avez cédé au camion à cause de sa taille.' },
          { t: 'Je passe prudemment, en gardant une bonne marge sur le côté.', act: 'go' },
          { t: 'Je passe vite en frôlant le camion.', act: 'rush', did: 'Vous êtes passé vite et trop près.' }],
        ok: 1, should: 'Passer **prudemment** sur votre voie, avec une **marge latérale** suffisante.',
        why: 'La taille d’un véhicule ne crée **aucun droit** de priorité. On communique, on garde de l’espace sur le côté, sans jamais forcer.',
        memo: 'O–V–E : l’**O**bstacle décide, pas la taille.' }
    ],
    routes: [
      { id: 'p1', pt: 0, slot: 'int', kind: 'mainGo', title: 'Sur la route principale',
        scene: 'Un **losange jaune** bordé de blanc vous indique que vous êtes sur une **route principale**. Une voiture attend à droite, sur une rue secondaire.',
        choices: [
          { t: 'Je lui cède : elle vient de droite.', act: 'info', did: 'Vous avez cédé à une voiture qui devait vous laisser passer.' },
          { t: 'Je continue, en restant attentif.', act: 'go' },
          { t: 'Je m’arrête pour lui faire signe de passer.', act: 'info', did: 'Vous vous êtes arrêté pour lui céder votre priorité.' }],
        ok: 1, should: 'Continuer : sur la **route principale**, vous êtes prioritaire, même face à la droite.',
        why: 'Le losange jaune donne la priorité aux véhicules de l’axe, jusqu’au panneau de fin. S’arrêter sans raison crée de la confusion pour tous.',
        memo: 'P–T–F : je repère le **P**anneau.' },
      { id: 'p2', pt: 0, slot: 'int', kind: 'mainEnd', title: 'Fin de la route principale',
        scene: 'Vous venez de passer le panneau de **fin de route principale** (losange jaune barré). Au carrefour suivant, sans autre panneau, une voiture arrive **de votre droite**.',
        choices: [
          { t: 'Je passe : je viens de la grande route.', act: 'go', did: 'Vous êtes passé comme si la route était encore principale.' },
          { t: 'Je cède à la voiture de droite.', act: 'wait' },
          { t: 'Je passe en accélérant.', act: 'go', did: 'Vous avez accéléré pour passer avant elle.' }],
        ok: 1, should: 'Céder à droite : après le panneau de fin, la **règle générale** revient.',
        why: 'La priorité de la route principale s’arrête au panneau de **fin**. Ensuite, sans autre indication, la priorité de droite s’applique de nouveau.',
        memo: 'P–T–F : je guette la **F**in.' },
      { id: 'p3', pt: 1, slot: 'int', kind: 'sideYield', title: 'Rejoindre l’axe principal',
        scene: 'Votre rue est **secondaire** (panneau « Cédez le passage »). Elle rejoint un axe principal où une voiture arrive **de votre gauche**.',
        choices: [
          { t: 'Je passe : elle vient de ma gauche.', act: 'go', did: 'Vous êtes passé devant un véhicule de l’axe principal.' },
          { t: 'Je lui cède le passage.', act: 'wait' },
          { t: 'Je m’engage à moitié pour la forcer à ralentir.', act: 'go', did: 'Vous vous êtes engagé à moitié sur l’axe principal.' }],
        ok: 1, should: 'Céder à **tous** les véhicules de l’axe principal, même venant de gauche.',
        why: 'À chaque jonction, les rôles sont clairs : la route secondaire cède à l’axe principal. Ce classement passe **avant** la priorité de droite.',
        memo: 'P–T–F : axe principal d’abord.' },
      { id: 'p4', pt: 2, slot: 'int', kind: 'mainTurns', title: 'La route principale tourne',
        scene: 'Le losange jaune porte une **plaque** : le **trait épais** vient de votre **gauche** et repart tout droit devant vous. Votre route, d’où vous arrivez, n’est qu’un **trait fin**, même si la chaussée semble continuer tout droit. Une voiture arrive de gauche et suit le trait épais.',
        choices: [
          { t: 'Je continue : la chaussée continue tout droit, je suis prioritaire.', act: 'go', did: 'Vous avez suivi l’aspect de la chaussée plutôt que la plaque.' },
          { t: 'Je cède à la voiture qui suit le tracé prioritaire.', act: 'wait' },
          { t: 'J’accélère pour passer avant elle.', act: 'go', did: 'Vous avez accéléré pour passer avant elle.' }],
        ok: 1, should: 'Suivre le **dessin de la plaque** : votre route est secondaire, vous cédez au véhicule du trait épais.',
        why: 'C’est la plaque complémentaire qui montre le **tracé prioritaire** (trait épais). C’est ce dessin qui compte, même si la chaussée semble visuellement aller tout droit.',
        memo: 'P–T–F : je suis le **T**racé de la plaque.' }
    ],
    'prioritaires-tram': [
      { id: 't1', pt: 0, slot: 'mid', kind: 'ambulance', title: 'Feu bleu et sirène',
        scene: 'Une **ambulance** arrive derrière vous avec le **feu bleu** et la **sirène**.',
        choices: [
          { t: 'Je freine fort et je m’arrête au milieu de ma voie.', act: 'info', did: 'Vous vous êtes arrêté net au milieu de la voie.' },
          { t: 'Je mets le clignotant droit, je me serre à droite et je ralentis.', act: 'pull' },
          { t: 'Je continue normalement : elle me dépassera.', act: 'info', did: 'Vous avez continué sans créer de passage.' }],
        ok: 1, should: 'Créer **immédiatement** un passage : clignotant, se serrer à droite, ralentir.',
        why: 'Avec le feu bleu et la sirène, les véhicules d’urgence ont la priorité sur **tous** les usagers : quelques secondes peuvent sauver une vie. La manœuvre doit rester simple et compréhensible.',
        memo: 'B–S–S : **B**leu + **S**irène = **S**’écarter **S**ûrement.' },
      { id: 't2', pt: 1, slot: 'int', kind: 'tramLeft', title: 'Le tram tourne',
        scene: 'Un **tramway** arrive en face et **tourne à gauche**, en coupant votre route. Vous allez tout droit.',
        choices: [
          { t: 'Je passe : il tourne à gauche, il doit me céder.', act: 'go', did: 'Vous êtes passé devant le tram qui tournait.' },
          { t: 'Je laisse passer le tram, puis je passe.', act: 'wait' },
          { t: 'Je klaxonne pour qu’il freine.', act: 'go', did: 'Vous avez compté sur le tram pour freiner.' }],
        ok: 1, should: 'Laisser passer le **tram**, même lorsqu’il tourne à gauche.',
        why: 'Le tram roule sur des rails : il ne peut **ni se déporter ni s’arrêter net**. Sa trajectoire est rigide, d’où sa priorité étendue, même quand il tourne à gauche.',
        memo: 'B–S–S : **R**ail = trajectoire rigide.' },
      { id: 't3', pt: 2, slot: 'int', kind: 'ambulanceRed', title: 'Sirène au feu rouge',
        scene: 'Vous êtes arrêté au **feu rouge**. Une ambulance arrive derrière vous, feu bleu et sirène. Des voitures traversent le carrefour au vert.',
        choices: [
          { t: 'Je franchis le feu rouge pour dégager.', act: 'go', did: 'Vous avez franchi le feu rouge devant le trafic transversal.' },
          { t: 'Je me serre à droite autant que possible, sans franchir le feu.', act: 'pull' },
          { t: 'Je recule pour lui laisser de la place.', act: 'info', did: 'Vous avez reculé vers l’ambulance.' }],
        ok: 1, should: 'Libérer le passage **de façon sûre** : se serrer, sans franchir le feu au milieu du trafic.',
        why: '« Immédiatement » ne veut pas dire « n’importe comment ». Franchir le rouge à l’aveugle remplacerait un danger par un autre : vous pourriez percuter quelqu’un qui passe au vert.',
        memo: 'B–S–S : s’écarter **Sûrement**.' }
    ]
  }
};
export const CHAPTERS_READY = ['O11'];
