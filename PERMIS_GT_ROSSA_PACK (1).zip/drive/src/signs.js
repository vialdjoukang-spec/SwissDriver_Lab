// Panneaux routiers dessinés (modèles suisses, simplifiés) et poteaux.
import * as THREE from 'three';

const cache = {};
function tex(key, w, h, draw) { if (cache[key]) return cache[key]; const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return (cache[key] = t); }
const RED = '#c8102e', BLUE = '#1e5aa8';

const DRAW = {
  yield: (x, w, h) => { x.fillStyle = '#fff'; x.beginPath(); x.moveTo(8, 14); x.lineTo(w - 8, 14); x.lineTo(w / 2, h - 10); x.closePath(); x.fill(); x.strokeStyle = RED; x.lineWidth = 26; x.lineJoin = 'round'; x.beginPath(); x.moveTo(26, 26); x.lineTo(w - 26, 26); x.lineTo(w / 2, h - 34); x.closePath(); x.stroke(); },
  main: (x, w, h) => { x.save(); x.translate(w / 2, h / 2); x.rotate(Math.PI / 4); x.fillStyle = '#fff'; x.fillRect(-82, -82, 164, 164); x.fillStyle = '#f2c230'; x.fillRect(-60, -60, 120, 120); x.strokeStyle = '#111'; x.lineWidth = 2; x.strokeRect(-82, -82, 164, 164); x.restore(); },
  mainEnd: (x, w, h) => { DRAW.main(x, w, h); x.strokeStyle = '#222'; x.lineWidth = 14; for (let k = -2; k <= 2; k++) { x.beginPath(); x.moveTo(40 + k * 16, h - 40 + k * 16); x.lineTo(w - 40 + k * 16, 40 + k * 16); x.stroke(); } },
  round: (x, w, h) => { x.fillStyle = BLUE; x.beginPath(); x.arc(w / 2, h / 2, w / 2 - 6, 0, 7); x.fill(); x.strokeStyle = '#fff'; x.lineWidth = 6; x.stroke(); x.fillStyle = '#fff'; for (let k = 0; k < 3; k++) { x.save(); x.translate(w / 2, h / 2); x.rotate(k * 2.094); x.beginPath(); x.arc(0, 0, 58, -1.9, -.6); x.lineWidth = 20; x.strokeStyle = '#fff'; x.stroke(); x.translate(Math.cos(-.6) * 58, Math.sin(-.6) * 58); x.rotate(-.6 + Math.PI / 2); x.beginPath(); x.moveTo(-20, -8); x.lineTo(20, -8); x.lineTo(0, 22); x.closePath(); x.fill(); x.restore(); } },
  narrowPrio: (x, w, h) => { x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.fillStyle = BLUE; x.fillRect(8, 8, w - 16, h - 16); x.fillStyle = '#fff'; x.beginPath(); x.moveTo(78, 40); x.lineTo(108, 90); x.lineTo(88, 90); x.lineTo(88, 210); x.lineTo(68, 210); x.lineTo(68, 90); x.lineTo(48, 90); x.closePath(); x.fill(); x.fillStyle = RED; x.beginPath(); x.moveTo(178, 216); x.lineTo(150, 170); x.lineTo(168, 170); x.lineTo(168, 60); x.lineTo(188, 60); x.lineTo(188, 170); x.lineTo(206, 170); x.closePath(); x.fill(); },
  narrow: (x, w, h) => { x.fillStyle = '#fff'; x.beginPath(); x.moveTo(w / 2, 10); x.lineTo(w - 10, h - 20); x.lineTo(10, h - 20); x.closePath(); x.fill(); x.strokeStyle = RED; x.lineWidth = 24; x.lineJoin = 'round'; x.beginPath(); x.moveTo(w / 2, 34); x.lineTo(w - 32, h - 34); x.lineTo(32, h - 34); x.closePath(); x.stroke(); x.fillStyle = '#111'; x.beginPath(); x.moveTo(98, 90); x.quadraticCurveTo(110, 150, 104, 200); x.lineTo(92, 200); x.quadraticCurveTo(98, 150, 88, 90); x.fill(); x.beginPath(); x.moveTo(158, 90); x.quadraticCurveTo(146, 150, 152, 200); x.lineTo(164, 200); x.quadraticCurveTo(158, 150, 168, 90); x.fill(); },
  plateLeft: (x, w, h) => { x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.strokeStyle = '#111'; x.lineWidth = 6; x.strokeRect(6, 6, w - 12, h - 12); x.lineCap = 'round'; x.lineWidth = 7; x.beginPath(); x.moveTo(w / 2, h - 18); x.lineTo(w / 2, h / 2); x.moveTo(w / 2 + 40, h / 2); x.lineTo(w / 2, h / 2); x.stroke(); x.lineWidth = 22; x.beginPath(); x.moveTo(30, h / 2); x.lineTo(w / 2, h / 2); x.lineTo(w / 2, 18); x.stroke(); },
  stopText: (x, w, h) => { x.fillStyle = '#ffffffee'; x.fillRect(0, 0, w, h); x.fillStyle = '#16212e'; x.font = '700 40px Helvetica, Arial'; x.textAlign = 'center'; x.fillText('Feux hors service', w / 2, 58); }
};
const SIZE = { yield: [256, 230, .9, .8], main: [256, 256, .85, .85], mainEnd: [256, 256, .85, .85], round: [256, 256, .7, .7], narrowPrio: [256, 256, .7, .7], narrow: [256, 230, .9, .8], plateLeft: [256, 160, .7, .44], stopText: [512, 90, 1.4, .25] };

export function sign(kind, poleH = 2.2) {
  const [w, h, sw, sh] = SIZE[kind];
  const g = new THREE.Group();
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(.04, .04, poleH + sh, 10), new THREE.MeshStandardMaterial({ color: '#8e979f', metalness: .7, roughness: .4 })); pole.position.y = (poleH + sh) / 2; pole.castShadow = true; g.add(pole);
  const face = new THREE.Mesh(new THREE.PlaneGeometry(sw, sh), new THREE.MeshBasicMaterial({ map: tex(kind, w, h, DRAW[kind]), transparent: true, toneMapped: false })); face.position.set(0, poleH + sh / 2, .05); g.add(face);
  const back = new THREE.Mesh(new THREE.PlaneGeometry(sw * .95, sh * .95), new THREE.MeshStandardMaterial({ color: '#9aa2a9', metalness: .6 })); back.position.set(0, poleH + sh / 2, .04); back.rotation.y = Math.PI; g.add(back);
  g.userData.top = poleH + sh;
  return g;
}
// plaque complémentaire fixée sous un panneau
export function plate(kind, y) { const [w, h, sw, sh] = SIZE[kind]; const m = new THREE.Mesh(new THREE.PlaneGeometry(sw, sh), new THREE.MeshBasicMaterial({ map: tex(kind, w, h, DRAW[kind]), toneMapped: false })); m.position.set(0, y, .06); return m; }

// marquage au sol : ligne d'arrêt pointillée (céder) + triangle peint
export function yieldMarking(xc, z, width = 5) {
  const g = new THREE.Group(); const m = new THREE.MeshBasicMaterial({ color: '#f4f4ef' });
  for (let x = xc - width / 2 + .3; x < xc + width / 2; x += .9) { const d = new THREE.Mesh(new THREE.PlaneGeometry(.5, .3), m); d.rotation.x = -Math.PI / 2; d.position.set(x, .025, z); g.add(d); }
  const tri = new THREE.Shape(); tri.moveTo(-.7, 0); tri.lineTo(.7, 0); tri.lineTo(0, 2.6); tri.closePath(); const tm = new THREE.Mesh(new THREE.ShapeGeometry(tri), m); tm.rotation.x = -Math.PI / 2; tm.position.set(xc, .026, z + 4.6); g.add(tm);
  const tri2 = new THREE.Mesh(new THREE.ShapeGeometry((() => { const s = new THREE.Shape(); s.moveTo(-.45, .35); s.lineTo(.45, .35); s.lineTo(0, 2.0); s.closePath(); return s; })()), new THREE.MeshBasicMaterial({ color: '#5a5e63' })); tri2.rotation.x = -Math.PI / 2; tri2.position.set(xc, .027, z + 4.6); g.add(tri2);
  return g;
}
