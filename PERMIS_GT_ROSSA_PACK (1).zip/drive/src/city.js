// Ville procédurale infinie en quadrillage : avenues (nord-sud), rues (est-ouest), carrefours à feux,
// îlots d'immeubles, parcs et places. Chaque cellule (i, j) est construite de façon déterministe.
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

export const CELL = 80, RW = 5, CW = 3.5, SW = 4.5, SWC = 3.5, SWE = 7, CURB = .15;
const FLOOR = 3.2, BAY = 4.5;

export function hash(i, j, k = 0) { let h = (i * 374761393 + j * 668265263 + k * 1274126177) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
export function rng(seed) { let s = (seed * 4294967296) >>> 0 || 7; return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; }
export function cellType(i, j) { const h = hash(i, j, 5); return h < .11 ? 'park' : h < .17 ? 'plaza' : 'bld'; }
export const isAvenueRoad = x => Math.abs(x - Math.round(x / CELL) * CELL) < RW;
export const isCrossRoad = z => Math.abs(z - Math.round(z / CELL) * CELL) < CW;
export const groundY = (x, z) => (isAvenueRoad(x) || isCrossRoad(z)) ? 0 : CURB;
export const inCrossBand = (z, m = 2.5) => Math.abs(z - Math.round(z / CELL) * CELL) < CW + SWC + m;
export const AVENUE_NAMES = ['Avenue du Permis', 'Avenue de la Gare', 'Avenue du Premier-Mars', 'Avenue Léopold-Robert', 'Avenue de Beauregard', 'Avenue des Alpes', 'Avenue du Lac'];
export const STREET_NAMES = ['Rue des Priorités', 'Rue du Seyon', 'Rue des Moulins', 'Rue de l’Hôpital', 'Rue du Château', 'Rue des Terreaux', 'Rue de la Serre', 'Rue des Beaux-Arts', 'Rue Saint-Maurice', 'Rue du Temple-Neuf', 'Rue de la Côte', 'Rue des Parcs'];
const SHOPS = ['Boulangerie', 'Pharmacie', 'Café du Lac', 'Librairie', 'Coiffure', 'Banque Cantonale', 'Fleuriste', 'Optique', 'Boucherie', 'Épicerie', 'Auto-école', 'Kiosque', 'Restaurant', 'Chocolatier', 'Horlogerie', 'Tea-Room'];

/* ---------------- Textures ---------------- */
function tex(c, repeat, aniso = 8) { const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = aniso; if (repeat) t.repeat.set(repeat[0], repeat[1]); return t; }
function linTex(c) { const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 8; return t; }
function cv(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); return c; }
let NOISE = null;
function noisePattern(ctx) { if (!NOISE) { const c = cv(256, 256, () => {}); const x = c.getContext('2d'); const im = x.createImageData(256, 256); const d = im.data; for (let i = 0; i < d.length; i += 4) { const v = Math.random() < .5 ? 0 : 255; d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = Math.random() * 255; } x.putImageData(im, 0, 0); NOISE = c; } return ctx.createPattern(NOISE, 'repeat'); }
function grain(ctx, w, h, base, amp, n, R = Math.random) { ctx.fillStyle = base; ctx.fillRect(0, 0, w, h); ctx.save(); ctx.globalAlpha = Math.min(1, amp * 1.1); ctx.fillStyle = noisePattern(ctx); ctx.fillRect(0, 0, w, h); ctx.globalAlpha = Math.min(1, amp * .6); ctx.scale(3, 3); ctx.fillRect(0, 0, w / 3, h / 3); ctx.restore(); }
// carte de normales à partir d'une carte de hauteurs (canvas en niveaux de gris)
function normalFrom(hc, strength = 2) {
  const w = hc.width, h = hc.height, src = hc.getContext('2d').getImageData(0, 0, w, h).data;
  const out = cv(w, h, () => {}); const ctx = out.getContext('2d'); const img = ctx.createImageData(w, h); const d = img.data;
  const H = (x, y) => src[(((y + h) % h) * w + ((x + w) % w)) * 4] / 255;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const dx = (H(x + 1, y) - H(x - 1, y)) * strength, dy = (H(x, y + 1) - H(x, y - 1)) * strength;
    const l = Math.hypot(dx, dy, 1); const o = (y * w + x) * 4;
    d[o] = (-dx / l * .5 + .5) * 255; d[o + 1] = (dy / l * .5 + .5) * 255; d[o + 2] = (1 / l * .5 + .5) * 255; d[o + 3] = 255;
  }
  ctx.putImageData(img, 0, 0); return out;
}

export function makeMaterials() {
  const R = rng(.37);
  // asphalte : grain, fissures, taches
  const asC = cv(1024, 1024, (c, w, h) => { grain(c, w, h, '#5a5e63', .2, 90000, R); c.strokeStyle = 'rgba(20,20,22,.35)'; c.lineWidth = 2; for (let i = 0; i < 14; i++) { c.beginPath(); let x = R() * w, y = R() * h; c.moveTo(x, y); for (let k = 0; k < 12; k++) { x += (R() - .5) * 60; y += (R() - .5) * 60; c.lineTo(x, y); } c.stroke(); } for (let i = 0; i < 20; i++) { c.fillStyle = `rgba(0,0,0,${.05 + R() * .12})`; c.beginPath(); c.ellipse(R() * w, R() * h, 20 + R() * 90, 10 + R() * 50, R() * 3, 0, 7); c.fill(); } });
  const asH = cv(512, 512, (c, w, h) => grain(c, w, h, '#808080', .5, 40000, R));
  // pavés de trottoir avec joints
  const pvC = cv(1024, 1024, (c, w, h) => { grain(c, w, h, '#cfccc4', .09, 60000, R); const s = 128; for (let y = 0; y < h; y += s) for (let x = 0; x < w; x += s) { c.fillStyle = `rgba(${R() < .5 ? '0,0,0' : '255,255,255'},${R() * .06})`; c.fillRect(x, y, s, s); } c.strokeStyle = 'rgba(70,66,60,.55)'; c.lineWidth = 5; for (let y = 0; y <= h; y += s) { c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); } for (let x = 0; x <= w; x += s) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, h); c.stroke(); } });
  const pvH = cv(512, 512, (c, w, h) => { c.fillStyle = '#9a9a9a'; c.fillRect(0, 0, w, h); const s = 64; c.strokeStyle = '#303030'; c.lineWidth = 4; for (let y = 0; y <= h; y += s) { c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); } for (let x = 0; x <= w; x += s) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, h); c.stroke(); } });
  const grC = cv(512, 512, (c, w, h) => { grain(c, w, h, '#6f944f', .22, 30000, R); for (let i = 0; i < 3000; i++) { c.fillStyle = `rgba(${40 + R() * 60},${90 + R() * 70},${30 + R() * 40},.5)`; c.fillRect(R() * w, R() * h, 2, 5); } });
  const gvC = cv(512, 512, (c, w, h) => grain(c, w, h, '#c9bfae', .16, 50000, R));
  const roofC = cv(512, 512, (c, w, h) => grain(c, w, h, '#6e6a66', .18, 50000, R));
  const asN = linTex(normalFrom(asH, 1.2)), pvN = linTex(normalFrom(pvH, 2.4));
  const M = {
    asphalt: new THREE.MeshStandardMaterial({ map: tex(asC), normalMap: asN, normalScale: new THREE.Vector2(.35, .35), roughness: .93 }),
    paving: new THREE.MeshStandardMaterial({ map: tex(pvC), normalMap: pvN, normalScale: new THREE.Vector2(.5, .5), roughness: .88, color: '#cfcac0' }),
    plazaPaving: new THREE.MeshStandardMaterial({ map: tex(pvC), normalMap: pvN, normalScale: new THREE.Vector2(.4, .4), roughness: .8, color: '#d9d0c0' }),
    grass: new THREE.MeshStandardMaterial({ map: tex(grC), roughness: 1 }),
    gravel: new THREE.MeshStandardMaterial({ map: tex(gvC), roughness: 1 }),
    roof: new THREE.MeshStandardMaterial({ map: tex(roofC), roughness: .95 }),
    concrete: new THREE.MeshStandardMaterial({ color: '#cfcbc2', roughness: .9 }),
    white: new THREE.MeshStandardMaterial({ color: '#f1f1ec', roughness: .55 }),
    yellow: new THREE.MeshStandardMaterial({ color: '#f0c33c', roughness: .6 }),
    metal: new THREE.MeshStandardMaterial({ color: '#4d5862', roughness: .4, metalness: .7 }),
    dark: new THREE.MeshStandardMaterial({ color: '#2b3239', roughness: .5, metalness: .5 }),
    trunk: new THREE.MeshStandardMaterial({ color: '#5e4632', roughness: .95 }),
    leaf: new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: .92, vertexColors: false }),
    wood: new THREE.MeshStandardMaterial({ color: '#8a6440', roughness: .8 }),
    hedge: new THREE.MeshStandardMaterial({ color: '#2f6a2e', roughness: .95 }),
    water: new THREE.MeshPhysicalMaterial({ color: '#4f8fb8', roughness: .05, metalness: 0, transmission: 0, transparent: true, opacity: .85, envMapIntensity: 1.5 }),
    glass: new THREE.MeshPhysicalMaterial({ color: '#cfe3f0', roughness: .05, metalness: .1, transparent: true, opacity: .32, envMapIntensity: 1.2 }),
    flowers: ['#d9435a', '#f2c94c', '#9b59b6'].map(c => new THREE.MeshStandardMaterial({ color: c, roughness: .8 })),
    awnings: ['#b3463a', '#2f5f8f', '#3e7a50'].map(c => new THREE.MeshStandardMaterial({ color: c, roughness: .9, side: THREE.DoubleSide })),
    lampOn: new THREE.MeshStandardMaterial({ color: '#fff6dc', emissive: '#ffe9b0', emissiveIntensity: .3 }),
    lightOff: new THREE.MeshStandardMaterial({ color: '#2a2e33', roughness: .4 }),
    red: new THREE.MeshBasicMaterial({ color: '#ff3b30', toneMapped: false }), amber: new THREE.MeshBasicMaterial({ color: '#ffb020', toneMapped: false }), green: new THREE.MeshBasicMaterial({ color: '#2fe06b', toneMapped: false }),
    carPaint: ['#b9332f', '#2b5a9c', '#e9e9e4', '#2d3136', '#6f7f8f', '#1f6b4a', '#d6a63a', '#5a3f7a', '#8f9ea8', '#c9c3b7'].map(c => new THREE.MeshPhysicalMaterial({ color: c, roughness: .3, metalness: .5, clearcoat: 1, clearcoatRoughness: .08 })),
    carGlass: new THREE.MeshStandardMaterial({ color: '#1b2630', roughness: .05, metalness: .9 }),
    tire: new THREE.MeshStandardMaterial({ color: '#1b1d20', roughness: .95 }), rim: new THREE.MeshStandardMaterial({ color: '#c8cdd2', metalness: .85, roughness: .3 })
  };
  M.asphalt.map.repeat.set(1 / 9, 1 / 9); M.asphalt.normalMap.repeat.set(1 / 6, 1 / 6);
  M.paving.map.repeat.set(1 / 4, 1 / 4); M.paving.normalMap.repeat.set(1 / 4, 1 / 4); M.plazaPaving.map.repeat.set(1 / 5, 1 / 5); M.plazaPaving.normalMap.repeat.set(1 / 5, 1 / 5);
  M.grass.map.repeat.set(1 / 6, 1 / 6); M.gravel.map.repeat.set(1 / 5, 1 / 5); M.roof.map.repeat.set(1 / 8, 1 / 8);
  // façades : 4 travées × 8 niveaux (rez-de-chaussée en bas), relief des fenêtres
  const pal = [['#efe3cf', '#7d5a3c'], ['#e3e9ee', '#4e5a66'], ['#f2dccd', '#8b4e3a'], ['#e8e3cf', '#6c6650'], ['#dfe6da', '#4d6450'], ['#f6efe3', '#946b45'], ['#e6e3ea', '#5a566b'], ['#f0e2c2', '#8a6a33'], ['#d9c9b6', '#5e4a3a'], ['#e9d7d3', '#7a4d4a']];
  const hC = cv(512, 1024, (c, w, h) => { c.fillStyle = '#999'; c.fillRect(0, 0, w, h); const cols = 4, rows = 8, ww = w / cols, wh = h / rows; for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) { const x = k * ww + ww * .22, y = r * wh + wh * .2, gw = ww * .56, gh = wh * .58; if (r === rows - 1) { c.fillStyle = '#555'; c.fillRect(k * ww + 8, y - 12, ww - 16, gh + 30); continue; } c.fillStyle = '#c8c8c8'; c.fillRect(x - 12, y - 14, gw + 24, 10); c.fillRect(x - 16, y + gh + 4, gw + 32, 12); c.fillStyle = '#4a4a4a'; c.fillRect(x - 5, y - 5, gw + 10, gh + 10); c.fillStyle = '#9a9a9a'; c.fillRect(x - 3, y - 3, gw + 6, 5); c.fillRect(x + gw / 2 - 2, y, 5, gh); } for (let r = 1; r < rows; r++) { c.fillStyle = '#b5b5b5'; c.fillRect(0, r * wh - 6, w, 8); } });
  const facadeN = linTex(normalFrom(hC, 2.2));
  M.facades = pal.map(([wall, trim], i) => {
    const c = cv(1024, 2048, (c, w, h) => {
      grain(c, w, h, wall, .07, 70000, R);
      for (let k = 0; k < 90; k++) { c.fillStyle = `rgba(0,0,0,${R() * .035})`; c.beginPath(); c.arc(R() * w, R() * h, 30 + R() * 180, 0, 7); c.fill(); }
      const cols = 4, rows = 8, ww = w / cols, wh = h / rows;
      for (let r = 1; r < rows; r++) { c.fillStyle = 'rgba(0,0,0,.1)'; c.fillRect(0, r * wh - 7, w, 11); c.fillStyle = 'rgba(255,255,255,.3)'; c.fillRect(0, r * wh - 10, w, 3); }
      for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) {
        const x = k * ww + ww * .22, y = r * wh + wh * .2, gw = ww * .56, gh = wh * .58;
        if (r === rows - 1) {
          c.fillStyle = trim; c.fillRect(k * ww + 10, y - 26, ww - 20, gh + 56);
          if (k === 1) { c.fillStyle = '#4a3a2c'; c.fillRect(k * ww + 40, y - 6, ww - 80, gh + 30); c.fillStyle = '#8fa9bd'; c.fillRect(k * ww + 60, y + 10, ww - 120, gh * .45); c.fillStyle = '#d8c08a'; c.fillRect(k * ww + ww - 76, y + gh * .6, 10, 10); continue; }
          const g = c.createLinearGradient(0, y, 0, y + gh + 20); g.addColorStop(0, '#b4c7d6'); g.addColorStop(.4, '#64809a'); g.addColorStop(1, '#2d3f50'); c.fillStyle = g; c.fillRect(k * ww + 24, y - 10, ww - 48, gh + 30);
          c.fillStyle = 'rgba(255,255,255,.3)'; c.beginPath(); c.moveTo(k * ww + 30, y - 6); c.lineTo(k * ww + 95, y - 6); c.lineTo(k * ww + 44, y + gh + 10); c.lineTo(k * ww + 30, y + gh + 10); c.fill();
          c.fillStyle = trim; c.fillRect(k * ww + ww / 2 - 3, y - 10, 6, gh + 30);
          continue;
        }
        c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(x - 10, y - 10, gw + 20, gh + 24);
        c.fillStyle = '#f0ebe2'; c.fillRect(x - 14, y - 16, gw + 28, 12); c.fillRect(x - 18, y + gh + 6, gw + 36, 14);
        const g = c.createLinearGradient(x, y, x + gw * .4, y + gh); g.addColorStop(0, '#b9d0e2'); g.addColorStop(.45, '#6d8aa3'); g.addColorStop(.7, '#45607a'); g.addColorStop(1, '#7f98ad'); c.fillStyle = g; c.fillRect(x, y, gw, gh);
        if (R() < .45) { c.fillStyle = `rgba(${225 + R() * 25},${215 + R() * 25},${195 + R() * 30},.6)`; c.fillRect(x + 5, y + 5, gw * .3, gh - 10); c.fillRect(x + gw * .7 - 5, y + 5, gw * .3, gh - 10); }
        if (R() < .18) { c.fillStyle = 'rgba(255,240,200,.35)'; c.fillRect(x + 5, y + 5, gw - 10, gh - 10); }
        c.fillStyle = 'rgba(255,255,255,.2)'; c.beginPath(); c.moveTo(x, y); c.lineTo(x + gw * .35, y); c.lineTo(x, y + gh * .5); c.fill();
        c.fillStyle = '#f7f5f0'; c.fillRect(x - 3, y - 3, gw + 6, 6); c.fillRect(x - 3, y + gh - 3, gw + 6, 6); c.fillRect(x - 3, y, 6, gh); c.fillRect(x + gw - 3, y, 6, gh); c.fillRect(x + gw / 2 - 3, y, 6, gh); c.fillRect(x, y + gh * .38, gw, 5);
        if ((r + k + i) % 3 === 0) { const sc = ['#9c4a3a', '#3f6f8f', '#4f7a4a', '#8a6a3a'][(r + i) % 4]; c.fillStyle = sc; c.fillRect(x - 36, y - 6, 24, gh + 12); c.fillRect(x + gw + 12, y - 6, 24, gh + 12); c.fillStyle = 'rgba(0,0,0,.2)'; for (let yy = y; yy < y + gh; yy += 12) { c.fillRect(x - 36, yy, 24, 3); c.fillRect(x + gw + 12, yy, 24, 3); } }
      }
    });
    return new THREE.MeshStandardMaterial({ map: tex(c), normalMap: facadeN, normalScale: new THREE.Vector2(.6, .6), roughness: .85, color: '#e9e6e0' });
  });
  M.trims = ['#6b5744', '#4e5a66'].map(t => new THREE.MeshStandardMaterial({ color: t, roughness: .75 }));
  M.noShadow = new Set([M.asphalt, M.paving, M.plazaPaving, M.grass, M.gravel, M.white, M.tactile, M.manhole, M.roof]);
  // enseignes
  { const c = cv(2048, 2048, (c, w, h) => { SHOPS.forEach((name, i) => { const x0 = (i % 2) * 1024, y0 = Math.floor(i / 2) * 256; const bg = ['#1d3a5f', '#5a1f1f', '#2d4a2e', '#3b2f55', '#1f1f23', '#7a4b1c'][i % 6]; c.fillStyle = bg; c.fillRect(x0, y0, 1024, 256); c.fillStyle = 'rgba(255,255,255,.12)'; c.fillRect(x0, y0, 1024, 18); c.fillStyle = ['#f3e5b8', '#ffffff', '#ffd27a', '#dfe8ff'][i % 4]; c.font = `${i % 3 === 0 ? 'italic ' : ''}700 118px ${i % 2 ? 'Georgia, serif' : '"Segoe UI", Helvetica, Arial, sans-serif'}`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(name, x0 + 512, y0 + 134); }); });
    const t = tex(c); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; M.signAtlas = new THREE.MeshStandardMaterial({ map: t, roughness: .6, emissive: '#ffffff', emissiveMap: t, emissiveIntensity: .1 }); M.signCount = SHOPS.length; }
  M.plateTex = (text) => { const c = cv(1024, 192, (c, w, h) => { c.fillStyle = '#1f4e8c'; c.fillRect(0, 0, w, h); c.strokeStyle = '#ffffff'; c.lineWidth = 8; c.strokeRect(12, 12, w - 24, h - 24); c.fillStyle = '#ffffff'; c.font = '700 96px "Segoe UI", Helvetica, Arial, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(text, w / 2, h / 2 + 4); }); return new THREE.MeshBasicMaterial({ map: tex(c), toneMapped: false }); };
  M.plates = {};
  M.crossSign = new THREE.MeshBasicMaterial({ map: tex(cv(256, 256, (c, w, h) => { c.fillStyle = '#ffffff'; c.fillRect(0, 0, w, h); c.fillStyle = '#1e5aa8'; c.fillRect(10, 10, w - 20, h - 20); c.fillStyle = '#ffffff'; c.beginPath(); c.moveTo(w / 2, 28); c.lineTo(w - 28, h - 36); c.lineTo(28, h - 36); c.closePath(); c.fill(); c.fillStyle = '#16212e'; c.beginPath(); c.arc(w / 2, 100, 13, 0, 7); c.fill(); c.fillRect(w / 2 - 7, 114, 14, 50); c.fillRect(w / 2 - 22, 155, 12, 42); c.fillRect(w / 2 + 10, 155, 12, 42); for (let i = 0; i < 4; i++) c.fillRect(66 + i * 34, h - 62, 22, 14); })), toneMapped: false });
  M.busSign = new THREE.MeshBasicMaterial({ map: tex(cv(512, 256, (c, w, h) => { c.fillStyle = '#ffffff'; c.fillRect(0, 0, w, h); c.fillStyle = '#1d5cb0'; c.fillRect(0, 0, w, 90); c.fillStyle = '#ffffff'; c.font = '800 64px Helvetica, Arial, sans-serif'; c.textAlign = 'center'; c.fillText('BUS', w / 2, 68); c.fillStyle = '#16212e'; c.font = '600 44px Helvetica, Arial, sans-serif'; c.fillText('Arrêt · Ligne 101', w / 2, 160); c.font = '500 34px Helvetica, Arial, sans-serif'; c.fillText('toutes les 10 min', w / 2, 215); })), toneMapped: false });
  M.tactile = new THREE.MeshStandardMaterial({ map: tex(cv(128, 128, (c, w, h) => { c.fillStyle = '#e2c84a'; c.fillRect(0, 0, w, h); c.fillStyle = '#b89a2e'; for (let y = 16; y < h; y += 32) for (let x = 16; x < w; x += 32) { c.beginPath(); c.arc(x, y, 9, 0, 7); c.fill(); } })), roughness: .8 });
  M.tactile.map.repeat.set(1.5, 1.5);
  M.manhole = new THREE.MeshStandardMaterial({ color: '#3a3d41', roughness: .6, metalness: .6 });
  return M;
}

/* ---------------- Fusion de géométries par matériau ---------------- */
class Merger {
  constructor() { this.m = new Map(); }
  add(geo, mat, mtx) { const g = geo.clone(); if (mtx) g.applyMatrix4(mtx); if (!this.m.has(mat)) this.m.set(mat, []); this.m.get(mat).push(g); }
  build(group, shadows = true) { for (const [mat, list] of this.m) { const merged = mergeGeometries(list, false); list.forEach(g => g.dispose()); if (!merged) continue; const mesh = new THREE.Mesh(merged, mat); mesh.castShadow = shadows && !(this.noShadow && this.noShadow.has(mat)); mesh.receiveShadow = true; group.add(mesh); } this.m.clear(); }
}
const _m = new THREE.Matrix4(), _p = new THREE.Vector3(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(), _e = new THREE.Euler();
function M4(x, y, z, sx = 1, sy = 1, sz = 1, ry = 0, rx = 0, rz = 0) { _e.set(rx, ry, rz); _q.setFromEuler(_e); return _m.compose(_p.set(x, y, z), _q, _s.set(sx, sy, sz)); }
// sol horizontal avec UV en mètres (textures continues entre les pièces)
function ground(x0, z0, x1, z1, y) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute([x0, y, z0, x1, y, z0, x0, y, z1, x1, y, z1], 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute([0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0], 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute([x0, z0, x1, z0, x0, z1, x1, z1], 2));
  g.setIndex([0, 2, 1, 1, 2, 3]); return g;
}
function quad(p0, p1, p2, p3, n, u1, v1) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute([...p0, ...p1, ...p2, ...p3], 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute([...n, ...n, ...n, ...n], 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, u1, 0, 0, v1, u1, v1], 2));
  g.setIndex([0, 1, 2, 2, 1, 3]); return g;
}

function quadUV(p0, p1, p2, p3, n, u0, v0, u1, v1) { const g = quad(p0, p1, p2, p3, n, 1, 1); g.setAttribute('uv', new THREE.Float32BufferAttribute([u0, v0, u1, v0, u0, v1, u1, v1], 2)); return g; }
/* ---------------- Construction d'une cellule ---------------- */
export function buildChunk(i, j, M, G) {
  const grp = new THREE.Group(); const mg = new Merger(); mg.noShadow = M.noShadow; const R = rng(hash(i, j, 1));
  const col = { boxes: [], circles: [] };
  const box = (b) => col.boxes.push(b); const circ = (x, z, r) => col.circles.push({ x, z, r });
  const x0 = i * CELL, z0 = j * CELL, x1 = x0 + CELL, z1 = z0 + CELL;
  const swe = i === 0 ? SWE : SW; // trottoir est de l'avenue x0
  const type = cellType(i, j);
  const BX0 = x0 + RW + swe, BX1 = x1 - RW - SW, BZ0 = z0 + CW + SWC, BZ1 = z1 - CW - SWC;

  /* --- chaussées --- */
  mg.add(ground(x0 - RW, z0, x0 + RW, z1, 0), M.asphalt);               // avenue (ligne x0)
  mg.add(ground(x0 - RW, z0 - CW, x1 - RW, z0 + CW, .004), M.asphalt);  // rue (ligne z0)
  // marquages
  for (let z = z0 + CW + 3; z < z1 - CW - 4; z += 6) mg.add(G.unit, M.white, M4(x0, .012, z + 1.5, .14, .01, 3));
  [-3, 3].forEach(dx => mg.add(G.unit, M.white, M4(x0 + dx, .012, (z0 + CW + z1 - CW) / 2, .1, .01, z1 - z0 - 2 * CW - 7)));
  for (let x = x0 + RW + 3; x < x1 - RW - 4; x += 6) mg.add(G.unit, M.white, M4(x + 1.5, .016, z0, 3, .01, .14));
  // passages piétons (4 par cellule : deux sur l'avenue, deux sur la rue)
  const zebraX = (xc, zc, dir) => { for (let k = 0; k < 8; k++) { const t = -3.5 + k; if (dir === 'z') mg.add(G.unit, M.white, M4(xc + t, .018, zc, .55, .01, 3)); else mg.add(G.unit, M.white, M4(xc, .018, zc + t, 3, .01, .55)); } };
  zebraX(x0, z0 + CW + 2, 'z'); zebraX(x0, z1 - CW - 2, 'z'); zebraX(x0 + RW + 2, z0, 'x'); zebraX(x1 - RW - 2, z0, 'x');
  // lignes d'arrêt
  mg.add(G.unit, M.white, M4(x0 + 2.5, .018, z0 + CW + 4.1, 5, .01, .35)); mg.add(G.unit, M.white, M4(x0 - 2.5, .018, z1 - CW - 4.1, 5, .01, .35));
  mg.add(G.unit, M.white, M4(x0 + RW + 4.1, .018, z0 - 1.75, .35, .01, 3.5)); mg.add(G.unit, M.white, M4(x1 - RW - 4.1, .018, z0 + 1.75, .35, .01, 3.5));
  // plaques d'égout, grilles
  mg.add(G.disc, M.manhole, M4(x0 + 1.4, .02, z0 + 22 + R() * 30, .45, 1, .45)); mg.add(G.disc, M.manhole, M4(x0 - 1.6, .02, z0 + 50 + R() * 25, .45, 1, .45));
  for (let z = z0 + CW + 10; z < z1 - CW - 6; z += 20) { mg.add(G.unit, M.dark, M4(x0 + RW - .35, .03, z, .5, .03, .9)); mg.add(G.unit, M.dark, M4(x0 - RW + .35, .03, z + 7, .5, .03, .9)); }

  /* --- trottoirs et bordures --- */
  const walk = (xa, za, xb, zb, mat = M.paving) => { mg.add(G.unit, M.concrete, M4((xa + xb) / 2, CURB / 2 - .01, (za + zb) / 2, xb - xa, CURB - .02, zb - za)); mg.add(ground(xa, za, xb, zb, CURB), mat); };
  const pave = type === 'plaza' ? M.plazaPaving : M.paving;
  walk(x0 + RW, z0 + CW, x0 + RW + swe, z1 - CW, pave);   // trottoir est de l'avenue x0
  walk(x1 - RW - SW, z0 + CW, x1 - RW, z1 - CW, pave);    // trottoir ouest de l'avenue x1
  walk(x0 + RW + swe, z0 + CW, x1 - RW - SW, z0 + CW + SWC, pave);  // trottoir nord de la rue z0
  walk(x0 + RW + swe, z1 - CW - SWC, x1 - RW - SW, z1 - CW, pave);  // trottoir sud de la rue z1
  // bordures
  mg.add(G.unit, M.concrete, M4(x0 + RW + .12, CURB / 2, (z0 + z1) / 2, .24, CURB, z1 - z0 - 2 * CW)); mg.add(G.unit, M.concrete, M4(x1 - RW - .12, CURB / 2, (z0 + z1) / 2, .24, CURB, z1 - z0 - 2 * CW));
  mg.add(G.unit, M.concrete, M4((x0 + x1) / 2, CURB / 2, z0 + CW + .12, x1 - x0 - 2 * RW, CURB, .24)); mg.add(G.unit, M.concrete, M4((x0 + x1) / 2, CURB / 2, z1 - CW - .12, x1 - x0 - 2 * RW, CURB, .24));
  // bandes podotactiles aux passages
  [[x0 + RW + 1, z0 + CW + 2], [x0 - RW - 1, z0 + CW + 2], [x0 + RW + 1, z1 - CW - 2], [x0 - RW - 1, z1 - CW - 2]].forEach(([x, z]) => mg.add(ground(x - .5, z - 1.6, x + .5, z + 1.6, CURB + .004), M.tactile));
  [[x0 + RW + 2, z0 + CW + .9], [x0 + RW + 2, z0 - CW - .9], [x1 - RW - 2, z0 + CW + .9], [x1 - RW - 2, z0 - CW - .9]].forEach(([x, z]) => mg.add(ground(x - 1.6, z - .5, x + 1.6, z + .5, CURB + .004), M.tactile));

  /* --- îlot --- */
  if (type === 'bld') buildings(mg, M, G, R, i, j, BX0, BX1, BZ0, BZ1, box);
  else if (type === 'park') park(mg, M, G, R, BX0, BX1, BZ0, BZ1, box, circ, grp);
  else plaza(mg, M, G, R, BX0, BX1, BZ0, BZ1, box, circ, grp);

  /* --- arbres (côté ouest de l'avenue x1, et côté est de x0 sauf avenue du parcours) --- */
  const trees = [];
  for (let z = z0 + CW + SWC + 5; z < z1 - CW - SWC - 3; z += 11) {
    trees.push([x1 - RW - 1.6, z + (R() - .5) * 2]);
    if (i !== 0) trees.push([x0 + RW + 1.6, z + 4 + (R() - .5) * 2]);
  }
  if (type === 'park') for (let k = 0; k < 16; k++) trees.push([BX0 + 6 + R() * (BX1 - BX0 - 12), BZ0 + 6 + R() * (BZ1 - BZ0 - 12)]);
  if (type === 'plaza') for (let k = 0; k < 6; k++) trees.push([BX0 + 5 + R() * (BX1 - BX0 - 10), (R() < .5 ? BZ0 + 5 : BZ1 - 5)]);
  addTrees(grp, trees, M, G, R, circ, mg);

  /* --- lampadaires, bornes, bancs, poubelles, boîte aux lettres --- */
  for (let z = z0 + CW + 9; z < z1 - CW - 4; z += 26) { if (i !== 0) lamp(mg, M, G, x0 + RW + .55, z, 1, circ); lamp(mg, M, G, x1 - RW - .55, z + 13, -1, circ); }
  [[x0 + RW + .5, z0 + CW + 5.2], [x0 + RW + 2.2, z0 + CW + 5.2], [x1 - RW - .5, z0 + CW + 5.2], [x1 - RW - 2.2, z0 + CW + 5.2]].filter(([x]) => !(i === 0 && x < x0 + RW + 3)).forEach(([x, z]) => { mg.add(G.cylS, M.dark, M4(x, CURB + .45, z, .08, .9, .08)); circ(x, z, .14); });
  for (let z = z0 + CW + SWC + 14; z < z1 - CW - SWC - 6; z += 30) { if (R() < .7) { bench(mg, M, G, x1 - RW - SW + .6, z, Math.PI / 2, box); mg.add(G.cylS, M.dark, M4(x1 - RW - SW + .5, CURB + .42, z - 1.9, .26, .84, .26)); circ(x1 - RW - SW + .5, z - 1.9, .35); } }
  if (hash(i, j, 9) < .5) { const mx = x0 + RW + swe - .6, mz = z0 + CW + SWC + 3; mg.add(G.unit, M.yellow, M4(mx, CURB + .6, mz, .5, 1.1, .4)); mg.add(G.unit, M.dark, M4(mx, CURB + 1.17, mz, .54, .06, .44)); circ(mx, mz, .4); }
  if (hash(i, j, 11) < .35) busStop(mg, M, G, x1 - RW - 1.9, z0 + CELL / 2 + 6, box);
  /* --- carrefour (x0, z0) : feux et plaques de rue --- */
  const lights = trafficLights(mg, M, G, x0, z0, grp, circ);
  const av = AVENUE_NAMES[((i % AVENUE_NAMES.length) + AVENUE_NAMES.length) % AVENUE_NAMES.length], st = STREET_NAMES[((j % STREET_NAMES.length) + STREET_NAMES.length) % STREET_NAMES.length];
  plates(grp, M, G, x0 + RW + swe - .3, z0 + CW + SWC - .25, av, st, i === 0);
  // voitures garées (bande de stationnement)
  // voitures garées (fusionnées dans la géométrie de la cellule)
  const parked = [];
  for (let z = z0 + CW + 9; z < z1 - CW - 9; z += 6.5) { if (R() < .45 && i !== 0) parked.push([x0 + 4, z + .5, 0]); if (R() < .45) parked.push([x0 - 4, z + 3, Math.PI]); }
  parked.forEach(([px, pz, ry]) => { const paint = M.carPaint[Math.floor(R() * M.carPaint.length)]; const T = (dx, dy, dz, sx = 1, sy = 1, sz = 1) => { const c = Math.cos(ry), sn = Math.sin(ry); return M4(px + dx * c + dz * sn, dy, pz - dx * sn + dz * c, sx, sy, sz, ry); };
    mg.add(G.carBody, paint, T(0, 0, 0)); mg.add(G.carCab, M.carGlass, T(0, 1.17, .2)); mg.add(G.carRoof, paint, T(0, 1.5, .2));
    [-.62, .62].forEach(x => { mg.add(G.unit, M.lampOn, T(x, .74, -2.16, .38, .14, .05)); mg.add(G.unit, M.red, T(x, .78, 2.16, .38, .14, .05)); });
    [[-.86, 1.35], [.86, 1.35], [-.86, -1.35], [.86, -1.35]].forEach(([x, z]) => { mg.add(G.wheel, M.tire, T(x, .34, z)); mg.add(G.rim, M.rim, T(x, .34, z)); }); });

  mg.build(grp);
  grp.userData = { col, lights, parked, i, j, type };
  return grp;
}

function buildings(mg, M, G, R, i, j, BX0, BX1, BZ0, BZ1, box) {
  const D = 14; // profondeur des immeubles
  const strip = (len, place) => { let t = 0; while (len - t > 6) { let w = BAY * (2 + Math.floor(R() * 3)); if (len - t - w < 6) w = len - t; place(t, w); t += w; } };
  const pick = () => Math.floor(R() * M.facades.length);
  const bld = (xa, za, xb, zb, face, fi, floors) => {
    const h = floors * FLOOR, w = face === 'x' ? zb - za : xb - xa;
    const F = M.facades[fi], uvw = w / (BAY * 4), uvd = D / (BAY * 4), vh = floors / 8;
    // 4 faces (toutes texturées, la face principale regarde la rue), toit
    mg.add(quad([xa, 0, zb], [xa, 0, za], [xa, h, zb], [xa, h, za], [-1, 0, 0], (zb - za) / (BAY * 4), vh), F);
    mg.add(quad([xb, 0, za], [xb, 0, zb], [xb, h, za], [xb, h, zb], [1, 0, 0], (zb - za) / (BAY * 4), vh), F);
    mg.add(quad([xb, 0, za], [xa, 0, za], [xb, h, za], [xa, h, za], [0, 0, -1], (xb - xa) / (BAY * 4), vh), F);
    mg.add(quad([xa, 0, zb], [xb, 0, zb], [xa, h, zb], [xb, h, zb], [0, 0, 1], (xb - xa) / (BAY * 4), vh), F);
    mg.add(ground(xa, za, xb, zb, h), M.roof);
    // acrotère, corniche
    const T = M.trims[fi % 2];
    mg.add(G.unit, M.concrete, M4((xa + xb) / 2, h + .25, za + .15, xb - xa, .5, .3)); mg.add(G.unit, M.concrete, M4((xa + xb) / 2, h + .25, zb - .15, xb - xa, .5, .3));
    mg.add(G.unit, M.concrete, M4(xa + .15, h + .25, (za + zb) / 2, .3, .5, zb - za)); mg.add(G.unit, M.concrete, M4(xb - .15, h + .25, (za + zb) / 2, .3, .5, zb - za));
    mg.add(G.unit, T, M4((xa + xb) / 2, h - .1, (za + zb) / 2, xb - xa + .5, .35, zb - za + .5));
    // toiture : cheminées, climatiseurs, antennes, lucarnes
    const n = 1 + Math.floor(R() * 3);
    for (let k = 0; k < n; k++) { const px = xa + 2 + R() * (xb - xa - 4), pz = za + 2 + R() * (zb - za - 4); const kind = R(); if (kind < .4) mg.add(G.unit, M.metal, M4(px, h + .45, pz, 1.1, .9, .8)); else if (kind < .7) mg.add(G.cylS, M.concrete, M4(px, h + .7, pz, .35, 1.4, .35)); else mg.add(G.cylS, M.dark, M4(px, h + 1.5, pz, .04, 3, .04)); }
    // enseigne et store au rez-de-chaussée, sur la face qui regarde la rue
    const si = Math.floor(R() * M.signCount), su0 = (si % 2) / 2, sv1 = 1 - Math.floor(si / 2) / 8, su1 = su0 + .5, sv0 = sv1 - 1 / 8; const sw = Math.min(w - 1.2, 7), sh = .78, sy0 = 3.3, sy1 = sy0 + sh;
    const aw = M.awnings[Math.floor(R() * M.awnings.length)];
    if (face === 'x') { const xf = fi % 2 === 0 ? xa : xb, dir = xf === xa ? -1 : 1, zc = (za + zb) / 2, xs = xf + dir * .06; const a = zc + dir * -sw / 2, b = zc + dir * sw / 2; mg.add(quadUV([xs, sy0, dir < 0 ? zc + sw / 2 : zc - sw / 2], [xs, sy0, dir < 0 ? zc - sw / 2 : zc + sw / 2], [xs, sy1, dir < 0 ? zc + sw / 2 : zc - sw / 2], [xs, sy1, dir < 0 ? zc - sw / 2 : zc + sw / 2], [dir, 0, 0], su0, sv0, su1, sv1), M.signAtlas); if (R() < .6) mg.add(G.unit, aw, M4(xf + dir * .7, 3.2, zc, 1.4, .06, Math.min(w - 2, 5), 0, 0, -dir * .3)); }
    else { const zf = fi % 2 === 0 ? za : zb, dir = zf === za ? -1 : 1, xc = (xa + xb) / 2, zs = zf + dir * .06; mg.add(quadUV([dir < 0 ? xc + sw / 2 : xc - sw / 2, sy0, zs], [dir < 0 ? xc - sw / 2 : xc + sw / 2, sy0, zs], [dir < 0 ? xc + sw / 2 : xc - sw / 2, sy1, zs], [dir < 0 ? xc - sw / 2 : xc + sw / 2, sy1, zs], [0, 0, dir], su0, sv0, su1, sv1), M.signAtlas); if (R() < .6) mg.add(G.unit, aw, M4(xc, 3.2, zf + dir * .7, Math.min(w - 2, 5), .06, 1.4, 0, dir * .3, 0)); }
    box({ x0: xa - .3, x1: xb + .3, z0: za - .3, z1: zb + .3 });
  };
  // bandes ouest / est (façade sur l'avenue) sur toute la profondeur, nord / sud entre les deux
  strip(BZ1 - BZ0, (t, w) => { const fi = pick(); bld(BX0, BZ0 + t, BX0 + D, BZ0 + t + w, 'x', fi - (fi % 2), 3 + Math.floor(R() * 5)); });
  strip(BZ1 - BZ0, (t, w) => { const fi = pick(); bld(BX1 - D, BZ0 + t, BX1, BZ0 + t + w, 'x', fi | 1, 3 + Math.floor(R() * 5)); });
  strip(BX1 - BX0 - 2 * D, (t, w) => { const fi = pick(); bld(BX0 + D + t, BZ0, BX0 + D + t + w, BZ0 + D, 'z', fi - (fi % 2), 3 + Math.floor(R() * 5)); });
  strip(BX1 - BX0 - 2 * D, (t, w) => { const fi = pick(); bld(BX0 + D + t, BZ1 - D, BX0 + D + t + w, BZ1, 'z', fi | 1, 3 + Math.floor(R() * 5)); });
  // cour intérieure
  mg.add(ground(BX0 + D, BZ0 + D, BX1 - D, BZ1 - D, CURB), M.grass);
}

function park(mg, M, G, R, BX0, BX1, BZ0, BZ1, box, circ, grp) {
  mg.add(ground(BX0, BZ0, BX1, BZ1, CURB), M.grass);
  const cx = (BX0 + BX1) / 2, cz = (BZ0 + BZ1) / 2;
  mg.add(ground(cx - 2.2, BZ0, cx + 2.2, BZ1, CURB + .01), M.gravel); mg.add(ground(BX0, cz - 2.2, BX1, cz + 2.2, CURB + .01), M.gravel);
  mg.add(G.disc, M.gravel, M4(cx, CURB + .012, cz, 9, 1, 9));
  // fontaine
  mg.add(G.cyl, M.concrete, M4(cx, CURB + .35, cz, 4, .7, 4)); mg.add(G.cyl, M.concrete, M4(cx, CURB + .9, cz, .5, 1.8, .5)); mg.add(G.cyl, M.concrete, M4(cx, CURB + 1.85, cz, 1.4, .18, 1.4));
  const water = new THREE.Mesh(G.disc, M.water); water.scale.set(3.7, 1, 3.7); water.position.set(cx, CURB + .62, cz); grp.add(water); grp.userData.water = water;
  circ(cx, cz, 4.3);
  // parterres fleuris
  for (let k = 0; k < 4; k++) { const a = k * Math.PI / 2 + Math.PI / 4, fx = cx + Math.cos(a) * 12, fz = cz + Math.sin(a) * 12; mg.add(G.disc, M.gravel, M4(fx, CURB + .012, fz, 3.2, 1, 3.2)); const fm = M.flowers[k % M.flowers.length]; for (let f = 0; f < 26; f++) { const r = R() * 2.6, b = R() * 6.3; mg.add(G.sph, fm, M4(fx + Math.cos(b) * r, CURB + .25, fz + Math.sin(b) * r, .18, .18, .18)); } for (let f = 0; f < 30; f++) { const r = R() * 2.8, b = R() * 6.3; mg.add(G.sph, M.hedge, M4(fx + Math.cos(b) * r, CURB + .12, fz + Math.sin(b) * r, .22, .14, .22)); } }
  // bancs autour de la fontaine
  for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; bench(mg, M, G, cx + Math.cos(a) * 7, cz + Math.sin(a) * 7, -a + Math.PI / 2, box); }
  // haie périphérique
  for (let x = BX0 + 1; x < BX1; x += 2) { mg.add(G.unit, M.hedge, M4(x, CURB + .45, BZ0 + .6, 2, .9, 1)); mg.add(G.unit, M.hedge, M4(x, CURB + .45, BZ1 - .6, 2, .9, 1)); }
  for (let z = BZ0 + 1; z < BZ1; z += 2) { mg.add(G.unit, M.hedge, M4(BX0 + .6, CURB + .45, z, 1, .9, 2)); mg.add(G.unit, M.hedge, M4(BX1 - .6, CURB + .45, z, 1, .9, 2)); }
  box({ x0: BX0, x1: BX0 + 1.2, z0: BZ0, z1: cz - 2.5 }); box({ x0: BX0, x1: BX0 + 1.2, z0: cz + 2.5, z1: BZ1 }); box({ x0: BX1 - 1.2, x1: BX1, z0: BZ0, z1: cz - 2.5 }); box({ x0: BX1 - 1.2, x1: BX1, z0: cz + 2.5, z1: BZ1 });
  box({ x0: BX0, x1: cx - 2.5, z0: BZ0, z1: BZ0 + 1.2 }); box({ x0: cx + 2.5, x1: BX1, z0: BZ0, z1: BZ0 + 1.2 }); box({ x0: BX0, x1: cx - 2.5, z0: BZ1 - 1.2, z1: BZ1 }); box({ x0: cx + 2.5, x1: BX1, z0: BZ1 - 1.2, z1: BZ1 });
}

function plaza(mg, M, G, R, BX0, BX1, BZ0, BZ1, box, circ, grp) {
  mg.add(ground(BX0, BZ0, BX1, BZ1, CURB), M.plazaPaving);
  const cx = (BX0 + BX1) / 2, cz = (BZ0 + BZ1) / 2;
  // bassin
  mg.add(G.cyl, M.concrete, M4(cx, CURB + .3, cz, 3, .6, 3)); const water = new THREE.Mesh(G.disc, M.water); water.scale.set(2.7, 1, 2.7); water.position.set(cx, CURB + .5, cz); grp.add(water); grp.userData.water = water; circ(cx, cz, 3.3);
  // terrasse de café : tables, chaises, parasols
  for (let k = 0; k < 8; k++) { const tx = BX0 + 6 + (k % 4) * 4.2, tz = BZ0 + 8 + Math.floor(k / 4) * 4.2; mg.add(G.cyl, M.dark, M4(tx, CURB + .72, tz, .45, .04, .45)); mg.add(G.cylS, M.dark, M4(tx, CURB + .36, tz, .03, .72, .03)); for (let c = 0; c < 3; c++) { const a = c * 2.1; mg.add(G.unit, M.wood, M4(tx + Math.cos(a) * .9, CURB + .45, tz + Math.sin(a) * .9, .42, .05, .42, -a)); mg.add(G.unit, M.wood, M4(tx + Math.cos(a) * 1.1, CURB + .7, tz + Math.sin(a) * 1.1, .05, .5, .42, -a)); } if (k % 2 === 0) { mg.add(G.cylS, M.metal, M4(tx, CURB + 1.3, tz, .025, 2.6, .025)); mg.add(G.cone, M.awnings[(k / 2) % M.awnings.length], M4(tx, CURB + 2.55, tz, 1.9, .5, 1.9)); } circ(tx, tz, 1.3); }
  // kiosque
  const kx = BX1 - 8, kz = BZ1 - 8; mg.add(G.unit, M.trims[3], M4(kx, CURB + 1.4, kz, 4, 2.8, 3)); mg.add(G.unit, M.awnings[0], M4(kx, CURB + 3.0, kz, 4.8, .12, 3.8)); mg.add(quadUV([kx + 1.7, CURB + 2.0, kz - 1.52], [kx - 1.7, CURB + 2.0, kz - 1.52], [kx + 1.7, CURB + 2.6, kz - 1.52], [kx - 1.7, CURB + 2.6, kz - 1.52], [0, 0, -1], .5, 1 - 6 / 8, 1, 1 - 5 / 8), M.signAtlas); box({ x0: kx - 2.3, x1: kx + 2.3, z0: kz - 1.8, z1: kz + 1.8 });
  // jardinières et bancs
  for (let k = 0; k < 6; k++) { const px = BX0 + 4 + k * ((BX1 - BX0 - 8) / 5), pz = BZ1 - 4; mg.add(G.unit, M.concrete, M4(px, CURB + .3, pz, 1.6, .6, .8)); for (let f = 0; f < 10; f++) mg.add(G.sph, M.flowers[(k + f) % 5], M4(px - .6 + R() * 1.2, CURB + .7, pz - .25 + R() * .5, .16, .16, .16)); box({ x0: px - .8, x1: px + .8, z0: pz - .4, z1: pz + .4 }); }
  for (let k = 0; k < 3; k++) bench(mg, M, G, cx + 6 + k * 3, cz - 6, 0, box);
}

function addTrees(grp, list, M, G, R, circ, mg) {
  if (!list.length) return;
  const leafGeo = G.leaf, n = list.length;
  let count = 0; const items = [];
  list.forEach(([x, z]) => { mg.add(G.cylS, M.trunk, M4(x, CURB + 1.55, z, .17, 3.1, .17)); for (let b = 0; b < 3; b++) mg.add(G.cylS, M.trunk, M4(x + (R() - .5) * .8, CURB + 3.3, z + (R() - .5) * .8, .06, 1.6, .06, 0, (R() - .5) * 1.1, (R() - .5) * 1.1)); mg.add(G.unit, M.dark, M4(x, CURB + .005, z, 1.6, .01, 1.6)); circ(x, z, .4); const k = 15 + Math.floor(R() * 8); for (let q = 0; q < k; q++) { const a = R() * 6.3, rr = Math.pow(R(), .6) * 1.7, hh = 3.5 + (R() - .3) * 2.2 * (1 - rr / 2.6), s = .6 + R() * .6; items.push([x + Math.cos(a) * rr, CURB + hh, z + Math.sin(a) * rr, s, R() * 3, R() * 3]); } });
  const im = new THREE.InstancedMesh(leafGeo, M.leaf, items.length); const d = new THREE.Object3D(); const c = new THREE.Color();
  const greens = ['#3b6b2c', '#4a7d35', '#5a8f3d', '#34612a', '#6a9a46', '#55843a'];
  items.forEach((it, k) => { d.position.set(it[0], it[1], it[2]); d.scale.set(it[3], it[3] * .85, it[3]); d.rotation.set(it[4], it[5], 0); d.updateMatrix(); im.setMatrixAt(k, d.matrix); im.setColorAt(k, c.set(greens[k % greens.length])); });
  im.castShadow = true; im.receiveShadow = true; grp.add(im);
}
function lamp(mg, M, G, x, z, side, circ) { mg.add(G.cylS, M.dark, M4(x, CURB + 3.2, z, .08, 6.4, .08)); mg.add(G.unit, M.dark, M4(x - side * .7, CURB + 6.3, z, 1.5, .08, .08)); mg.add(G.unit, M.lampOn, M4(x - side * 1.3, CURB + 6.2, z, .6, .16, .32)); circ(x, z, .16); }
function bench(mg, M, G, x, z, ry, box) { mg.add(G.unit, M.wood, M4(x, CURB + .46, z, .5, .06, 1.8, ry)); mg.add(G.unit, M.wood, M4(x - Math.cos(ry) * .24, CURB + .78, z + Math.sin(ry) * .24, .06, .46, 1.8, ry)); [-.75, .75].forEach(o => mg.add(G.unit, M.dark, M4(x - Math.sin(ry) * o, CURB + .22, z - Math.cos(ry) * o, .46, .44, .06, ry))); box({ x0: x - 1, x1: x + 1, z0: z - 1, z1: z + 1 }); }
function busStop(mg, M, G, x, z, box) { [-2.2, 2.2].forEach(o => mg.add(G.cylS, M.metal, M4(x + 1.2, CURB + 1.3, z + o, .05, 2.6, .05))); mg.add(G.unit, M.metal, M4(x, CURB + 2.65, z, 2.8, .08, 5)); mg.add(G.unit, M.glass, M4(x + 1.3, CURB + 1.4, z, .04, 2.4, 4.8)); mg.add(G.unit, M.glass, M4(x, CURB + 1.4, z - 2.45, 2.6, 2.4, .04)); mg.add(G.unit, M.wood, M4(x + .7, CURB + .5, z, .5, .06, 3)); mg.add(G.cylS, M.metal, M4(x - 1.2, CURB + 1.5, z - 2.2, .04, 3, .04)); mg.add(G.plane, M.busSign, M4(x - 1.2, CURB + 2.7, z - 2.2, .9, .45, 1, Math.PI / 2)); box({ x0: x - 1.5, x1: x + 1.5, z0: z - 2.6, z1: z + 2.6 }); }
function trafficLights(mg, M, G, x0, z0, grp, circ) {
  const acc = { av: { red: [], amber: [], green: [] }, cr: { red: [], amber: [], green: [] } };
  const head = (x, z, ry, group) => { mg.add(G.unit, M.dark, M4(x, CURB + 4.0, z, .34, 1.05, .3, ry)); const dz = Math.cos(ry) * .17, dx = Math.sin(ry) * .17; [['red', 4.33], ['amber', 4.0], ['green', 3.67]].forEach(([c, y]) => { const g = G.sph.clone(); g.applyMatrix4(M4(x + dx, CURB + y, z + dz, .11, .11, .11)); acc[group][c].push(g); }); };
  const corners = [[x0 + RW + .7, z0 + CW + .7, 0, Math.PI / 2], [x0 - RW - .7, z0 - CW - .7, Math.PI, -Math.PI / 2]];
  corners.forEach(([x, z, ryAv, ryCr]) => { mg.add(G.cylS, M.dark, M4(x, CURB + 2.3, z, .07, 4.6, .07)); circ(x, z, .15); head(x, z, ryAv, 'av'); head(x, z, ryCr, 'cr'); });
  const lights = { av: {}, cr: {} };
  for (const grpK of ['av', 'cr']) for (const c of ['red', 'amber', 'green']) { const m = new THREE.Mesh(mergeGeometries(acc[grpK][c], false), M.lightOff); grp.add(m); lights[grpK][c] = m; }
  return lights;
}
function plates(grp, M, G, x, z, av, st, main) {
  const key = av + '|' + st; const pm = M.plates[av] || (M.plates[av] = M.plateTex(av)), ps = M.plates[st] || (M.plates[st] = M.plateTex(st));
  const pole = new THREE.Mesh(G.cylS, M.metal); pole.scale.set(.04, 3, .04); pole.position.set(x, CURB + 1.5, z); grp.add(pole);
  const a = new THREE.Mesh(G.plane, pm); a.scale.set(1.5, .28, 1); a.position.set(x - .04, CURB + 2.9, z); a.rotation.y = -Math.PI / 2; grp.add(a);
  const b = new THREE.Mesh(G.plane, ps); b.scale.set(1.5, .28, 1); b.position.set(x, CURB + 2.55, z - .04); b.rotation.y = Math.PI; grp.add(b);
  const s = new THREE.Mesh(G.plane, M.crossSign); s.scale.set(.6, .6, 1); s.position.set(x, CURB + 2.1, z + .04); grp.add(s);
}

export function makeGeometries() {
  const unit = new THREE.BoxGeometry(1, 1, 1), cyl = new THREE.CylinderGeometry(1, 1, 1, 24), cylS = new THREE.CylinderGeometry(1, 1, 1, 10), sph = new THREE.SphereGeometry(1, 12, 9), cone = new THREE.ConeGeometry(1, 1, 12), plane = new THREE.PlaneGeometry(1, 1);
  const disc = new THREE.CircleGeometry(1, 28); disc.rotateX(-Math.PI / 2);
  const leaf = new THREE.IcosahedronGeometry(1, 2); { const p = leaf.attributes.position; for (let i = 0; i < p.count; i++) { const k = .8 + Math.random() * .4; p.setXYZ(i, p.getX(i) * k, p.getY(i) * k, p.getZ(i) * k); } leaf.computeVertexNormals(); }
  const carBody = new RoundedBoxGeometry(1.8, .66, 4.3, 4, .22); carBody.translate(0, .64, 0);
  const carCab = new RoundedBoxGeometry(1.64, .6, 2.35, 4, .2), carRoof = new RoundedBoxGeometry(1.58, .1, 1.95, 3, .05);
  const wheel = new THREE.CylinderGeometry(.34, .34, .26, 20); wheel.rotateZ(Math.PI / 2); const rim = new THREE.CylinderGeometry(.2, .2, .27, 12); rim.rotateZ(Math.PI / 2);
  return { unit, cyl, cylS, sph, cone, plane, disc, leaf, carBody, carCab, carRoof, wheel, rim };
}

/* ---------------- Voiture ---------------- */
export function makeCar(M, G, paint) {
  const g = new THREE.Group();
  const body = M.carPaint[paint % M.carPaint.length];
  const lower = new THREE.Mesh(G.carBody, body); lower.castShadow = true; g.add(lower);
  const cab = new THREE.Mesh(G.carCab, M.carGlass); cab.position.set(0, 1.17, .2); cab.castShadow = true; g.add(cab);
  const roof = new THREE.Mesh(G.carRoof, body); roof.position.set(0, 1.5, .2); g.add(roof);
  [-.62, .62].forEach(x => { const f = new THREE.Mesh(G.unit, M.lampOn); f.scale.set(.38, .14, .05); f.position.set(x, .74, -2.16); g.add(f); const r = new THREE.Mesh(G.unit, M.red); r.scale.set(.38, .14, .05); r.position.set(x, .78, 2.16); g.add(r); });
  const plate = new THREE.Mesh(G.unit, M.white); plate.scale.set(.5, .11, .03); plate.position.set(0, .5, 2.17); g.add(plate);
  g.userData.wheels = [];
  [[-.86, 1.35], [.86, 1.35], [-.86, -1.35], [.86, -1.35]].forEach(([x, z]) => { const w = new THREE.Mesh(G.wheel, M.tire); w.position.set(x, .34, z); w.castShadow = true; const r = new THREE.Mesh(G.rim, M.rim); w.add(r); g.add(w); g.userData.wheels.push(w); });
  return g;
}
