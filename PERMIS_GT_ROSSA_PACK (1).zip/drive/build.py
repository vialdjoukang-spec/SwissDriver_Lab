import base64,subprocess
subprocess.run('npx esbuild src/main.js --bundle --format=iife --minify --charset=utf8 --outfile=bundle.js --log-level=warning',shell=True,check=True)
d=open('/home/claude/work/data.js').read().replace('const DATA=','window.DATA=',1)
hb='window.AVATAR_B64="'+base64.b64encode(open('/home/claude/assets/rpm.glb','rb').read()).decode()+'";\nwindow.ANIM_B64="'+base64.b64encode(open('/home/claude/assets/anim.glb','rb').read()).decode()+'";\n'
html=open('shell.html').read()+d+hb+'\n</script>\n<script>\n'+open('bundle.js').read().replace('</script','<\\/script')+'\n</script>\n</body>\n</html>\n'
open('Permis_GT_Rossa.html','w').write(html); print(len(html))
