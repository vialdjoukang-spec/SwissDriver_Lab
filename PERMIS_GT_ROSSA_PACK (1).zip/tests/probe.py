import asyncio,sys,time
from playwright.async_api import async_playwright
ID=sys.argv[1]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    pg=await b.new_page(viewport={'width':900,'height':560})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.add_init_script("window.__DTMAX=.1;window.__NORENDER=1")
    await pg.goto('file:///home/claude/drive/Permis_GT_Rossa.html',wait_until='commit')
    for i in range(120):
      await asyncio.sleep(1)
      if await pg.evaluate('!!window.__G'): break
    await pg.keyboard.press('Enter'); await asyncio.sleep(1)
    idx=await pg.evaluate(f'__G.ITEMS.findIndex(i=>i.sc&&i.sc.id==="{ID}")')
    z=await pg.evaluate(f'__G.ITEMS[{idx}].z'); slot=await pg.evaluate(f'__G.ITEMS[{idx}].sc.slot')
    await pg.evaluate(f'__G.ST.idx={idx};__G.P.x=1.5;__G.P.z={z}+{58 if slot=="int" else 62};__G.P.h=0;__G.P.v=9;__G.snap();__G.rf()')
    await pg.keyboard.down('w')
    for k in range(int(sys.argv[2]) if len(sys.argv)>2 else 12):
      await asyncio.sleep(3)
      print(await pg.evaluate('({f:__G.frames(),m:__G.mode,P:[+__G.P.x.toFixed(1),+__G.P.z.toFixed(1),+__G.P.v.toFixed(1)],S:__G.SIT&&{ph:__G.SIT.phase,dec:__G.SIT.decS,sA:__G.P.sAlong,stop:__G.SIT.stopS,A:__G.P.auto&&[__G.P.auto.s,__G.P.auto.stopAt],st:__G.SIT.stopT}})'),errs[:2],flush=True)
      if await pg.evaluate('__G.mode==="decide"'): break
    await pg.keyboard.up('w')
    await pg.evaluate('window.__NORENDER=0'); await asyncio.sleep(4); await pg.screenshot(path=f't/p_{ID}.png',timeout=120000)
    await b.close()
asyncio.run(main())
