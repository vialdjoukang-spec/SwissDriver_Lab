import asyncio,sys,json,time,os
BI=int(os.environ.get('BI','0')); SKIPG=os.environ.get('SKIPG')
from playwright.async_api import async_playwright
ONLY=sys.argv[1] if len(sys.argv)>1 else None
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    pg=await b.new_page(viewport={'width':900,'height':560})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m: m.type=='error' and errs.append(m.text))
    await pg.add_init_script("window.__DTMAX=.1;window.__NORENDER=1")
    await pg.goto('file:///home/claude/drive/Permis_GT_Rossa.html',wait_until='commit')
    for i in range(120):
      await asyncio.sleep(1)
      if await pg.evaluate('!!window.__G') or errs: break
    await pg.keyboard.press('Enter'); await asyncio.sleep(2)
    if SKIPG: await pg.evaluate('window.__NOCOURSE=1')
    async def shot(path,timeout):
      await pg.evaluate('window.__NORENDER=0'); await asyncio.sleep(3); await pg.screenshot(path=path,timeout=timeout); await pg.evaluate('window.__NORENDER=1')
    async def waitm(cond,secs):
      t0=time.time()
      while time.time()-t0<secs:
        if await pg.evaluate(cond): return True
        if errs: return False
        await asyncio.sleep(.5)
      return False
    n=await pg.evaluate('__G.ITEMS.length'); log=[]
    shots=0
    for idx in range(n):
      it=await pg.evaluate(f'(()=>{{const i=__G.ITEMS[{idx}];return {{type:i.type,z:i.z,id:i.sc&&i.sc.id,slot:i.sc&&i.sc.slot,ok:i.sc&&i.sc.ok}}}})()')
      await pg.evaluate(f'__G.ST.idx={idx}')
      if ONLY and it['type']=='sit' and it['id'] not in ONLY.split(','): continue
      if it['type'] in ('chapGate','secGate','secEnd') and SKIPG: continue
      if it['type'] in ('chapGate','secGate','secEnd'):
        await pg.evaluate(f'__G.P.x=1.5;__G.P.z={it["z"]}+8;__G.P.h=0;__G.P.v=8;__G.snap()')
        ok=await waitm(f'__G.mode==="course"||__G.ST.idx>{idx}',40)
        if it['type']!='secEnd' and shots<2: await shot(path=f't/c{shots}.png',timeout=120000); shots+=1
        if await pg.evaluate('__G.mode==="course"'): await pg.evaluate('__G.closeCourse()')
        log.append((it['type'],ok,await pg.evaluate('__G.ST.idx'))); print(log[-1],flush=True); continue
      res={}
      for phase in ('bad','good'):
        if ONLY or phase=='bad' or True:
          pass
        await pg.evaluate(f'__G.ST.idx={idx};__G.P.x=1.5;__G.P.z={it["z"]}+{58 if it["slot"]=="int" else 62};__G.P.h=0;__G.P.v=9;__G.snap()')
        await pg.keyboard.down('w')
        okd=await waitm('__G.mode==="decide"',60)
        await pg.keyboard.up('w')
        if not okd: res[phase]='NODECIDE mode='+await pg.evaluate('__G.mode'); break
        if phase=='bad' and ONLY: await shot(path=f't/d_{it["id"]}.png',timeout=120000)
        k=await pg.evaluate(f'(()=>{{const D=__G.DEC();const ok=D.S.sc.ok;const ks=[0,1,2].filter(k=>{"(D.order[k]!==ok)" if phase=="bad" else "(D.order[k]===ok)"});return ks[%d]}})()'%(BI if phase=='bad' else 0))
        await pg.evaluate(f'__G.choose({k})')
        if phase=='bad':
          r=await waitm('__G.mode==="explain"',60); res['bad']=r
          if ONLY: await shot(path=f't/e_{it["id"]}.png',timeout=120000)
          await pg.evaluate('__G.replay()')
        else:
          r=await waitm(f'__G.ST.done.includes("{it["id"]}")',90); res['good']=r
          if not r: res['gstate']=await pg.evaluate('({m:__G.mode,P:[__G.P.x,__G.P.z,__G.P.v],A:__G.P.auto&&[__G.P.auto.s,__G.P.auto.stopAt,__G.P.auto.target],S:__G.SIT&&{w:__G.SIT.waiting,ph:__G.SIT.phase,end:__G.SIT.endS}})')
      log.append((it['id'],res)); print(log[-1],errs[:3],flush=True)
      if errs: break
    print('ERRS',errs[:5])
    await b.close()
asyncio.run(main())
