# 01 · INSTRUCTIONS ET ARCHITECTURE · PERMIS GT ROSSA

## A. Pour l'utilisateur, en 3 gestes

1. **Déposer l'archive dans le dossier.** Glissez `PERMIS_GT_ROSSA_PACK.zip` (reçue dans la conversation avec Claude) dans le dossier Google Drive **`GPT_PERMIS_GT_ROSSA_PROJET`**.
2. **Activer le connecteur.** Dans ChatGPT, activez le connecteur **Google Drive** (dans les connecteurs ou applications).
3. **Lancer ChatGPT.** Collez ce message :
   > Cherche dans mon Google Drive le dossier « GPT_PERMIS_GT_ROSSA_PROJET ». Lis le document « 00_PROMPT_GPT_PERMIS_GT_ROSSA », puis « 01_INSTRUCTIONS_ARCHITECTURE_PERMIS_GT_ROSSA », puis exécute intégralement le prompt. Livre le résultat dans ce même dossier.

Si ChatGPT ne parvient pas à ouvrir le .zip depuis Drive, joignez-le directement dans la conversation ChatGPT.

## B. Contenu de l'archive PERMIS_GT_ROSSA_PACK.zip

| Chemin | Rôle |
|---|---|
| `html/Permis_GT_Rossa.html` | Le jeu de conduite (pilote O11 Priorités), le produit à achever |
| `html/Permis_Parcours_3D.html` | Le parcours 3D à pied : stations de cours et QCM (référence) |
| `html/Permis_de_Conduire.html` | La plateforme de révision : cours complet, 1220 questions, 20 thèmes clairs |
| `drive/src/main.js` | Le moteur : rendu, conduite, parcours, portiques, situations, interface, sauvegarde |
| `drive/src/scenarios.js` | **Les scénarios** (`SCENARIOS`, `CHAPTERS_READY`) |
| `drive/src/city.js` | La ville procédurale en grille infinie (chunks, feux, collisions) |
| `drive/src/vehicles.js` | La GT Rossa, l'ambulance, le camion, la camionnette, le tram, les cônes |
| `drive/src/signs.js` | Les panneaux suisses dessinés sur canvas, les marquages |
| `drive/src/human.js` | Les piétons (avatar GLB et animations reciblées) |
| `drive/shell.html` | L'interface HTML et CSS (thème clair) |
| `drive/build.py` | Le build : esbuild, puis intégration de data.js et des GLB en base64 |
| `data/data.js` | **`DATA`** : tout le cours (groupes, chapitres, sections, questions) |
| `assets/rpm.glb`, `assets/anim.glb` | L'avatar et ses animations |
| `tests/t2.py`, `tests/probe.py` | Les tests Playwright headless |

## C. Build

```bash
npm i three@0.160.0 esbuild@0.21.5
# dans build.py, adapter les chemins : ../data/data.js et ../assets/*.glb
python3 build.py   # → Permis_GT_Rossa.html
```

## D. Le modèle de données DATA

`DATA.groups[]` = `{id, official, title, chapters:[chapterId]}`

`DATA.chapters[]` = `{id, otitle, oscope, title, tagline, intro, keyIdea, memo:{code,text}, sources, color, group, sections[]}`

`section` = `{id, otitle, ogoal, title, question, lead, parts:[{title,body}], words, method, example:{title,scene,reasoning,answer}, trap, remember, memo, law, diagram, source}`

## E. Le schéma d'un scénario (scenarios.js)

```js
{ id:'h1', pt:0,            // pt = index du point officiel couvert dans la section
  slot:'int' | 'mid',       // 'int' : à un carrefour (z = -80k) ; 'mid' : entre deux carrefours (z = -80k-40)
  kind:'agent',             // le type de mise en scène, codé dans buildSit() de main.js
  title, scene,             // markdown léger (**gras**)
  choices:[{t, act:'go'|'wait'|'pull'|'creep'|'info'|'rush', did}], // exactement 3 choix
  ok:1,                     // index de la bonne réponse (l'affichage est mélangé)
  should, why, memo }
```

**Les actes :**

- `go` : je passe ;
- `wait` : je cède, puis je repars quand c'est libre ;
- `creep` : j'avance au pas ;
- `pull` : je me range à droite ;
- `info` : je m'arrête ou j'hésite à tort ;
- `rush` : je force à vitesse élevée.

**Ajouter une mise en scène :** créer un `case` dans `buildSit(it)`, avec les éléments suivants.

- **Acteurs :** `actor(mesh, Path, {hold, prio, clear, vmax, rad})`.
- **Trajets :** `S.pPath`, plus les abscisses `decS`, `stopS`, `clearS` et `endS`.
- **Feux :** `LIGHT_OVR` force les feux d'un carrefour : `'off'`, `'red'` ou `'green'`.
- **Résolution :** elle est générique, dans `startResolve()` et `updateSit()`.

## F. Les crochets de test

- `window.__G` : `{P, ST, ITEMS, SIT, mode, choose(k), replay(), frames(), rf(), snap(), closeCourse(), DEC()}`.
- `window.__NORENDER = 1` saute le rendu, ce qui permet de tester la logique à 60 images par seconde en mode headless.
- `window.__DTMAX` fixe le pas de temps maximal.
- Paramètres de Chromium : `--use-gl=angle --use-angle=swiftshader --enable-unsafe-swiftshader --ignore-gpu-blocklist`.

## G. Préférences de l'utilisateur, non négociables

- Un thème **clair uniquement**.
- Les titres officiels exacts (Partie / Chapitre / Sous-chapitre).
- Un texte justifié.
- Un langage pour un **novice absolu**.
- Le contenu du cours à 100 %.
- Aucune marque déposée.
- La livraison directe quand les tests passent.
